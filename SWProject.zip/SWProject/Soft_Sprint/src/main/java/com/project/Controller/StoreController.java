package com.project.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.Entities.Store;
import com.project.Repository.StoreRepository;

@Controller
public class StoreController {
	@Autowired
	private StoreRepository repo;

	@GetMapping("/addstore")
	public String getstore(Model model) {
		System.out.println("============= ssssssssssssssssssssssssssssssssss");
		model.addAttribute("store", new Store());
		return "addstore";
	}

	@PostMapping("/addstore")
	public String addStore(Model model, @ModelAttribute Store store, HttpSession session) {
		System.out.println("=============aaaaaaaaaaaaaaaaaaaaaaaa");
		System.out.println(store.getStore_name());
		System.out.println(store.getStore_category());
		System.out.println(store.getStore_location());
		System.out.println(store.getApprove());
		String ID = session.getAttribute("UserIdSession").toString();
		Integer UserId = Integer.parseInt(ID);
		store.setOwner_id(UserId);
		repo.save(store);
		model.addAttribute("store", new Store());
		return "OwnerHomePage";
	}

}
