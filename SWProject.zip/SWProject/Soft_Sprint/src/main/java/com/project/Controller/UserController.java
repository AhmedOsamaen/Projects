package com.project.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.Entities.User;
import com.project.Repository.UserRepository;

@Controller
public class UserController {
	@Autowired
	private UserRepository repo;
	@GetMapping("/adduser")	
	public String ShowUser(Model model)
	{
		model.addAttribute("user", new User());
		return "adduser";
	}
	@PostMapping("/adduser")	
	public String addUser(Model model,@ModelAttribute User user)
	{
		System.out.println(user.getName());
		System.out.println(user.getEmail());		
		System.out.println(user.getPassword());
		repo.save(user);
		model.addAttribute("user", new User());
		return "adduser";		
	}
	
	
	
}
