package com.project.Repository;

import java.util.Vector;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Product;
//import com.project.Entities.Store;

public interface  ProductRepository extends CrudRepository<Product, Integer>{

//	Product findByid(int Owner);

	Product findByid(Integer id);
	//Product findByStoreId(Integer Id);
	

}
