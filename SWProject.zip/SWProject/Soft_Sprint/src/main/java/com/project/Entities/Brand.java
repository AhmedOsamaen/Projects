package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Brand {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	public Integer getBrandId() {
		return id;
	}
	public void setBrandId(Integer brandId) {
		this.id = brandId;
	}

	private String brand_name;
	private String brand_category;
	
	
	public String getBrand_name() {
		return brand_name;
	}
	public void setBrand_name(String brand_name) {
		this.brand_name = brand_name;
	}
	public String getBrand_category() {
		return brand_category;
	}
	public void setBrand_category(String brand_category) {
		this.brand_category = brand_category;
	}
	
	public Brand()
	{
		this.brand_category=" ";
		this.brand_name=" ";
		this.id=0;
		
	}
	public Brand(Integer id, String brand_name, String brand_category) {
		super();
		this.id = id;
		this.brand_name = brand_name;
		this.brand_category = brand_category;
	}
	
}
