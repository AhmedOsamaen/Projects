package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Store {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String Store_name;
	private String Store_location;
	private String Store_category;
	private Boolean approve;
	private Integer Owner_id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStore_name() {
		return Store_name;
	}

	public void setStore_name(String store_name) {
		Store_name = store_name;
	}

	public String getStore_location() {
		return Store_location;
	}

	public void setStore_location(String store_location) {
		Store_location = store_location;
	}

	public String getStore_category() {
		return Store_category;
	}

	public void setStore_category(String store_category) {
		Store_category = store_category;
	}

	public Boolean getApprove() {
		return approve;
	}

	public void setApprove(Boolean approve) {
		this.approve = approve;
	}

	public Integer getOwner_id() {
		return Owner_id;
	}

	public void setOwner_id(Integer owner_id) {
		Owner_id = owner_id;
	}

	public Store() {
		this.Store_name = " ";
		this.Store_category = " ";
		this.Store_location = " ";
		this.approve = false;
	}

	public Store(Integer id, String store_name, String store_location, String store_category, Boolean approve,
			Integer owner_id) {
		super();
		this.id = id;
		Store_name = store_name;
		Store_location = store_location;
		Store_category = store_category;
		this.approve = approve;
		Owner_id = owner_id;
	}

}
