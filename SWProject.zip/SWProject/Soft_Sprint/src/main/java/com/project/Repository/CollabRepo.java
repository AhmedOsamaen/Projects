package com.project.Repository;
import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Collaborator;


public interface CollabRepo extends CrudRepository<Collaborator, Integer> {

	Collaborator findByid(Integer id);
}
