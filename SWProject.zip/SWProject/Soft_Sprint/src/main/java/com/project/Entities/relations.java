package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class relations {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private int type;
	private int from_id;
	private int to_id;
	
	public relations()
	{
		this.from_id=0;
		this.id=0;
		this.to_id=0;
		this.type=1000;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getFrom_id() {
		return from_id;
	}
	public void setFrom_id(int from_id) {
		this.from_id = from_id;
	}
	public int getTo_id() {
		return to_id;
	}
	public void setTo_id(int to_id) {
		this.to_id = to_id;
	}
	public relations(Integer id, int type, int from_id, int to_id) {
		super();
		this.id = id;
		this.type = type;
		this.from_id = from_id;
		this.to_id = to_id;
	}
	
	

}
