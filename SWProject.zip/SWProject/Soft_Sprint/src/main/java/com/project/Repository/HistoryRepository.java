package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.History;


public interface  HistoryRepository extends CrudRepository<History, Integer>{
History	findByid(Integer id);
}