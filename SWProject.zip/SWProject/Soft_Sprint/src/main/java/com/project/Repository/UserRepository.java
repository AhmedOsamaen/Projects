package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.User;

public interface  UserRepository extends CrudRepository<User, Integer>{
	
}
