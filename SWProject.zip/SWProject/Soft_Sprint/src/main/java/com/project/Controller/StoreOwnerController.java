package com.project.Controller;

import java.util.Vector;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.Entities.Collaborator;
import com.project.Entities.History;
import com.project.Entities.Product;
import com.project.Entities.Store;
import com.project.Entities.StoreOwner;
import com.project.Entities.relations;
import com.project.Repository.BrandRepository;
import com.project.Repository.CollabRepo;
import com.project.Repository.HistoryRepository;
import com.project.Repository.ProductRepository;
import com.project.Repository.StatRepository;
import com.project.Repository.StoreOwnerRepository;
import com.project.Repository.StoreRepository;
import com.project.Repository.relationRepo;
//import com.project.Repository.relationRepo;

@Controller
public class StoreOwnerController {
	@Autowired
	private StoreOwnerRepository repo;
	@Autowired
	private ProductRepository repop;
	@Autowired
	private BrandRepository reposs;
	@Autowired
	private StoreRepository SR;
	@Autowired
	private StatRepository stat;
	@Autowired
	private HistoryRepository repoh;
	@Autowired
	private  CollabRepo reppp;
	@Autowired
	private  relationRepo repre;
	@GetMapping("/addowner")
	public String ShowUser(Model model) {
		model.addAttribute("owner", new StoreOwner());
		return "addowner";
	}

	@PostMapping("/addowner")
	public String addUser(Model model, @ModelAttribute StoreOwner owner, HttpSession session) {
		String name = owner.getName();
		// System.out.println();
		// session.setAttribute("UserIdSession", name);
		System.out.println(owner.getName());
		System.out.println("============= " + owner.getId());

		repo.save(owner);

		Iterable<StoreOwner> adminsIterable = repo.findAll();
		boolean x = false;
		for (StoreOwner a : adminsIterable) {

			if (owner.getName().equals(a.getName()) && owner.getPassword().equals(a.getPassword())) {
				System.out.println("============= " + a.getId());
				owner.setId(a.getId());
				x = true;
				break;
			}
		}
		if (x) {
			session.setAttribute("UserIdSession", owner.getId());
			System.out.println("Complete");

		} else {

			// model.addAttribute("admin", new Admin());
		}

		model.addAttribute("owner", new StoreOwner());
		return "OwnerHomePage";
	}

	@GetMapping("/showstats/{id}")
	public String ShowStat(@PathVariable("id") String StoreId, Model model) {
		int id = Integer.parseInt(StoreId);
		Store ss = SR.findByid(id);

		Iterable<Product> productIterable = repop.findAll();
		Vector<Product> products = new Vector<Product>();
		for (Product p1 : productIterable) {
			if (p1.getStoreId() == id)
				products.add(p1);
		}

		int views = 0;
		int bought = 0;
		model.addAttribute("Store_name", ss.getStore_name());
		for (int i = 0; i < products.size(); i++) {
			views += products.get(i).getProduct_views_counter();
			bought += products.get(i).getProduct_sales_counter();
		}
		model.addAttribute("product_views_counter", views);
		model.addAttribute("product_sales_counter", bought);

		return "showstats";
	}
	
	@GetMapping("/showhist/{id}")
	public String ShowHist(@PathVariable("id") String HistoryId, Model model) {
		int id = Integer.parseInt(HistoryId);
		History ss = repoh.findByid(id);

//		Iterable<Product> productIterable = repop.findAll();
//		Vector<Product> products = new Vector<Product>();
//		for (Product p1 : productIterable) {
//			if (p1.getStoreId() == id)
//				products.add(p1);
//		}
//
//		int views = 0;
//		int bought = 0;
//		model.addAttribute("Store_name", ss.getStore_name());
//		for (int i = 0; i < products.size(); i++) {
//			views += products.get(i).getProduct_views_counter();
//			bought += products.get(i).getProduct_sales_counter();
//		}
		model.addAttribute("product_name", ss.getProduct_name());
		model.addAttribute("oper", ss.getOper());

		return "showhist";
	}

	@GetMapping("/editeproduct")
	public String editeg(Model model) {
		model.addAttribute("product", new Product());
		return "editeproduct";
	}

	@PostMapping("/editeproduct")
	public String editp(Model model, @ModelAttribute Product product, HttpSession session) {
		String ID = session.getAttribute("UserIdSession").toString();
		Integer UserId = Integer.parseInt(ID);
		Product pro = repop.findByid(product.getId());
		if (pro == null) {
			System.out.println("there is no  product with this id in the DataBase");
			return "editeproduct";
		} else if (pro.getOwnerId() != UserId) {
			System.out.println("sorry you don't have this product");
			return "editeproduct";
		} else if (pro.getStoreId() != product.getStoreId()) {
			System.out.println("sorry you don't have this product in this store");
			return "editeproduct";
		} else {
			int new_number = product.getProduct_number();
			// String new_price= product.getProduct_price();
			// String newname = product.getProduct_name();
			// String new_cat = product.getProduct_category();
			// String newtype=product.getProduct_type();
			// if(new_price!=""){pro.setProduct_price(new_price);}
			// if(newname!="") {pro.setProduct_name(newname);};
			// if(new_cat!="") {pro.setProduct_category(new_cat);};
			// if(newtype!="") {pro.setProduct_type(newtype);};

			History H = new History(0, "edite", 1, UserId, product.getId(), product.getProduct_number(),
					product.getStoreId(), pro);
			// repo.save(product);
			repoh.save(H);
			// if(newname!="") {pro.setProduct_name(newname);};
			pro.setProduct_number(new_number);
			// pro.setProduct_category(new_cat);
			repop.save(pro);
			return "OwnerHomePage";
		}
	}

	@GetMapping("/deleteproduct")
	public String deleteg(Model model) {
		model.addAttribute("product", new Product());
		return "deleteproduct";
	}

	@PostMapping("/deleteproduct")
	public String deletep(Model model, @ModelAttribute Product product, HttpSession session) {
		String ID = session.getAttribute("UserIdSession").toString();
		Integer UserId = Integer.parseInt(ID);
		Product pro = repop.findByid(product.getId());
		if (pro == null) {
			System.out.println("there is no  product with this id in the DataBase");
			return "deleteproduct";
		} else if (pro.getOwnerId() != UserId) {
			System.out.println("sorry you don't have this product");
			return "deleteproduct";
		} else if (pro.getStoreId() != product.getStoreId()) {
			System.out.println("sorry you don't have this product in this store");
			return "deleteproduct";
		} else {
			History H = new History(0, "delete", 1, UserId, product.getId(), pro.getProduct_number(),
					product.getStoreId(), pro);
			// repo.save(product);
			repoh.save(H);
			// if(newname!="") {pro.setProduct_name(newname);};
			// pro.setProduct_number(new_number);
			// pro.setProduct_category(new_cat);
			pro.exsist=false;
			repop.save(pro);

			return "OwnerHomePage";
		}
	}

	@GetMapping("/undo")
	public String undpg(Model model) {
		model.addAttribute("product", new Product());
		return "undo";
	}

	@PostMapping("/undo")
	public String undop(Model model, @ModelAttribute Product product, HttpSession session) {
		String ID = session.getAttribute("UserIdSession").toString();
		Integer UserId = Integer.parseInt(ID);
		Iterable<History> productIterable = repoh.findAll();
		Product prod = new Product();
		History H = new History();

		for (History h1 : productIterable) {
			if (h1.getUser_id() == UserId && h1.getStore_id().equals(product.getStoreId()))
				prod = h1.getprod();
			H = h1;
		}
		if(H.getOper().equals("Add")) {
			prod.exsist=false;
			repop.save(prod);

		//	repop.delete(prod.getId());;
		}
		else if(H.getOper().equals("delete")) {
			prod.exsist=true;
			repop.save(prod);

		}
		else {
			prod.setProduct_number(H.num());
			repop.save(prod);
		}
		

		repoh.delete(H.getId());

		return "OwnerHomePage";
		// }
	}
	
	@GetMapping("/addcollaborator")	
	public String addcollaborator(Model model)
	{
		model.addAttribute("collaborator", new Collaborator());

		return "addcollaborator";
	}
	@PostMapping("/addcollaborator")	
	public String addcollaborator(Model model,@ModelAttribute Collaborator owner)
	{
		
		reppp.save(owner);
		model.addAttribute("collaborator", new Collaborator());
		return "OwnerHomePage";	
	}	
	
	@GetMapping("/collaboratorlogin")
	public String CollaboratorLogin(Model model) {
		model.addAttribute("collaborator", new Collaborator());
		return "collaboratorlogin";
	}

	@PostMapping("/collaboratorlogin")
	public String CollaboratorLogin(@ModelAttribute Collaborator admin, Model model, HttpSession session) {

		Iterable<Collaborator> adminsIterable = reppp.findAll();
		boolean x = false;
		for (Collaborator a : adminsIterable) {

			if (admin.getName().equals(a.getName())&&admin.getPassword().equals(a.getPassword()));
				x = true;
				break;
			}
		if (x) {
			session.setAttribute("UserIdSession", admin.getId());
			System.out.println("Complete user id = "+admin.getId());
			
			return "collaboratorpage";
		} else {
			// model.addAttribute("admin", new Admin());
			return "collaboratorlogin";
		}
	}
	@GetMapping("/relation")	
	public String relation(Model model)
	{
		
		model.addAttribute("relation", new relations());

		return "relation";
	}
	@PostMapping("/relation")	
	public String relation(Model model,@ModelAttribute relations re, HttpSession session)
	{
		//String ID=session.getAttribute("UserIdSession").toString();
		
//		Store st=SR.findByid(re.getTo_id());
//		String idd=st.getOwner_id().toString(); 
//		if(st==null)
//		{
//			return "relation";
//		}
////		if(idd!=ID) {
////			return "relation";
////		}
		repre.save(re);
		model.addAttribute("relation", new relations());
		return "home";	
	}
	
	
	@GetMapping("/ownerlogin")
	public String ShowAdminLogin(Model model) {
		model.addAttribute("owner", new StoreOwner());
		return "ownerlogin";
	}

	@PostMapping("/ownerlogin")
	public String Validate(@ModelAttribute StoreOwner admin, Model model, HttpSession session) {

		Iterable<StoreOwner> adminsIterable = repo.findAll();
		boolean x = false;
		for (StoreOwner a : adminsIterable) {

			if (admin.getName().equals(a.getName()) && admin.getPassword().equals(a.getPassword())) {
				admin.setId(a.getId());
				x = true;
				break;
			}
		}
		if (x) {
			session.setAttribute("UserIdSession", admin.getId());
			System.out.println("Complete user id = "+admin.getId());
			
			return "OwnerHomePage";
		} else {
			// model.addAttribute("admin", new Admin());
			return "ownerlogin";
		}
	}

	

}
