package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Stat;


public interface StatRepository extends CrudRepository<Stat, Integer>{
Stat findByStoreId(Integer id);

}