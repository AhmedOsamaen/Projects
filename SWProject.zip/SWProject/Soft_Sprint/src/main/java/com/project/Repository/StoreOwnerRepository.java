package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.StoreOwner;

public interface  StoreOwnerRepository extends CrudRepository<StoreOwner, Integer>{
	
}
