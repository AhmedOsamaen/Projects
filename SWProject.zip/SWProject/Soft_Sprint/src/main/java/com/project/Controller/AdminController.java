package com.project.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.project.Entities.Admin;
import com.project.Entities.Brand;
import com.project.Entities.History;
import com.project.Entities.Product;
import com.project.Entities.Store;
import com.project.Entities.Admin;
import com.project.Repository.AdminRepository;
import com.project.Repository.BrandRepository;
import com.project.Repository.ProductRepository;
import com.project.Repository.StoreRepository;
@Controller
public class AdminController {
	@Autowired
	private AdminRepository repo;
	@Autowired
	private StoreRepository repos;
	@Autowired
	private BrandRepository reposs;
	@Autowired
	private ProductRepository repop;

	@GetMapping("/addadmin")	
	public String ShowUser(Model model)
	{
		model.addAttribute("admin", new Admin());
		return "addadmin";
	}
	@PostMapping("/addadmin")	
	public String addUser(Model model,@ModelAttribute Admin admin,HttpSession session)
	{
		System.out.println(admin.getAdminname());
		System.out.println(admin.getAdminemail());		
		System.out.println(admin.getAdminpassword());
		session.setAttribute("UserIdSession", admin.getId());
		repo.save(admin);
		model.addAttribute("admin", new Admin());
		return "addadmin";		
	}
	
	
	@GetMapping("/approvestore")	
	public String StoreAprovement(Model model)
	{
		model.addAttribute("store", new Store());	
		return "approvestore";
	}
	@PostMapping("/approvestore")	
	public String storeaprovement(Model model,@ModelAttribute Store store){
		boolean b =true;
	    Store st=repos.findByid(store.getId());
	    st.setApprove(b);
	    repos.save(st);
	    return "home";
	    		
	}
	
	@GetMapping("/approveproduct")	
	public String ProductAprovement(Model model)
	{
		model.addAttribute("product", new Product());	
		return "approveproduct";
	}
	@PostMapping("/approveproduct")	
	public String Productaprovement(Model model,@ModelAttribute Product product){
		boolean b =true;
	    Product st=repop.findByid(product.getId());
	    st.setAprroved(b);
	    repop.save(st);
	    return "home";
	    		
	}
	
	@GetMapping("/addbrand")	
	public String AddBrand(Model model)
	{
		model.addAttribute("brand", new Brand());
		return "addbrand";
	}
	@PostMapping("/addbrand")	
	public String addbrand(Model model,@ModelAttribute Brand brand)
	{
		System.out.println(brand.getBrand_name());
		System.out.println(brand.getBrand_category());	
		reposs.save(brand);
		model.addAttribute("brand", new Brand());
		return "home";		
	}
	
	@GetMapping("/showproduct/{id}")
	public String ShowHist(@PathVariable("id") String ProductId, Model model) {
		int id = Integer.parseInt(ProductId);
		Product ss = repop.findByid(id);

//		Iterable<Product> productIterable = repop.findAll();
//		Vector<Product> products = new Vector<Product>();
//		for (Product p1 : productIterable) {
//			if (p1.getStoreId() == id)
//				products.add(p1);
//		}
//
//		int views = 0;
//		int bought = 0;
//		model.addAttribute("Store_name", ss.getStore_name());
//		for (int i = 0; i < products.size(); i++) {
//			views += products.get(i).getProduct_views_counter();
//			bought += products.get(i).getProduct_sales_counter();
//		}
		if(ss.isAprroved()==true)
		{model.addAttribute("product_name", ss.getProduct_name());
		model.addAttribute("product_number", ss.getProduct_number());
		model.addAttribute("product_price", ss.getProduct_price());

		return "showproduct";
		}
		else
			return "home";
	}
	
	
	@GetMapping("/adminlogin")
	public String ShowAdminLogin(Model model) {
		model.addAttribute("admin", new Admin());
		return "adminlogin";
	}
	@PostMapping("/adminlogin")
	public String Validate (@ModelAttribute Admin admin, Model model,HttpSession session){
		Iterable<Admin> adminsIterable = repo.findAll();
		boolean x =false;
		for(Admin a : adminsIterable) {
			
			if (admin.getAdminname().equals(a.getAdminname()) && admin.getAdminpassword().equals(a.getAdminpassword())){
				//System.out.println("Done");
				System.out.println(a.getAdminname());
				System.out.println(a.getAdminpassword());
				x =true;
				break;	
			}
		}
		if (x) {
			session.setAttribute("UserIdSession", admin.getId());

			System.out.println("Complete");
			return "home";
		}else {
			System.out.println(admin.getAdminname());
			System.out.println(admin.getAdminpassword());
			//model.addAttribute("admin", new Admin());
			return "adminlogin";
		}
	}

	
	
	
}
