package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Brand;


public interface  BrandRepository extends CrudRepository<Brand,Integer>{
	
	//Brand findByid(Integer id);

}
