package com.project.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.Entities.History;
import com.project.Entities.Product;
import com.project.Entities.StoreOwner;
import com.project.Repository.BrandRepository;
import com.project.Repository.HistoryRepository;
import com.project.Repository.ProductRepository;
import com.project.Repository.StoreRepository;

@Controller
public class ProductController {
	@Autowired
	private ProductRepository repo;
	@Autowired
	private HistoryRepository repoh;
	@Autowired
	private StoreRepository repos;
	@Autowired
	private BrandRepository brandRepo;

	@GetMapping("/addproduct")
	public String addproduct(Model model) {
		
		model.addAttribute("product", new Product());
		return "addproduct";
	}

	@PostMapping("/addproduct")
	public String addUser(Model model, @ModelAttribute Product product, HttpSession session) {
		if (repos.findByid(product.getStoreId()) == null) {
			System.out.println(" you don't have a store with this id");
			return "addproduct";
		} else {
			String ID = session.getAttribute("UserIdSession").toString();
			Integer UserId = Integer.parseInt(ID);
			System.out.println(" dddddddddddd = " + UserId);
			product.setOwnerId(UserId);
			repo.save(product);
			
			
//			Iterable<Product> adminsIterable = repo.findAll();
//			for (Product a : adminsIterable) {
//
//				if (product.getOwnerId().equals(a.getOwnerId()) && product.getProduct_name().equals(a.getProduct_name())&& product.getStoreId().equals(a.getStoreId())) {
//					System.out.println("============= " + a.getId());
//					product.setId(a.getId());
//					break;
//				}
//			}
//			History H = new History(0, "Add", 1, UserId, product.getId(), product.getProduct_number(), product.getStoreId(),product);
//			repoh.save(H);
//			model.addAttribute("product", new Product());
			return "OwnerHomePage";
		}
	}
}
