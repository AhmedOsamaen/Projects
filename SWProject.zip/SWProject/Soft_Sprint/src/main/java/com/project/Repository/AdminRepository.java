	package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Admin;

public interface  AdminRepository extends CrudRepository<Admin, Integer>{
	
}
