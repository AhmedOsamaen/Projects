package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Admin {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	private String adminname;
	private String adminemail;
	private String adminpassword;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getAdminemail() {
		return adminemail;
	}
	public void setAdminemail(String adminemail) {
		this.adminemail = adminemail;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	public Admin(Integer id, String adminname, String adminemail, String adminpassword) {
		super();
		this.id = id;
		this.adminname = adminname;
		this.adminemail = adminemail;
		this.adminpassword = adminpassword;
	}
	public Admin()
	{
		this.adminname="";
		this.adminemail=" ";
		this.adminpassword=" ";
	}
}
