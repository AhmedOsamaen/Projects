package com.project.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.Entities.Admin;
import com.project.Entities.Customer;
import com.project.Entities.Product;
import com.project.Entities.Store;
import com.project.Repository.CustomerRepository;
import com.project.Repository.ProductRepository;
import com.project.Repository.StoreRepository;

@Controller
public class CustomerController {
	@Autowired
	private CustomerRepository repo;
	@Autowired
	private ProductRepository repop;
	
	@GetMapping("/addcustomer")	
	public String ShowUser(Model model)
	{
		model.addAttribute("customer", new Customer());
		return "addcustomer";
	}
	@PostMapping("/addcustomer")	
	public String addUser(Model model,@ModelAttribute Customer customer)
	{
		System.out.println(customer.getName());
		System.out.println(customer.getEmail());		
		System.out.println(customer.getPassword());
		repo.save(customer);
		//model.addAttribute("customer", new Customer());
		return "addcustomer";		
	}
	
	
	
	@GetMapping("/buy")	
	public String Buy(Model model)
	{
		model.addAttribute("product", new Product());
		return "buy";
	}
	@PostMapping("/buy")	
	public String  Buy(Model model,@ModelAttribute Product product )
	{
		Product pro=repop.findByid(product.getId());
		if(pro.getProduct_number()<product.getProduct_number()) {
			System.out.println(" no");
			return "buy";
		}
		else {
			int new_number=pro.getProduct_number()-product.getProduct_number();
			int new_buy_number=pro.getProduct_sales_counter()+product.getProduct_number();
			pro.setProduct_number(new_number);
			pro.setProduct_sales_counter(new_buy_number);
			repop.save(pro);
			return "home";
		}
		
	}
		
		
		
		@GetMapping("/view")	
		public String View(Model model)
		{
			model.addAttribute("product", new Product());
			return "view";
		}
		@PostMapping("/view")	
		public String  view(Model model,@ModelAttribute Product product )
		{
			Product pro=repop.findByid(product.getId());
				int view_count=pro.getProduct_views_counter()+1;
				//int new_number=pro.getProduct_number()-product.getProduct_number();
				//int new_buy_number=pro.getProduct_sales_counter()+product.getProduct_number();
				//pro.setProduct_number(new_number);
				pro.setProduct_views_counter(view_count);
				repop.save(pro);
				return "home";
		
	}
		
		@GetMapping("/customerlogin")
		public String ShowAdminLogin(Model model) {
			model.addAttribute("admin", new Admin());
			return "customerlogin";
		}
		
		@PostMapping("/customerlogin")
		public String Validate (@ModelAttribute Customer custmoer, Model model){
			Iterable<Customer> adminsIterable = repo.findAll();
			boolean x =false;
			for(Customer a : adminsIterable) {
				
				if (custmoer.getName().equals(a.getName()) && custmoer.getPassword().equals(a.getPassword())){
					//System.out.println("Done");
					x =true;
					break;	
				}
			}
			if (x) {
				
				System.out.println("Complete");
				return "home";
			}else {
			
				//model.addAttribute("admin", new Admin());
				return "customerlogin";
			}
		}
	
}
