package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Store;

public interface StoreRepository extends CrudRepository<Store, Integer> {

	Store findByid(Integer id);
	

}
