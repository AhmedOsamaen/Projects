package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class History {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String oper;
	private Integer user;
	private Integer user_id;
	private Integer product_id;
	private Integer quantity;
	private Integer store_id;

	private String product_name;
	private String product_price;
	private String product_type;
	private String product_category;
	private Integer product_number;
	private Integer product_views_counter;
	private Integer product_sales_counter;
	private int product_assigned_brand;
	
	public History() {
		super();
		oper = "";
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_price() {
		return product_price;
	}

	public void setProduct_price(String product_price) {
		this.product_price = product_price;
	}

	public String getProduct_type() {
		return product_type;
	}

	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public Integer getProduct_number() {
		return product_number;
	}

	public void setProduct_number(Integer product_number) {
		this.product_number = product_number;
	}

	public Integer getProduct_views_counter() {
		return product_views_counter;
	}

	public void setProduct_views_counter(Integer product_views_counter) {
		this.product_views_counter = product_views_counter;
	}

	public Integer getProduct_sales_counter() {
		return product_sales_counter;
	}

	public void setProduct_sales_counter(Integer product_sales_counter) {
		this.product_sales_counter = product_sales_counter;
	}

	public int getProduct_assigned_brand() {
		return product_assigned_brand;
	}

	public void setProduct_assigned_brand(int product_assigned_brand) {
		this.product_assigned_brand = product_assigned_brand;
	}

	public String getOper() {
		return oper;
	}

	public void setOper(String oper) {
		this.oper = oper;
	}

	public Integer getUser() {
		return user;
	}

	public void setUser(Integer user) {
		this.user = user;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Integer getProduct_id() {
		return product_id;
	}

	public void setProduct_id(Integer product_id) {
		this.product_id = product_id;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getStore_id() {
		return store_id;
	}

	public void setStore_id(Integer store_id) {
		this.store_id = store_id;
	}
	
	public Integer num() {
		return this.product_number;
	}
	public Product getprod() {
		Product prod=new Product();
		prod.setId(this.product_id) ;
		prod.setOwnerId(this.user_id);
		prod.setProduct_assigned_brand(this.product_assigned_brand);
		prod.setProduct_category(this.product_category);
		prod.setProduct_name(this.product_name);
		prod.setProduct_number(this.quantity);
		prod.setProduct_price(this.product_price);
		prod.setProduct_sales_counter(this.product_sales_counter);
		prod.setProduct_type(this.product_type);
		prod.setProduct_views_counter(this.product_views_counter);
		prod.setStoreId(this.store_id);
		return prod;
		// = quantity;
		// = store_id;
		// = prod.getProduct_assigned_brand();
//		this.product_category=prod.getProduct_category();
	//	this.product_name=prod.getProduct_name();
		//this.product_number=prod.getProduct_number();
		//this.product_price=prod.getProduct_price();
		//this.product_sales_counter=prod.getProduct_sales_counter();
		//this.product_type=prod.getProduct_type();
	//	this.product_views_counter=prod.getProduct_views_counter();
	}


	public History(Integer id, String oper, Integer user, Integer user_id, Integer product_id, Integer quantity,
			Integer store_id, Product prod) {
		super();
		this.id = id;
		this.oper = oper;
		this.user = user;
		this.user_id = user_id;
		this.product_id = product_id;
		this.quantity = quantity;
		this.store_id = store_id;
		this.product_assigned_brand = prod.getProduct_assigned_brand();
		this.product_category=prod.getProduct_category();
		this.product_name=prod.getProduct_name();
		this.product_number=prod.getProduct_number();
		this.product_price=prod.getProduct_price();
		this.product_sales_counter=prod.getProduct_sales_counter();
		this.product_type=prod.getProduct_type();
		this.product_views_counter=prod.getProduct_views_counter();
	}

}
