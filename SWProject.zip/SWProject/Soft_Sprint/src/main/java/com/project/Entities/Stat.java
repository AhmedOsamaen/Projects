package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Stat {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private Integer storeId;
	private Integer views_number;
	private Integer bought_number;
	
	public Stat()
	{
		this.id=0;
		this.storeId=0;
		this.bought_number=0;
		this.views_number=0;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Integer getViews_number() {
		return views_number;
	}

	public void setViews_number(Integer views_number) {
		this.views_number = views_number;
	}

	public Integer getBought_number() {
		return bought_number;
	}

	public void setBought_number(Integer bought_number) {
		this.bought_number = bought_number;
	}

	public Stat(Integer id, Integer storeId, Integer views_number, Integer bought_number) {
		super();
		this.id = id;
		this.storeId = storeId;
		this.views_number = views_number;
		this.bought_number = bought_number;
	}
	
	
	
	
}
