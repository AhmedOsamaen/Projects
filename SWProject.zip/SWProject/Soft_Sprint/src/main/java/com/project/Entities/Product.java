package com.project.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

	@Entity
public class Product {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private String product_name;
	private String product_price;
	private String product_type;
	private String product_category;
	private Integer product_number;
	private Integer OwnerId;
	private Integer StoreId;
	private Integer product_views_counter;
	private Integer product_sales_counter;
	private int product_assigned_brand;
	public boolean exsist=true;
	public boolean aprroved;
	public boolean isAprroved() {
		return aprroved;
	}
	public void setAprroved(boolean aprroved) {
		this.aprroved = aprroved;
	}
	public Integer getProduct_views_counter() {
		return product_views_counter;
	}
	public void setProduct_views_counter(Integer product_views_counter) {
		this.product_views_counter = product_views_counter;
	}
	public Integer getProduct_sales_counter() {
		return product_sales_counter;
	}
	public void setProduct_sales_counter(Integer product_sales_counter) {
		this.product_sales_counter = product_sales_counter;
	}
	public Product()
	{
		this.product_category=" ";
		this.product_name=" ";
		this.product_price=" ";
		this.product_type=" ";
		this.product_number=0;
		this.OwnerId=0;
		this.StoreId=0;
		this.product_views_counter=0;
		this.product_sales_counter=0;
		this.product_assigned_brand=0;
		this.aprroved=false;
	}
	
	
	
	public int getProduct_assigned_brand() {
		return product_assigned_brand;
	}
	public void setProduct_assigned_brand(int product_assigned_brand) {
		this.product_assigned_brand = product_assigned_brand;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_price() {
		return product_price;
	}
	public void setProduct_price(String product_price) {
		this.product_price = product_price;
	}
	public String getProduct_type() {
		return product_type;
	}
	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}
	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public Integer getProduct_number() {
		return product_number;
	}
	public void setProduct_number(Integer product_number) {
		this.product_number = product_number;
	}
	
	public Integer getOwnerId() {
		return OwnerId;
	}
	public void setOwnerId(Integer ownerId) {
		OwnerId = ownerId;
	}
	public Integer getStoreId() {
		return StoreId;
	}
	public void setStoreId(Integer storeId) {
		StoreId = storeId;
	}
	public Product(Integer id, String product_name, String product_price, String product_type, String product_category,
			Integer product_number, Integer ownerId, Integer storeId, Integer product_views_counter,
			Integer product_sales_counter, int product_assigned_brand) {
		super();
		this.id = id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_type = product_type;
		this.product_category = product_category;
		this.product_number = product_number;
		OwnerId = ownerId;
		StoreId = storeId;
		this.product_views_counter = product_views_counter;
		this.product_sales_counter = product_sales_counter;
		this.product_assigned_brand = product_assigned_brand;
	}
	

	
	
	
	
}
