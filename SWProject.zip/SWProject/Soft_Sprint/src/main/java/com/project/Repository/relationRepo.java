package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.relations;

public interface relationRepo extends CrudRepository<relations, Integer> {
	relations findByid(Integer id);

}
