package com.project.Repository;

import org.springframework.data.repository.CrudRepository;

import com.project.Entities.Customer;

public interface  CustomerRepository extends CrudRepository<Customer, Integer>{
	
}
