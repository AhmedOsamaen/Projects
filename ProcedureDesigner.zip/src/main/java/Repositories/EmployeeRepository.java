package Repositories;

import Entities.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.List;

public class EmployeeRepository implements Repository<Employee,Integer> {
    AnnotationConfiguration config = new AnnotationConfiguration();
    SessionFactory factory= config.configure().buildSessionFactory();
    Session session = factory.getCurrentSession();
    public void Insert(Employee T) {
        try {
            session = factory.getCurrentSession();
            config.addAnnotatedClass(Employee.class);
            session.beginTransaction();
            session.save(T);
            session.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("Error " + e);
            session.close();
        }
    }

    public Employee Read(Integer integer) {
        return null;
    }

    public List<Employee> ReadAll() {
        try {
            session = factory.openSession();
            config.addAnnotatedClass(Employee.class);
            session.beginTransaction();
            org.hibernate.Query queryResult = session.createQuery("from Employee");

            List<Employee> allEmployees = queryResult.list();
            session.close();
            return allEmployees;
        }catch (Exception e){
            System.out.println(e);
            session.close();
            return null;
        }
    }

    public void Update(Employee t) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(Employee.class);
        session.beginTransaction();
        session.update(t);
        session.getTransaction().commit();
//        session.close();

    }


}
