package Repositories;

import Entities.Activity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import java.util.ArrayList;
import java.util.List;

public class ActivityRepository implements Repository<Activity, Integer> {
    AnnotationConfiguration config = new AnnotationConfiguration();
    SessionFactory factory= config.configure().buildSessionFactory();
    Session session = factory.getCurrentSession();
    public void Insert(Activity T) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(Activity.class);
        session.beginTransaction();
        session.save(T);
        session.getTransaction().commit();

    }

    public Activity Read(Integer integer) {
        return null;
    }

    public List<Activity> ReadAll() {

        session = factory.openSession();
        config.addAnnotatedClass(Activity.class);
        org.hibernate.Query queryResult = session.createQuery("from Activity");
        session.beginTransaction();

        List<Activity> allActivities = queryResult.list();
        session.close();
        return allActivities;
    }

    public void Update(Activity t) {

    }
}
