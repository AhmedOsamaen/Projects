package Repositories;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import java.util.List;

public interface Repository <Type,ID> {
    public void Insert (Type T);
    public Type Read (ID id);
    public List<Type> ReadAll();
    public void Update(Type t);


}
