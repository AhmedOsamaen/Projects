package Repositories;

import Entities.Process;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;


import java.util.List;


public class ProcessRepository implements Repository<Process ,Integer> {
    AnnotationConfiguration config = new AnnotationConfiguration();
    SessionFactory factory= config.configure().buildSessionFactory();
    Session session = factory.getCurrentSession();
    public void Insert(Process T) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(Process.class);
        session.beginTransaction();
        session.save(T);
        session.getTransaction().commit();
    }

    public Process Read(Integer integer) {
        return null;
    }

    public List<Process> ReadAll() {
        session = factory.getCurrentSession();
        session.beginTransaction();
        org.hibernate.Query queryResult = session.createQuery("from Process");
        List<Entities.Process> allActivities = queryResult.list();
        session.close();
        return allActivities;


      /*  session = factory.getCurrentSession();
        config.addAnnotatedClass(Process.class);
        session.beginTransaction();
        session.getTransaction().commit();
        org.hibernate.Query queryResult = session.createQuery("from Process");
      //  session.beginTransaction();

        List<Process> allActivities = queryResult.list();
        //session.close();
        return allActivities;*/
    }

    public void Update(Process t) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(Process.class);
        session.beginTransaction();
        session.update(t);
        session.getTransaction().commit();
//        session.close();

    }
}
