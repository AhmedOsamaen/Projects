package Repositories;

import Entities.Task_;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import java.util.List;

public class TaskRepository implements Repository<Task_,Integer> {
    AnnotationConfiguration config = new AnnotationConfiguration();
    SessionFactory factory= config.configure().buildSessionFactory();
    Session session = factory.getCurrentSession();
    @Override
    public void Insert(Task_ T) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(Task_.class);
        session.beginTransaction();
        session.save(T);
        session.getTransaction().commit();
    }

    @Override
    public Task_ Read(Integer integer) {
        return null;
    }

    @Override
    public List<Task_> ReadAll() {
        session = factory.openSession();
        config.addAnnotatedClass(Task_.class);
        org.hibernate.Query queryResult = session.createQuery("from Task_");
        session.beginTransaction();

        List<Task_> tasks = queryResult.list();
        session.close();
        return tasks;
    }

    @Override
    public void Update(Task_ t) {

    }
}
