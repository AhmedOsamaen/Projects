package Repositories;

import Entities.SubProcess;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import java.util.ArrayList;
import java.util.List;

public class SubProcessRepository implements Repository<SubProcess,Integer> {
    AnnotationConfiguration config = new AnnotationConfiguration();
    SessionFactory factory= config.configure().buildSessionFactory();
    Session session = factory.getCurrentSession();
    public void Insert(SubProcess T) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(SubProcess.class);
        session.beginTransaction();
        session.save(T);
        session.getTransaction().commit();
    }

    public SubProcess Read(Integer integer) {
        return null;
    }

    public List<SubProcess> ReadAll() {
        session = factory.openSession();
        config.addAnnotatedClass(SubProcess.class);
        org.hibernate.Query queryResult = session.createQuery("from SubProcess");
        session.beginTransaction();

        List<SubProcess> allSubProcesses = queryResult.list();
        session.close();
        return allSubProcesses;
    }

    public void Update(SubProcess t) {
        session = factory.getCurrentSession();
        config.addAnnotatedClass(SubProcess.class);
        session.beginTransaction();
        session.update(t);
        session.getTransaction().commit();
    }
}
