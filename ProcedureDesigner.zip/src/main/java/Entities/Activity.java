package Entities;

import javax.annotation.Nullable;
import javax.persistence.Entity;
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.sun.xml.internal.ws.policy.sourcemodel.wspolicy.XmlToken.Name;

@Entity
public class Activity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int ID;
    @Column(columnDefinition="text")
    private String ShortDescription = "";;
    @Column(columnDefinition="text")
    private String Description = "";;
    private String Category= "";;
    private String STD= "";;
    public int level_num = 0;


    @Nullable
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name="Activity_Process" , joinColumns = @JoinColumn(name ="ActivityID"),
            inverseJoinColumns = @JoinColumn(name ="ProcessID"))
    Set<Process>processes=new HashSet<Process>();




    @Nullable
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name="Activity_SubProcess" , joinColumns = @JoinColumn(name ="ActivityID"),
            inverseJoinColumns = @JoinColumn(name ="SubProcessID"))
    Set <SubProcess>subProcesses=new HashSet<SubProcess>();;
    private String language;
    public Activity() {
        language = "EN";
    }

    public Activity(int ID, String shortDescription, String description, String category, String STD) {
        this.ID = ID;
        ShortDescription = shortDescription;
        Description = description;
        Category = category;
        this.STD = STD;
        language = "EN";

    }

    public Activity(String shortDescription, String description, String category, String STD) {
        ShortDescription = shortDescription;
        Description = description;
        Category = category;
        this.STD = STD;
        language = "EN";

    }


    public Activity(String name, int id, String description, int levelnum) {
        this.ShortDescription = name;
        this.ID = id;
        this.Description = description;
        this.level_num = levelnum;
        language = "EN";

    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getShortDescription() {
        return ShortDescription;
    }

    public void setShortDescription(String shortDescription) {
        ShortDescription = shortDescription;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getSTD() {
        return STD;
    }

    public void setSTD(String STD) {
        this.STD = STD;
    }

    public Set<Process> getProcesses() {
        return processes;
    }

    public void setProcesses(Set<Process> processes) {
        this.processes = processes;
    }

    public Set<SubProcess> getSubProcesses() {
        return subProcesses;
    }

    public void setSubProcesses(Set<SubProcess> subProcesses) {
        this.subProcesses = subProcesses;
    }

    public Activity(Activity a) {
        //for (int i = 0; i < a.Responsible.size(); i++) {
        //Employee em = new Employee(a.Responsible.get(i));
        //  this.Responsible.add(em);
        //}
        this.ShortDescription = new String(a.ShortDescription);
        this.Description = new String(a.Description);
        this.ID = new Integer(a.ID);
        this.level_num = new Integer(a.level_num);
        this.STD = new String(a.STD);
        //this.OutputName = new String(a.OutputName);
    }

    public void ClearChildern(){
        this.subProcesses.clear();
        this.processes.clear();
    }

    public void Get_Info(String x) {
        if (subProcesses.size() > 0) {
            List<SubProcess>subs=new ArrayList<SubProcess>(subProcesses);
            System.out.print(x + "- " + Name + "( Activity ) and assigned to [");
            for (int i = 0; i < subs.size(); i++) {
                if (i == subs.size() - 1) {
                    System.out.println(subs.get(i).getShortDescription() + " ]");
                } else {
                    System.out.print(subs.get(i).getShortDescription() + " - ");
                }
            }
        } else {
            System.out.println(x + "- " + Name + "( Activity )");
        }
    }
}