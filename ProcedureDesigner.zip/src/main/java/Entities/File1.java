package Entities;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.io.Serializable;

@Entity
public class File1 implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "idfiles")
    private int idfiles;
    @Column( name = "files")
    private byte[] files;
    @Column(name="name")

    private String name ;
    @Column(name="type")

    private int type;

    public File1 () {

    }
    public File1(File1 f) {
        this.idfiles = f.idfiles;
        this.files = f.files;
        this.name = f.name;
        this.type = f.type;
    }



    public void setType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdfiles() {
        return idfiles;
    }

    public void setIdfiles(int idfiles) {
        this.idfiles = idfiles;
    }

    public void setFiles(byte[] files) {
        this.files = files;
    }


    public byte[] getFiles() {
        return files;
    }
}
