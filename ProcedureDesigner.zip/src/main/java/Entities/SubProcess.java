package Entities;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
@Entity
public class SubProcess implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int ID ;
    public int level_num=0;
    private String Name= "";
    private String STD ="";
    private String Category = "";
    @Column(columnDefinition="text")
    private String ShortDescription = "";
    @Column(columnDefinition="text")
    private  String Description= "";;
    @Nullable
    @OneToOne(optional = true, fetch = FetchType.LAZY )
    private SubProcess child ;
    @Nullable
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name="Process_SubProcess" , joinColumns = @JoinColumn(name ="SubProcessID"),
            inverseJoinColumns = @JoinColumn(name ="ProcessID"))
    Set<Process>processes;
    @Nullable
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name="Activity_SubProcess" , joinColumns = @JoinColumn(name ="SubProcessID"),
            inverseJoinColumns = @JoinColumn(name ="ActivityID"))
    Set<Activity>activities=new HashSet<Activity>();
    @Nullable
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name="SubProcess_Employee" , joinColumns = @JoinColumn(name ="SubProcessID"),
            inverseJoinColumns = @JoinColumn(name ="EmployeeID"))
    Set<Employee>employees=new HashSet<Employee>();

    @Nullable
    private String language;
    private  boolean childFlag;

    public boolean isChildFlag() {
        return childFlag;
    }

    public void setChildFlag(boolean childFlag) {
        this.childFlag = childFlag;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public SubProcess() {
        language = "EN";
    }
    public SubProcess(String name, int id, String description, int levels_num) {
        this.Name = name;
        this.ShortDescription = name;

        this.ID = id;
        this.Description = description;
        this.level_num = levels_num;
        child = null;
        language = "EN";

    }
    public SubProcess(int ID, String name, String STD, String category, String shortDescription, String description, SubProcess child) {
        this.ID = ID;
        Name = name;
        this.STD = STD;
        Category = category;
        ShortDescription = shortDescription;
        Description = description;
        this.child = child;
        language = "EN";

    }

    public SubProcess(String name, String STD, String category, String shortDescription, String description) {
        Name = name;
        this.STD = STD;
        Category = category;
        ShortDescription = shortDescription;
        Description = description;
        child = null;
        language = "EN";

    }

    public SubProcess(String name, String STD, String category, String shortDescription, String description, SubProcess child) {
        Name = name;
        this.STD = STD;
        Category = category;
        ShortDescription = shortDescription;
        Description = description;
        this.child = child;
        language = "EN";

    }

    public SubProcess(SubProcess s) {

        this.Name = new String(s.Name);
        this.Description = new String(s.Description);
        this.ID = new Integer(s.ID);
        this.ShortDescription = new String(s.ShortDescription);
        this.level_num = new Integer(s.level_num);
        this.STD = new String(s.STD);
        language = "EN";

    }

    public int getLevel_num() {
        return level_num;
    }

    public void setLevel_num(int level_num) {
        this.level_num = level_num;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getShortDescription() {
        return ShortDescription;
    }

    public void setShortDescription(String shortDescription) {
        ShortDescription = shortDescription;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public SubProcess getChild() {
        return child;
    }

    public void setChild(SubProcess child) {
        this.child = child;
    }

    public Set<Process> getProcesses() {
        return processes;
    }

    public void setProcesses(Set<Process> processes) {
        this.processes = processes;
    }

    public Set<Activity> getActivities() {
        return activities;
    }

    public void setActivities(Set<Activity> activities) {
        this.activities = activities;
    }

    public Set<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<Employee> employees) {
        this.employees = employees;
    }

    public String getSTD() {
        return STD;
    }

    public void setSTD(String STD) {
        this.STD = STD;
    }

    public void ClearChildern(){
        this.activities.clear();
        this.employees.clear();
        this.child = null;
    }

    public void Get_Info(String x) {
        System.out.println(x + "- " + Name + "( SubProcess )");
        List<Activity> Activities=new ArrayList<Activity>(activities);
        for (int i = 0; i < Activities.size(); i++) {
            Activities.get(i).Get_Info(x + "   ");
        }
        if (child != null) {
            child.Get_Info(x + "   ");
        }

    }
}
