package sample;
public class Image {
    public static javafx.scene.image.Image image = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/icon.png"), 50, 50, false, true);
    public static javafx.scene.image.Image image2 = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/iconA.png"), 40, 40, false, true);
    public static javafx.scene.image.Image imageAC = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/iconAc.png"), 40, 40, false, true);
    public static javafx.scene.image.Image imageMain = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/icon_main.png"), 40, 40, false, true);
    public static javafx.scene.image.Image imagewndow = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/icons8.png"), 40, 40, false, true);
    public static javafx.scene.image.Image imageNew = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/New2.png"), 25, 25, false, true);

}

