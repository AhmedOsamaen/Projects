package sample;

import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.text.Font;

public class GUI_Comp {

    public static Menu RecentOpenn = new Menu("RecentOpen");

    public static Label JobTitleL = new Label("Job Title");
    public static Label JobTypeL = new Label("Job Type");
    public static Label JobLocationL = new Label("Job Location");
    public static Label JobManagerL = new Label("Supervisor/Manager");
    public static Label LanguagesL = new Label("Languages");
    public static Label ExperienceL = new Label("Experience");
    public static Label JobQualificationL = new Label("Qualifications");
    public static Label SkillsL = new Label("Skills");
    public static Label PDescriptionL = new Label("Procedure Description");
    public static Label POwnerL = new Label("Procedure Owner");
    public static Label PSNameL = new Label("Procedure Name");
    public static Label PShortDL = new Label("Procedure Short Description");
    public static Label PVersionL = new Label("Procedure Version");
    public static Label langChoice= new Label("SubProcess Language");
    public static ChoiceBox langCat=new ChoiceBox();

    public static Label SDescribtionL = new Label("New SubProcess");
    public static Label SdescriptionL = new Label("SubProcess Description");
    public static Label SCategoryL = new Label("SubProcess Category");
    public static Label SNameL = new Label("SubProcess Name");
    public static Label SSTDL = new Label("SubProcess standard");
    public static Label SShortDL = new Label("SubProcess Short Description");

    public static TextField Sdescription = new TextField();
    public static TextField SCategory = new TextField();
    public static TextField SName = new TextField();
    public static ComboBox SSTD = new ComboBox();
    public static TextField SShortD = new TextField();

    public static Label SDescribtionL2 = new Label("New SubProcess");
    public static Label SdescriptionL2 = new Label("SubProcess Description");
    public static Label SCategoryL2 = new Label("SubProcess Category");
    public static Label SNameL2 = new Label("SubProcess Name");
    public static Label SSTDL2 = new Label("SubProcess standard");
    public static Label SShortDL2 = new Label("SubProcess Short Description");

    public static TextField Sdescription2 = new TextField();
    public static TextField SCategory2 = new TextField();
    public static TextField SName2 = new TextField();
    public static ComboBox SSTD2 = new ComboBox();
    public static TextField SShortD2 = new TextField();
    public static Label langChoice2= new Label("SubProcess Language");
    public static ChoiceBox langCat2=new ChoiceBox();


    public static Label Pdescription = new Label("Operating Procedure");
    public static Label Jobdescription = new Label("Job Description");
    public static TextField JobTitle = new TextField();
    public static ComboBox JobType = new ComboBox();

    public static ComboBox JobLocation = new ComboBox();
    public static TextField JobManager = new TextField();
    public static ComboBox Languages = new ComboBox();
    public static ComboBox Experience = new ComboBox();
    public static TextArea JobQualification = new TextArea();
    public static TextArea Skills = new TextArea();
    public static TextArea PDescription = new TextArea();
    public static TextField POwner = new TextField();
    public static TextField PShortD = new TextField();
    public static TextField PVersion = new TextField();
    public static TextField PName = new TextField();
    public static Button Refresh= new Button();



    // public static Button Insert_Employee = new Button("Add JD");
    // public static Button Save_Employee_Tasks = new Button("Update JD");
    public static MenuItem Save_Process = new MenuItem("Add New Operating Procedure to Data base");
    public static MenuItem Save_Process2 = new MenuItem("Update Operating Procedure");
    public static MenuItem Insert_New_SubProcess = new MenuItem("Insert SubProcess to database");
    public static MenuItem Update_Sub_Process = new MenuItem("Update SubProcess to database");

    public static Button Generate = new Button("Generate");

    public static Group Process_Form_Root = new Group();

    public static  Group SubProcess_Form_Root = new Group();
    public static  Group SubProcess_Form_Root2 = new Group();


    GUI_Comp() {

        Process_Form_Root.getChildren().add(Pdescription);
        Process_Form_Root.getChildren().add(PDescription);
        Process_Form_Root.getChildren().add(PDescriptionL);
        Process_Form_Root.getChildren().add(PShortD);
        Process_Form_Root.getChildren().add(PShortDL);
        Process_Form_Root.getChildren().add(PName);
        Process_Form_Root.getChildren().add(PSNameL);
        Process_Form_Root.getChildren().add(POwnerL);
        Process_Form_Root.getChildren().add(POwner);
        Process_Form_Root.getChildren().add(PVersionL);
        Process_Form_Root.getChildren().add(PVersion);
        // Process_Form_Root.getChildren().add(Save_Process);
        // Process_Form_Root.getChildren().add(Save_Process2);


        SubProcess_Form_Root.getChildren().add(SDescribtionL);
        SubProcess_Form_Root.getChildren().add(SdescriptionL);
        SubProcess_Form_Root.getChildren().add(Sdescription);
        SubProcess_Form_Root.getChildren().add(SShortDL);
        SubProcess_Form_Root.getChildren().add(SShortD);
        SubProcess_Form_Root.getChildren().add(SCategoryL);
        SubProcess_Form_Root.getChildren().add(SCategory);
        SubProcess_Form_Root.getChildren().add(SNameL);
        SubProcess_Form_Root.getChildren().add(SName);
        SubProcess_Form_Root.getChildren().add(SSTDL);
        SubProcess_Form_Root.getChildren().add(SSTD);
        SubProcess_Form_Root.getChildren().add(langChoice);
        SubProcess_Form_Root.getChildren().add(langCat);


        SubProcess_Form_Root2.getChildren().add(SDescribtionL2);
        SubProcess_Form_Root2.getChildren().add(SdescriptionL2);
        SubProcess_Form_Root2.getChildren().add(Sdescription2);
        SubProcess_Form_Root2.getChildren().add(SShortDL2);
        SubProcess_Form_Root2.getChildren().add(SShortD2);
        SubProcess_Form_Root2.getChildren().add(SCategoryL2);
        SubProcess_Form_Root2.getChildren().add(SCategory2);
        SubProcess_Form_Root2.getChildren().add(SNameL2);
        SubProcess_Form_Root2.getChildren().add(SName2);
        SubProcess_Form_Root2.getChildren().add(SSTDL2);
        SubProcess_Form_Root2.getChildren().add(SSTD2);
        SubProcess_Form_Root2.getChildren().add(langChoice2);
        SubProcess_Form_Root2.getChildren().add(langCat2);

        // SubProcess_Form_Root.getChildren().add(Update_Sub_Process);
        //SubProcess_Form_Root.getChildren().add(Insert_New_SubProcess);


        // Save_Process.setTranslateX(1210);
        //Save_Process.setTranslateY(130);
       // Save_Process2.setTranslateX(1210);
        //Save_Process2.setTranslateY(80);

        // Refresh.setTranslateX(1210);
        //Refresh.setTranslateY(80);


        Jobdescription.setTranslateX(250);
        Jobdescription.setTranslateY(0);
        Jobdescription.setFont(Font.font(18));
        JobTitleL.setTranslateX(250);
        JobTitleL.setTranslateY(40);
        JobTitle.setPromptText("Ex:IT Administrator .");
        JobTitle.setTranslateX(250);
        JobTitle.setTranslateY(70);
        JobTitle.setMaxWidth(150);
        JobType.setMaxWidth(150);
        JobType.setTranslateX(250);
        JobType.setTranslateY(140);
        JobType.setPromptText("Ex:Full Time .");
        JobTypeL.setTranslateX(250);
        JobTypeL.setTranslateY(110);
        JobLocationL.setTranslateX(250);
        JobLocationL.setTranslateY(180);
        JobLocation.setMaxWidth(150);
        JobLocation.setTranslateX(250);
        JobLocation.setTranslateY(210);
        JobLocation.setPromptText("Ex:Cairo/Egypt .");
        JobManagerL.setTranslateX(250);
        JobManagerL.setTranslateY(250);
        JobManager.setMaxWidth(150);
        JobManager.setTranslateX(250);
        JobManager.setTranslateY(280);
        JobManager.setPromptText("EX:IT Infrastructure Head .");
        LanguagesL.setTranslateX(250);
        LanguagesL.setTranslateY(320);
        Languages.setTranslateX(250);
        Languages.setTranslateY(350);
        Languages.setMaxWidth(150);
        ExperienceL.setTranslateX(250);
        ExperienceL.setTranslateY(390);
        Experience.setMaxWidth(150);
        Experience.setTranslateX(250);
        Experience.setTranslateY(420);
        Experience.setPromptText("Ex:3-5 Years .");
        JobQualificationL.setTranslateX(250);
        JobQualificationL.setTranslateY(460);//400
        JobQualification.setTranslateX(250);
        JobQualification.setTranslateY(490);//430
        JobQualification.setPrefRowCount(2);
        JobQualification.setMaxSize(200, 60);
        JobQualification.setWrapText(true);
        Skills.setTranslateX(250);
        Skills.setTranslateY(580);//570
        Skills.setPrefRowCount(2);
        Skills.setMaxSize(200, 60);
        Skills.setPromptText("Ex: Team work, work under pressure .");
        Skills.setWrapText(true);
        SkillsL.setTranslateX(250);
        SkillsL.setTranslateY(550);//540

        // Languages.setPromptText("Ex:English - Arabic .");
        Pdescription.setTranslateX(250);
        Pdescription.setTranslateY(0);
        Pdescription.setFont(Font.font(18));
        SDescribtionL.setTranslateX(250);
        SDescribtionL.setTranslateY(0);
        SDescribtionL.setFont(Font.font(18));



        PShortDL.setTranslateX(250);
        PShortDL.setTranslateY(110);
        PShortD.setTranslateX(250);
        PShortD.setTranslateY(140);

        POwnerL.setTranslateX(250);
        POwnerL.setTranslateY(180);
        POwner.setTranslateX(250);
        POwner.setTranslateY(210);

        PVersionL.setTranslateX(250);
        PVersionL.setTranslateY(250);
        PVersion.setTranslateX(250);
        PVersion.setTranslateY(280);

        PSNameL.setTranslateX(250);
        PSNameL.setTranslateY(40);
        PName.setTranslateX(250);
        PName.setTranslateY(70);
        PDescriptionL.setTranslateX(250);
        PDescriptionL.setTranslateY(320);
        PDescription.setMaxSize(150, 70);
        PDescription.setWrapText(true);
        PDescription.setPrefRowCount(3);
        PDescription.setTranslateX(250);
        PDescription.setTranslateY(350);

        SdescriptionL.setTranslateX(250);
        SdescriptionL.setTranslateY(40);
        Sdescription.setTranslateX(250);
        Sdescription.setTranslateY(70);

        SdescriptionL2.setTranslateX(1);
        SdescriptionL2.setTranslateY(40);
        Sdescription2.setTranslateX(1);
        Sdescription2.setTranslateY(70);


        SCategoryL.setTranslateX(250);
        SCategoryL.setTranslateY(110);
        SCategory.setTranslateX(250);
        SCategory.setTranslateY(140);

        SCategoryL2.setTranslateX(1);
        SCategoryL2.setTranslateY(110);
        SCategory2.setTranslateX(1);
        SCategory2.setTranslateY(140);

        SNameL.setTranslateX(250);
        SNameL.setTranslateY(180);
        SName.setTranslateX(250);
        SName.setTranslateY(210);

        SNameL2.setTranslateX(1);
        SNameL2.setTranslateY(180);
        SName2.setTranslateX(1);
        SName2.setTranslateY(210);


        SShortDL.setTranslateX(250);
        SShortDL.setTranslateY(250);
        SShortD.setTranslateX(250);
        SShortD.setTranslateY(280);

        SShortDL2.setTranslateX(1);
        SShortDL2.setTranslateY(250);
        SShortD2.setTranslateX(1);
        SShortD2.setTranslateY(280);

        SSTDL.setTranslateX(250);
        SSTDL.setTranslateY(320);
        SSTD.setTranslateX(250);
        SSTD.setTranslateY(350);
        SSTD.setMaxWidth(150);

        SSTDL2.setTranslateX(1);
        SSTDL2.setTranslateY(320);
        SSTD2.setTranslateX(1);
        SSTD2.setTranslateY(350);
        SSTD2.setMaxWidth(150);


        langCat.setTranslateX(250);
        langCat.setTranslateY(420);
        langCat.setMaxWidth(150);
        langChoice.setTranslateX(250);
        langChoice.setTranslateY(390);

        langCat2.setTranslateX(1);
        langCat2.setTranslateY(420);
        langCat.setMaxWidth(150);
        langChoice2.setTranslateX(1);
        langChoice2.setTranslateY(390);

        Generate.setTranslateX(1210);
        Generate.setTranslateY(650);
    }
}
