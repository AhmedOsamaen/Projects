package sample;
import Entities.*;
import Entities.Process;
import javafx.scene.control.TreeItem;

import java.io.Serializable;

public class Modi_Tree<T> extends TreeItem<T> implements Serializable {

    String NAAAMe;
    String Desc = "_____---";
    int Level;
    Process MP = null;
    SubProcess SP = null;
    Activity AC = null;
    Employee EM = null;
    Task_ TA=null;
    File1 f = null;


}