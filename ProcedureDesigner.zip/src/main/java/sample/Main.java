package sample;
//import Images_And_Icons;

import Not_Used.ConfirmBox2;
//import Not_Used.ConfirmBoxArabic;
import Controller.DB;
//import sample.
import Entities.*;
import Entities.Activity;
import Entities.Employee;
import Entities.SubProcess;
import Entities.Task_;
import Entities.Process;
import Not_Used.ConfirmBox;
import Repositories.FileRepository;
import Repositories.Repository;
import javafx.application.Application;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.concurrent.Task;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.EventHandler;
import javafx.geometry.*;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.beans.value.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.input.*;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;


//import org.apache.poi.xwpf.usermodel.*;
//import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTBookmark;
//import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTP;

import javax.imageio.ImageIO;

import static sample.GUI_Comp.*;


public class Main extends Application {

    public static Modi_Line Dummy_Line = new Modi_Line(3);

    public static Boolean prcess_form_Flag = false;
    public static Boolean subProcess_form_flag = false;

    public static Modi_TreeTable ProcessTree = new Modi_TreeTable();
    public static Modi_TreeTable EmployeesTree = new Modi_TreeTable();
    public static Modi_TreeTable TasksTree = new Modi_TreeTable();
    public static Modi_TreeTable DurationTree = new Modi_TreeTable();

    public static Scene sx;
    public static Process MainProcess;
    public static BorderPane layout = new BorderPane();
    public static Vector<Modi_Label> Labels_vector = new Vector<Modi_Label>();
    public static Vector<Modi_Line> Lines_vector = new Vector<Modi_Line>();
    private FileChooser fc = new FileChooser();
    public static Boolean EmployeeScene = false;
    public static boolean obsence = false;

    public static int start = -1;
    public static History H = new History();
    public static Group root = new Group();
    //  public static Group root2 = new Group();
    public static MouseGestures mg = new MouseGestures();
    public static boolean DeleteOn = false;
    public static boolean LinkOn = false;

    public static MenuItem Delete = new MenuItem("Delete Alt");
    public static MenuItem Link = new MenuItem("Link Shift");
    public static MenuItem print = new MenuItem("Print");

    public static String addressoben = "";
    public static String addresssave = "";
    public static boolean araabc = false;
    //  public static List<XWPFParagraph> paragraphs1;
    public static ArrayList<String> results = new ArrayList<>();
    public static ArrayList<String> Arr = new ArrayList<>();
    public static GUI_Comp GUI = new GUI_Comp();
    private FileChooser fcWord = new FileChooser();
    public static Modi_Tree DragedTreeItem = null;
    Template template;

    Menu fleMenue = new Menu("File");
    Menu fleMenue1 = new Menu("Edit");
    Menu fleMenue2 = new Menu("Action");
    Menu fleMenue3 = new Menu("View");
    public static Menu fleMenue4 = new Menu("Generate");
    Menu fleMenue5 = new Menu("Help");
    Menu language = new Menu("Language");
    Menu New = new Menu("New");
    public static Menu Operation = new Menu("Operation");

    MenuItem Save_Employee_Tasks = new MenuItem("Update JD");
    MenuItem Insert_Employee = new MenuItem("Add JD to Database");
    MenuItem arabic = new MenuItem("Arabic");
    MenuItem english = new MenuItem("English");
    MenuItem savee = new MenuItem("Save");
    MenuItem saveeAs = new MenuItem("Save as");
    MenuItem openn = new MenuItem("Open");
    MenuItem close = new MenuItem("Close");
    MenuItem exit = new MenuItem("Exit");

    MenuItem Undo = new MenuItem("Undo Ctrl+Z");
    MenuItem Redo = new MenuItem("Redo Ctrl+X");

    MenuItem zoomInMenuItem = new MenuItem("Zoom In");
    MenuItem zoomOutMenuItem = new MenuItem("Zoom Out");

    MenuItem GenerateOP = new MenuItem("Generate OP");
    MenuItem GenerateJD = new MenuItem("Generate JD");
    MenuItem GeneratePdf = new MenuItem("Generate PDF");

    MenuItem Help = new MenuItem("Open Help file");
    public static Stage stagedummy;
    MenuItem newob = new MenuItem("OP");
    MenuItem newjb = new MenuItem("JD");
    List<String> validExtensions = Arrays.asList("opd", "jd");
    public static Button checkButton = new Button("NOT SAVED");

    Button btnn = new Button("Add new sub process");


    public static void main(String[] args) {
        Application.launch(args);
    }


    @Override
    public void start(Stage stage) throws IOException {
        stagedummy=stage;
        Languages.getItems().clear();
        //    paragraphs1 = SaveToWord();
        langCat.getItems().add("English");
        langCat.getItems().add("Arabic");
        langCat.setValue("English");
        langCat2.getItems().add("English");
        langCat2.getItems().add("Arabic");
        langCat2.setValue("English");
        SSTD.setEditable(true);
        SSTD2.setEditable(true);

        JobType.setEditable(true);
        JobLocation.setEditable(true);
        Experience.setEditable(true);
        Languages.setEditable(true);

        oPenProgram(RecentOpenn, Labels_vector, Lines_vector, stage);


        btnn.setOnAction(
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        final Stage dialog = new Stage();
                        int y=120;
                        int x=200;

                        Label ShortDescriptionL=new Label("Short Description");
                        ShortDescriptionL.setTranslateX(x);
                        ShortDescriptionL.setTranslateY(y);
                        TextField ShortDescription=new TextField();
                        ShortDescription.setTranslateX(x);
                        ShortDescription.setTranslateY(y+20);
                        ShortDescription.setMaxSize(150,2);
                        Label DescriptionL=new Label("Description");
                        DescriptionL.setTranslateX(x+150);
                        DescriptionL.setTranslateY(y);
                        TextField Description=new TextField();
                        Description.setTranslateX(x+150);
                        Description.setTranslateY(y+20);
                        Description.setMaxSize(150,2);
                        Label CategoryL=new Label("Category");
                        CategoryL.setTranslateX(x+300);
                        CategoryL.setTranslateY(y);
                        TextField Category=new TextField();
                        Category.setTranslateX(x+300);
                        Category.setTranslateY(y+20);
                        Category.setMaxSize(150,2);
                        Label STDL=new Label("Standard");
                        STDL.setTranslateX(x+450);
                        STDL.setTranslateY(y);
                        TextField STD=new TextField();
                        STD.setTranslateX(x+450);
                        STD.setTranslateY(y+20);
                        STD.setMaxSize(150,2);


                        Button add_act_to_sub=new Button("Add new sub process to DB");
                        Button Insert_sub_to_db = new Button("Add activity to sub process");
                        Label add_no_of_acts=new Label("Enter number of activities");
                        add_no_of_acts.setTranslateX(200);
                        add_no_of_acts.setTranslateY(40);
                        TextField number_of_acts=new TextField();
                        number_of_acts.setTranslateX(200);
                        number_of_acts.setTranslateY(70);
                        number_of_acts.setMaxSize(150,2);

                        dialog.initModality(Modality.APPLICATION_MODAL);
                        dialog.initOwner(stage);
                        Group dialogVbox = new Group();
                        dialogVbox.getChildren().clear();

                        Sdescription2.clear();
                        SShortD2.clear();
                        SCategory2.clear();
                        SSTD2.getEditor().clear();
                        SName2.clear();


                        Button proceed=new Button("Create new Activity");
                        proceed.setTranslateX(350);
                        proceed.setTranslateY(70);
                        Insert_sub_to_db.setTranslateX(600);
                        Insert_sub_to_db.setTranslateY(40);

                        List<Activity>act_list=new ArrayList<Activity>();

                        Insert_sub_to_db.setOnAction( new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                                Activity a=new Activity();
                                a.setShortDescription(ShortDescription.getText());
                                a.setDescription(Description.getText());
                                a.setCategory(Category.getText());
                                a.setSTD(STD.getText());
                                act_list.add(a);

                                boolean answer2 = ConfirmBox2.display("Insert", "Activity Added");

                                ShortDescription.clear();
                                Description.clear();
                                Category.clear();
                                STD.clear();


                            }});
                        add_act_to_sub.setTranslateX(500);
                        add_act_to_sub.setTranslateY(300);
                        add_act_to_sub.setOnAction( new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                                DB db=new DB();
                                SubProcess new_sub=new SubProcess();
                                new_sub.setDescription(Sdescription2.getText());
                                new_sub.setCategory(SCategory2.getText());
                                new_sub.setName(SName2.getText());
                                new_sub.setShortDescription(SShortD2.getText());
                                new_sub.setLanguage(langCat2.getValue().toString());
                                new_sub.setSTD(SSTD2.getEditor().getText());
                                Set<Activity> to_set=new HashSet<>(act_list);
                                new_sub.setActivities(to_set);
                                db.addSubProcess(new_sub);
                                act_list.clear();

                                ShortDescription.clear();
                                Description.clear();
                                Category.clear();
                                STD.clear();

                                Sdescription2.clear();
                                SShortD2.clear();
                                SCategory2.clear();
                                SSTD2.getEditor().clear();
                                SName2.clear();

                                boolean answer = ConfirmBox2.display("Insert", "Sub Process Added");
                            }});







                        dialogVbox.getChildren().add(ShortDescriptionL);
                        dialogVbox.getChildren().add(ShortDescription);
                        dialogVbox.getChildren().add(DescriptionL);
                        dialogVbox.getChildren().add(Description);
                        dialogVbox.getChildren().add(CategoryL);
                        dialogVbox.getChildren().add(Category);
                        dialogVbox.getChildren().add(STDL);
                        dialogVbox.getChildren().add(STD);






                        Scene dialogScene = new Scene(dialogVbox, 800, 600);
                        dialogVbox.getChildren().add(SubProcess_Form_Root2);
                        dialogVbox.getChildren().add(Insert_sub_to_db);
                        dialogVbox.getChildren().add(add_act_to_sub);
                        dialog.setScene(dialogScene);

                        dialog.show();
                    }
                });




        exit.setOnAction(e ->
        {
            if (araabc == true) {

                closeProgramArabc(stage, RecentOpenn);

            } else {

                closeProgram(stage, RecentOpenn);
            }
        });

        saveeAs.setOnAction(e -> {
            addresssave = Savee(stage);
        });

        savee.setOnAction(e -> {
            boolean error = false;
            if(EmployeeScene) {
                Vector<Employee> New_Employees_With_Tasks = new Vector<Employee>();
                DB db = new DB();
                String role;
                for (int i = 0; i < Labels_vector.size(); i++) {
                    boolean flag = false;
                    error = false;
                    if (Labels_vector.get(i).Type_id == 1) {
                        role = JobTitle.getText();
                        New_Employees_With_Tasks.add(Labels_vector.get(i).EM);
                        Labels_vector.get(i).EM.setRole(JobTitle.getText());
                        if (Experience.getValue() != null)
                            Labels_vector.get(i).EM.setExperience(Experience.getValue().toString());
                        if (JobLocation.getValue() != null)
                            Labels_vector.get(i).EM.setJobLocation(JobLocation.getValue().toString());
                        if (Languages.getValue() != null)
                            Labels_vector.get(i).EM.setLanguages(Languages.getValue().toString());
                        if (JobType.getValue() != null)
                            Labels_vector.get(i).EM.setJobType(JobType.getValue().toString());
                        Labels_vector.get(i).EM.setManager(JobManager.getText());
                        Labels_vector.get(i).EM.setSkills(Skills.getText());
                        Labels_vector.get(i).EM.setQualification(JobQualification.getText());

                        List<Employee> employees = new ArrayList<>(db.getALlEmployees());
                        for (int j = 0; j < employees.size(); j++) {
                            //System.out.println(employees.get(j).getName()+" "+Labels_vector.get(i).EM.getName());
                            if (employees.get(j).getRole().equals(role)) {

                                flag = true;
                                employees.get(j).setExperience(Labels_vector.get(i).EM.getExperience());
                                employees.get(j).setQualification(Labels_vector.get(i).EM.getQualification());
                                employees.get(j).setSkills(Labels_vector.get(i).EM.getSkills());
                                employees.get(j).setManager(Labels_vector.get(i).EM.getManager());
                                employees.get(j).setJobType(Labels_vector.get(i).EM.getJobType());
                                employees.get(j).setLanguages(Labels_vector.get(i).EM.getLanguages());
                                employees.get(j).setJobLocation(Labels_vector.get(i).EM.getJobLocation());
                                employees.get(j).setRole(Labels_vector.get(i).EM.getRole());
                                System.out.println(employees.get(j).getName() + " " + employees.get(j).getExperience());
                                if (Labels_vector.get(i).EM.getRole().isEmpty() == true) {
                                    error = true;
                                    if (araabc) {
                                        boolean answer = ConfirmBox2.display("????? ????", "??? ????? ??? ???????");
                                    } else {
                                        boolean answer = ConfirmBox2.display("Update", "JD can't be updated. Please insert Job Title");
                                    }
                                } else {
                                    db.update_employee(employees.get(j));
                                    checkButton.setVisible(false);
                                    if (araabc) {
                                        boolean answer = ConfirmBox2.display("????? ????", "?? ????? ?????? ??????");
                                    } else {
                                        boolean answer = ConfirmBox2.display("Update", "Employee Updated");
                                    }
                                }
                                break;
                            }
                        }
                        if (flag == false) {
                            if (Labels_vector.get(i).EM.getRole().isEmpty() == true) {
                                error = true;
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ?????", "??? ????? ?????? ???????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Insert", "Please Enter a Job Title to Add Employee");
                                }
                            } else {
                                db.addEmployee(Labels_vector.get(i).EM);
                                checkButton.setVisible(false);
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ?????? ??????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Insert", "Employee Added");
                                }

                            }
                            break;
                        }
                    }
                }

            }
            else {
                Vector<Process> New_Employees_With_Tasks = new Vector<Process>();
                DB db = new DB();
                for (int i = 0; i < Labels_vector.size(); i++) {
                    boolean flag = false;
                    error = false;
                    if (Labels_vector.get(i).Type_id == 0) {
                        New_Employees_With_Tasks.add(Labels_vector.get(i).MP);
                        Labels_vector.get(i).MP.setMainProcessOwner(POwner.getText());
                        Labels_vector.get(i).MP.setDescription(PDescription.getText());
                        Labels_vector.get(i).MP.setShortDescription(PShortD.getText());
                        Labels_vector.get(i).MP.setVersion(PVersion.getText());
                        Labels_vector.get(i).MP.setPName(PName.getText());

                        if (Labels_vector.get(i).MP.getPName().isEmpty() == true) {
                            error = true;
                            if (araabc) {

                                boolean answer = ConfirmBox2.display("????? ?????", "???? ????? ??? ???????");
                            } else {
                                boolean answer2 = ConfirmBox2.display("Insert", "Please enter process name");
                            }
                        } else {
                            checkButton.setVisible(false);
                            if (araabc) {
                                boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ??????? ?????");
                            } else {
                                boolean answer = ConfirmBox2.display("Insert", "Procedure Added");
                            }
                            db.addProcess(Labels_vector.get(i).MP);
                        }
                        break;
                    }
                }
            }
            if(error == false) {
                if (!addressoben.equalsIgnoreCase("")) {
                    Savesave(addressoben);
                    saveFileDb(addressoben);
                } else if (!addresssave.equalsIgnoreCase("")) {
                    Savesave(addresssave);
                    saveFileDb(addresssave);
                } else {
                    addresssave = Savee(stage);
                    saveFileDb(addresssave);
                }
            }
        });

        Undo.setOnAction(e -> H.Undo(root, Labels_vector, Lines_vector));
        Redo.setOnAction(e -> H.Redo(root, Labels_vector, Lines_vector));

        close.setOnAction(e -> {

            fleMenue4.getItems().removeAll(fleMenue4.getItems());
            fleMenue4.getItems().add(GeneratePdf);
            clearr();
        });

        zoomInMenuItem.setAccelerator(new KeyCodeCombination(KeyCode.I));
        zoomInMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (root.getScaleX() < 1.2 && root.getScaleY() < 1.2) {
                    root.setScaleX(root.getScaleX() * 1.1);
                    root.setScaleY(root.getScaleY() * 1.1);
                }
            }
        });

        zoomOutMenuItem.setAccelerator(new KeyCodeCombination(KeyCode.O));
        zoomOutMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (root.getScaleX() != 1 && root.getScaleY() != 1) {

                    root.setScaleX(root.getScaleX() * 1 / 1.1);
                    root.setScaleY(root.getScaleY() * 1 / 1.1);

                }
            }
        });

        Image rrefresh = new Image(getClass().getResourceAsStream("/Images_And_Icons/reload-icon.png"));
        Image Main_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/icon-v2.png"));
        Image FILE_OPEN_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/open-file-icon.png"));
        Image FILE_EXIT_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Actions-window-close-icon.png"));
        Image FILE_CLOSE_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/folder-close-icon.png"));
        Image FILE_SAVE_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Actions-document-save-icon.png"));
        Image FILE_SAVE_AS_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Save-as-icon.png"));
        Image FILE_NEW_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/table-edit-icon.png"));
        Image FILE_NEW_JD_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/people-icon.png"));
        Image UNDO_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Undo-icon.png"));
        Image REDO_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Redo-icon.png"));
        Image ZOOM_IN_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Zoom-In-icon.png"));
        Image ZOOM_OUT_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Zoom-Out-icon.png"));
        Image WORD_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Document-Microsoft-Word-icon.png"));
        Image HELP_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Actions-help-about-icon.png"));
        Image DELETE_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Button-Cancel-icon.png"));
        Image LINK_ICON = new Image(getClass().getResourceAsStream("/Images_And_Icons/Link-icon.png"),32,32,false,false);
        Image WORD_ICON2 = new Image(getClass().getResourceAsStream("/Images_And_Icons/Document-Microsoft-Word-icon.png"));
        Image Arabic_Icon = new Image(getClass().getResourceAsStream("/Images_And_Icons/arabic.png"));
        Image Englsh_Icon = new Image(getClass().getResourceAsStream("/Images_And_Icons/english.png"));
        Image recop = new Image(getClass().getResourceAsStream("/Images_And_Icons/Actions-document-open-recent-icon.png"));
        Image pdfIcon = new Image(getClass().getResourceAsStream("/Images_And_Icons/pdf.png"));
        Image fileButton = new Image(getClass().getResourceAsStream("/Images_And_Icons/file.png"),32,32,false,false);

        ImageView image5 = new ImageView(FILE_OPEN_ICON);
        ImageView image6 = new ImageView(FILE_CLOSE_ICON);
        ImageView image7 = new ImageView(FILE_SAVE_ICON);
        ImageView image8 = new ImageView(FILE_SAVE_AS_ICON);
        ImageView image9 = new ImageView(FILE_EXIT_ICON);
        ImageView image10 = new ImageView(FILE_NEW_ICON);
        ImageView image11 = new ImageView(FILE_NEW_JD_ICON);
        ImageView image12 = new ImageView(UNDO_ICON);
        ImageView image13 = new ImageView(REDO_ICON);
        ImageView image14 = new ImageView(ZOOM_IN_ICON);
        ImageView image15 = new ImageView(ZOOM_OUT_ICON);
        ImageView image16 = new ImageView(WORD_ICON);
        ImageView image166 = new ImageView(WORD_ICON2);
        ImageView image20 = new ImageView(Englsh_Icon);
        ImageView image21 = new ImageView(Arabic_Icon);
        ImageView image22 = new ImageView(pdfIcon);

        ImageView image17 = new ImageView(HELP_ICON);
        ImageView image18 = new ImageView(DELETE_ICON);
        ImageView image19 = new ImageView(LINK_ICON);
        ImageView refimg = new ImageView(rrefresh);
        ImageView recent = new ImageView(recop);
        ImageView fileButtonV = new ImageView(fileButton);

        image5.setSmooth(true);
        image5.setFitWidth(30);
        image5.setFitHeight(30);
        image6.setSmooth(true);
        image6.setFitWidth(30);
        image6.setFitHeight(30);
        image7.setSmooth(true);
        image7.setFitWidth(30);
        image7.setFitHeight(30);
        image8.setSmooth(true);
        image8.setFitWidth(30);
        image8.setFitHeight(30);
        image9.setSmooth(true);
        image9.setFitWidth(30);
        image9.setFitHeight(30);
        image10.setSmooth(true);
        image10.setFitWidth(30);
        image10.setFitHeight(30);
        image11.setSmooth(true);
        image11.setFitWidth(30);
        image11.setFitHeight(30);
        image12.setSmooth(true);
        image12.setFitWidth(30);
        image12.setFitHeight(30);
        image13.setSmooth(true);
        image13.setFitWidth(30);
        image13.setFitHeight(30);
        image14.setSmooth(true);
        image14.setFitWidth(30);
        image14.setFitHeight(30);
        image15.setSmooth(true);
        image15.setFitWidth(30);
        image15.setFitHeight(30);
        image16.setSmooth(true);
        image16.setFitWidth(30);
        image16.setFitHeight(30);
        image17.setSmooth(true);
        image17.setFitWidth(30);
        image17.setFitHeight(30);
        image18.setSmooth(true);
        image18.setFitWidth(30);
        image18.setFitHeight(30);
        image20.setSmooth(true);
        image20.setFitWidth(30);
        image20.setFitHeight(30);
        image21.setSmooth(true);
        image21.setFitWidth(30);
        image21.setFitHeight(30);
        image22.setSmooth(true);
        image22.setFitWidth(30);
        image22.setFitHeight(30);
        refimg.setFitHeight(30);
        refimg.setFitWidth(30);
        recent.setFitWidth(30);
        recent.setFitHeight(30);

        openn.setGraphic(image5);
        close.setGraphic(image6);
        savee.setGraphic(image7);
        saveeAs.setGraphic(image8);
        exit.setGraphic(image9);
        newob.setGraphic(image10);
        newjb.setGraphic(image11);
        Undo.setGraphic(image12);
        Redo.setGraphic(image13);
        zoomInMenuItem.setGraphic(image14);
        zoomOutMenuItem.setGraphic(image15);
        GenerateOP.setGraphic(image16);
        arabic.setGraphic(image21);
        english.setGraphic(image20);
        GeneratePdf.setGraphic(image22);
        Help.setGraphic(image17);
        Delete.setGraphic(image18);
        Link.setGraphic(image19);
        GenerateJD.setGraphic(image166);
        RecentOpenn.setGraphic(recent);
        checkButton.setStyle("-fx-font: 18 arial; -fx-base: #d3191c;");
        checkButton.setTranslateX(1250);
        checkButton.setMaxWidth(200);
        fcWord.getExtensionFilters().add(new FileChooser.ExtensionFilter("DOCX File", "*.docx"));
        fcWord.setTitle("Save to word");
        GenerateJD.setOnAction((ActionEvent event) -> {
            if(araabc)
            {
                fcWord.setInitialFileName(JobTitle.getText()+"-ar.docx");

            }
            else
            {
                fcWord.setInitialFileName(JobTitle.getText() + ".docx");

            }
            File file = fcWord.showSaveDialog(stage);
            if (file != null) {
                String str = file.getAbsolutePath();
                try {
                    if(araabc)
                    {
                        template = new sample.Template(str, "Job-description-template-V6-ar.dotx");

                    }
                    else {

                        template = new sample.Template(str, "Job-description-template-V6.dotx");
                    }
                    String jobtitle = JobTitle.getText();
                    String jobtype = JobType.getEditor().getText();
                    String joblocation = JobLocation.getEditor().getText();
                    String manager = JobManager.getText();
                    String quali = JobQualification.getText();
                    String exp = Experience.getEditor().getText();
                    String skills = Skills.getText();
                    String languages = Languages.getEditor().getText();
                    template.replaceText("EmployeeRole", jobtitle);
                    template.replaceText("EmployeeJobType", jobtype);
                    template.replaceText("EmployeeLocation", joblocation);
                    template.replaceText("EmployeeReportingLine", manager);
                    String res = "";
                    System.out.println("labels size ehh is" + Labels_vector.size());


                    for (int i = 0; i < Labels_vector.size(); i++) {
                        // System.out.println("ensfwefhjkfhskeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"+" "+Labels_vector.get(i).Type_id );
                        if (Labels_vector.get(i) != null && Labels_vector.get(i).Type_id == 1) {

                            List<Task_> tasks2 = new ArrayList<Task_>(Labels_vector.get(i).EM.getTasks());

                            for (int j = 0; j < tasks2.size(); j++) {

                                res += "? "+tasks2.get(j).getShortDesc() + "\n" +"• "+ tasks2.get(j).getDescription() + '\n';
                                //res += " ";

                            }

                        }
                    }
                    template.replaceText("Taskcat", res);
                    template.replaceText("EmployeeDesirableSkills", skills);
                    template.replaceText("EmployeeWorkexp", exp);
                    template.replaceText("EmployeeMandatorySkills", quali);
                    template.replaceText("EmployeeLanguage", languages);
                    template.replaceText("image","image");
                    template.saveWord();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        });
        GenerateOP.setOnAction((ActionEvent event) -> {
            fcWord.setInitialFileName(PName.getText() + ".docx");

            File file = fcWord.showSaveDialog(stage);
            if (file != null) {
                String str = file.getAbsolutePath();
                try {
                    template = new sample.Template(str, "Procedure-template.dotx");
                    String mainProcessName = PName.getText();
                    String procedureOwner = POwner.getText();
                    String procedureVersion = PVersion.getText();
                    String processShort = PShortD.getText();
                    String processDes = PDescription.getText();
                    template.replaceText("MainProcessName", mainProcessName);
                    template.replaceText("EmployeeRole", procedureOwner);
                    template.replaceText("MainProcessVersion", procedureVersion);
                    template.replaceText("MainProcessShortDesc", processShort);
                    template.replaceText("MainProcessDesc", processDes);
                    List<SubProcess> subProcesses = new ArrayList<SubProcess>(MainProcess.getSubProcesses());
                    Set<Activity> Activities = new HashSet<Activity>();
                    List<Employee> Emps =  new ArrayList<Employee>();

                    for (int i = 0; i < Labels_vector.size(); i++) {
                        if (Labels_vector.get(i) != null && Labels_vector.get(i).Type_id == 1) {

                            Emps.add(Labels_vector.get(i).EM);

                        }
                    }
                    String res = "";


                    for (int i = 0; i < subProcesses.size(); i++) {
                        res += "? "+subProcesses.get(i).getShortDescription()+'\n';
                        res += "•• "+subProcesses.get(i).getDescription()+"\n";
                        if (subProcesses.get(i).getChild() != null)
                            res += "• "+subProcesses.get(i).getChild().getShortDescription()+'\n';
                        Activities=subProcesses.get(i).getActivities();

                        for (Iterator<Activity> it = Activities.iterator(); it.hasNext(); ) {
                            Activity f = it.next();
                            res += "- "+f.getShortDescription()+'\n';
                        }

                    }
                    Set<SubProcess> subProEmployee= new HashSet<SubProcess>();
                    Set<Activity> employeeActivities= new HashSet<Activity>();

                    String resEmployee="";
                    for(int i=0;i<Emps.size();i++)
                    {
                        //Emps.get(i).AddSub();
                        resEmployee+="? "+ Emps.get(i).getRole()+"\n";
                        subProEmployee =Emps.get(i).getSubProcesses();

                        for (Iterator<SubProcess> it = subProEmployee.iterator(); it.hasNext(); ) {

                            SubProcess f = it.next();
                            resEmployee += "•• "+f.getShortDescription()+"\n";
                            employeeActivities = f.getActivities();

                            for (Iterator<Activity> it1 = employeeActivities.iterator(); it1.hasNext(); ) {
                                Activity f1 = it1.next();
                                resEmployee += "• "+f1.getShortDescription()+'\n';
                            }

                        }

                    }

                    template.replaceText("SubPrcoessDesc", res);
                    template.replaceText("Employees", resEmployee);



                    template.saveWord();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


        });

        GeneratePdf.setOnAction(e -> {
            String path = "";
            FileChooser fc2 = new FileChooser();
            fc2.setTitle("Open Word File");
            File file = fc2.showOpenDialog(stage);
            path = file.getPath();
            // String dataDir = sample.Utils.getDataDir(Main.class);
            try {
                InputStream is = new FileInputStream(new File(
                        path));
                XWPFDocument document = new XWPFDocument(is);

                fcWord.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF File", "*.pdf"));
                fcWord.setTitle("Save to word");
                fcWord.setInitialFileName("output" + ".pdf");
                File file1 = fcWord.showSaveDialog(stage);
                String str = file1.getAbsolutePath();

                PdfOptions options = PdfOptions.create();
                OutputStream out = new FileOutputStream(new File(
                        str));
                System.out.println("\nDocument converted to PDF successfully.\nFile saved at " + str);
                document.createNumbering();
                PdfConverter.getInstance().convert(document, out, options);

             /*   Document doc = new Document( path);
                fcWord.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF File", "*.pdf"));
                fcWord.setTitle("Save to word");
                fcWord.setInitialFileName("output" + ".pdf");
                File file1 = fcWord.showSaveDialog(stage);
                String str = file1.getAbsolutePath();
               // dataDir = "output.pdf";
                doc.save(str);*/
                System.out.println("\nDocument converted to PDF successfully.\nFile saved at " + str);
                document.close();

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        Delete.setOnAction(e -> {
            if (DeleteOn == true) {
                DeleteOn = false;
                Delete.setStyle("");
            } else {
                DeleteOn = true;
                Delete.setStyle("-fx-border-width: 3;" + "-fx-border-radius:110;" + "-fx-border-color: green;");
            }
            Link.setStyle("");
            LinkOn = false;
        });

        Link.setOnAction(e -> {
            if (LinkOn == true) {
                LinkOn = false;
                Link.setStyle("");
            } else {
                LinkOn = true;
                Link.setStyle("-fx-border-width: 3;" + "-fx-border-radius:110;" + "-fx-border-color: green;");
            }
            Delete.setStyle("");
            DeleteOn = false;
        });

        print.setOnAction(e ->
                {
                    printsss();
                    //   Group rrr=new Group();
                    //      for(int i=0;i<Labels_vector{})
//                    rrr.getChildren().add(Labels_vector);

                }
        );
        newob.setOnAction(e -> {
            EmployeeScene = false;
            fleMenue4.getItems().removeAll(fleMenue4.getItems());
            fleMenue4.getItems().add(GenerateOP);
            fleMenue4.getItems().add(GeneratePdf);

            ChangeScene();
        });
        newjb.setOnAction(e -> {
            EmployeeScene = true;
            fleMenue4.getItems().removeAll(fleMenue4.getItems());
            fleMenue4.getItems().add(GenerateJD);
            fleMenue4.getItems().add(GeneratePdf);

            ChangeScene();
        });

        Save_Process.setOnAction(e -> {
            Vector<Process> New_Employees_With_Tasks = new Vector<Process>();
            DB db = new DB();
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i).Type_id == 0) {
                    New_Employees_With_Tasks.add(Labels_vector.get(i).MP);
                    Labels_vector.get(i).MP.setMainProcessOwner(POwner.getText());
                    Labels_vector.get(i).MP.setDescription(PDescription.getText());
                    Labels_vector.get(i).MP.setShortDescription(PShortD.getText());
                    Labels_vector.get(i).MP.setVersion(PVersion.getText());
                    Labels_vector.get(i).MP.setPName(PName.getText());
                    if (Labels_vector.get(i).MP.getPName().isEmpty() == true) {
                        if (araabc) {
                            boolean answer = ConfirmBox2.display("????? ?????", "???? ????? ??? ???????");
                        } else {
                            boolean answer2 = ConfirmBox2.display("Insert", "Please enter process name");
                        }
                    } else {
                        checkButton.setVisible(false);
                        if (araabc) {
                            boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ??????? ?????");
                        } else {
                            boolean answer = ConfirmBox2.display("Insert", "Procedure Added");
                        }
                        db.addProcess(Labels_vector.get(i).MP);
                    }
                    break;
                }
            }

        });

        Save_Process2.setOnAction(e -> {
            Vector<Process> New_Employees_With_Tasks = new Vector<Process>();
            DB db = new DB();
            String shortDesc;
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i).Type_id == 0) {
                    shortDesc = Labels_vector.get(i).MP.getPName();
                    New_Employees_With_Tasks.add(Labels_vector.get(i).MP);
                    Labels_vector.get(i).MP.setMainProcessOwner(POwner.getText());
                    Labels_vector.get(i).MP.setDescription(PDescription.getText());
                    Labels_vector.get(i).MP.setShortDescription(PShortD.getText());
                    Labels_vector.get(i).MP.setVersion(PVersion.getText());
                    Labels_vector.get(i).MP.setPName(PName.getText());

                    List<Process> processes = new ArrayList<Process>(db.getALlProcess());

                    for (int j = 0; j < processes.size(); j++) {
                        System.out.println(processes.get(j).getShortDescription() + " " + shortDesc);
                        if (processes.get(j).getPName().equals(shortDesc)) {
                            System.out.println("Doneeeeeeeeeeeeeeeeeeee");
                            processes.get(j).setDescription(Labels_vector.get(i).MP.getDescription());
                            processes.get(j).setShortDescription(Labels_vector.get(i).MP.getShortDescription());
                            processes.get(j).setMainProcessOwner(Labels_vector.get(i).MP.getMainProcessOwner());
                            processes.get(j).setVersion(Labels_vector.get(i).MP.getVersion());
                            processes.get(j).setPName(Labels_vector.get(i).MP.getPName());
                            if (Labels_vector.get(i).MP.getShortDescription().isEmpty() == true) {
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ????", "??? ????? ??? ???????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Insert", "Please add Procedure Name");
                                }
                            } else {
                                checkButton.setVisible(false);

                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ????", "?? ????? ??????? ????? ");
                                } else {
                                    boolean answer = ConfirmBox2.display("Update", "Main Procedure Updated");
                                }
                                db.update_process(processes.get(j));
                            }
                        }

                    }
                    break;
                }
            }

        });

        Insert_New_SubProcess.setOnAction(e -> {

            Vector<SubProcess> New_Employees_With_Tasks = new Vector<SubProcess>();
            DB db = new DB();
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i).Type_id % 2 == 0) {
                    New_Employees_With_Tasks.add(Labels_vector.get(i).SP);
                    Labels_vector.get(i).SP.setCategory(SCategory.getText());
                    Labels_vector.get(i).SP.setDescription(Sdescription.getText());
                    Labels_vector.get(i).SP.setShortDescription(SShortD.getText());
                    Labels_vector.get(i).SP.setName(SName.getText());
                    Labels_vector.get(i).SP.setSTD(SSTD.getEditor().getText());
                    if (langCat.getValue().toString().matches("English")) {
                        Labels_vector.get(i).SP.setLanguage("EN");
                    } else if (langCat.getValue().toString().matches("Arabic")) {
                        Labels_vector.get(i).SP.setLanguage("AR");
                    }
                    if (araabc) {
                        checkButton.setVisible(false);

                        boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ????? ????? ?????");
                    } else {
                        boolean answer = ConfirmBox2.display("Insert", "Sub Process Added");
                    }

                    db.addSubProcess(Labels_vector.get(i).SP);
                    break;
                }
            }

        });

        Update_Sub_Process.setOnAction(e -> {

            Vector<SubProcess> New_Employees_With_Tasks = new Vector<SubProcess>();
            DB db = new DB();
            String shortDesc;
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i).Type_id % 2 == 0) {
                    shortDesc = Labels_vector.get(i).SP.getShortDescription();
                    New_Employees_With_Tasks.add(Labels_vector.get(i).SP);
                    Labels_vector.get(i).SP.setCategory(SCategory.getText());
                    Labels_vector.get(i).SP.setDescription(Sdescription.getText());
                    Labels_vector.get(i).SP.setShortDescription(SShortD.getText());
                    Labels_vector.get(i).SP.setName(SName.getText());
                    Labels_vector.get(i).SP.setSTD(SSTD.getEditor().getText());

                    List<SubProcess> processes = new ArrayList<SubProcess>(db.getALlSubProcess());

                    for (int j = 0; j < processes.size(); j++) {
                        System.out.println(processes.get(j).getShortDescription() + " " + shortDesc);
                        if (processes.get(j).getShortDescription().equals(shortDesc)) {
                            System.out.println("Doneeeeeeeeeeeeeeeeeeee");
                            if (araabc) {
                                boolean answer = ConfirmBox2.display("????? ????", "?? ????? ??????? ???????");
                            } else {
                                boolean answer = ConfirmBox2.display("Update", "Sub Process Updated");
                            }
                            processes.get(j).setDescription(Labels_vector.get(i).SP.getDescription());
                            processes.get(j).setShortDescription(Labels_vector.get(i).SP.getShortDescription());
                            processes.get(j).setName(Labels_vector.get(i).SP.getName());
                            processes.get(j).setCategory(Labels_vector.get(i).SP.getCategory());
                            processes.get(j).setSTD(Labels_vector.get(i).SP.getSTD());

                            db.update_subProcess(processes.get(j));
                        }

                    }
                    break;
                }
            }


        });


        Save_Employee_Tasks.setOnAction(e -> {

            Vector<Employee> New_Employees_With_Tasks = new Vector<Employee>();
            DB db = new DB();
            String role;
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i).Type_id == 1) {
                    role = Labels_vector.get(i).EM.getRole();
                    New_Employees_With_Tasks.add(Labels_vector.get(i).EM);
                    Labels_vector.get(i).EM.setRole(JobTitle.getText());

                    if (Experience.getValue() != null) {
                        Labels_vector.get(i).EM.setExperience(Experience.getValue().toString());
                    }

                    if (JobLocation.getValue() != null) {
                        Labels_vector.get(i).EM.setJobLocation(JobLocation.getValue().toString());
                    }

                    if (Languages.getValue() != null) {
                        Labels_vector.get(i).EM.setLanguages(Languages.getValue().toString());
                    }

                    if (JobType.getValue() != null) {
                        Labels_vector.get(i).EM.setJobType(JobType.getValue().toString());
                    }

                    Labels_vector.get(i).EM.setManager(JobManager.getText());
                    Labels_vector.get(i).EM.setSkills(Skills.getText());
                    Labels_vector.get(i).EM.setQualification(JobQualification.getText());


                    List<Employee> employees = new ArrayList<>(db.getALlEmployees());
                    for (int j = 0; j < employees.size(); j++) {
                        //System.out.println(employees.get(j).getName()+" "+Labels_vector.get(i).EM.getName());
                        if (employees.get(j).getRole().equals(role)) {


                            employees.get(j).setExperience(Labels_vector.get(i).EM.getExperience());
                            employees.get(j).setQualification(Labels_vector.get(i).EM.getQualification());
                            employees.get(j).setSkills(Labels_vector.get(i).EM.getSkills());
                            employees.get(j).setManager(Labels_vector.get(i).EM.getManager());
                            employees.get(j).setJobType(Labels_vector.get(i).EM.getJobType());
                            employees.get(j).setLanguages(Labels_vector.get(i).EM.getLanguages());
                            employees.get(j).setJobLocation(Labels_vector.get(i).EM.getJobLocation());
                            employees.get(j).setRole(Labels_vector.get(i).EM.getRole());
                            System.out.println(employees.get(j).getName() + " " + employees.get(j).getExperience());
                            if (Labels_vector.get(i).EM.getRole().isEmpty() == true) {
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ????", "??? ????? ??? ???????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Update", "JD can't be updated. Please insert Job Title");
                                }
                            } else {
                                db.update_employee(employees.get(j));
                                checkButton.setVisible(false);
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ????", "?? ????? ?????? ??????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Update", "Employee Updated");
                                }
                            }
                        }
                    }

                    break;
                }
            }

        });

   /*     Insert_Employee.setOnAction(e -> {

            Vector<Employee> New_Employees_With_Tasks = new Vector<Employee>();
            DB db = new DB();
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i).Type_id == 1) {
                    New_Employees_With_Tasks.add(Labels_vector.get(i).EM);
                    Labels_vector.get(i).EM.setRole(JobTitle.getText());
                    if (Experience.getValue() != null)
                        Labels_vector.get(i).EM.setExperience(Experience.getValue().toString());
                    if (JobLocation.getValue() != null)
                        Labels_vector.get(i).EM.setJobLocation(JobLocation.getValue().toString());
                    if (Languages.getValue() != null)
                        Labels_vector.get(i).EM.setLanguages(Languages.getValue().toString());
                    if (JobType.getValue() != null)
                        Labels_vector.get(i).EM.setJobType(JobType.getValue().toString());
                    Labels_vector.get(i).EM.setManager(JobManager.getText());
                    Labels_vector.get(i).EM.setSkills(Skills.getText());
                    Labels_vector.get(i).EM.setQualification(JobQualification.getText());

                    if (Labels_vector.get(i).EM.getRole().isEmpty() == true) {
                        if (araabc) {
                            boolean answer = ConfirmBox2.display("????? ?????", "??? ????? ?????? ???????");
                        } else {
                            boolean answer = ConfirmBox2.display("Insert", "Please Enter a Job Title to Add Employee");
                        }
                    } else {
                        checkButton.setVisible(false);
                        if (araabc) {
                            boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ?????? ??????");
                        } else {
                            boolean answer = ConfirmBox2.display("Insert", "Employee Added");
                        }

                        db.addEmployee(Labels_vector.get(i).EM);
                    }
                    break;
                }
            }
            if (!addressoben.equalsIgnoreCase("")) {
                Savesave(addressoben);
                saveFileDb(addressoben);
            } else if (!addresssave.equalsIgnoreCase("")) {
                Savesave(addresssave);
                saveFileDb(addresssave);
            }
            else
            {
                addresssave = Savee(stage);
                saveFileDb(addresssave);
            }


        });*/


        language.getItems().addAll(arabic, english);
        fleMenue.getItems().add(New);
        New.getItems().add(newjb);
        New.getItems().add(newob);
        fleMenue.getItems().add(savee);
        fleMenue.getItems().add(openn);
        fleMenue.getItems().add(RecentOpenn);
        fleMenue.getItems().add(saveeAs);
        fleMenue.getItems().add(close);
        fleMenue.getItems().add(exit);


        // Operation.getItems().add(Save_Employee_Tasks);
        //Operation.getItems().add(Insert_Employee);


        fleMenue1.getItems().add(Undo);
        fleMenue1.getItems().add(Redo);

        fleMenue2.getItems().add(Delete);
        fleMenue2.getItems().add(Link);

        fleMenue3.getItems().add(zoomInMenuItem);
        fleMenue3.getItems().add(zoomOutMenuItem);
        fleMenue4.getItems().add(GeneratePdf);
        fleMenue5.getItems().add(Help);
        fleMenue5.getItems().add(print);
        MenuBar menuBar = new MenuBar();
        menuBar.setMinWidth(3000);

        menuBar.getMenus().addAll(fleMenue, fleMenue1, fleMenue2, fleMenue3, fleMenue4, language, fleMenue5);

        VBox topContainer = new VBox(); //Creates a container to hold all Menu Objects.
        ToolBar toolbar = new ToolBar();
        Button openFileBtn = new Button();
        Button closeFileBtn = new Button();
        Button SaveFileBtn = new Button();
        Button SaveAsFileBtn = new Button();
        Button ZoomAnBtn = new Button();
        Button ZoomOutFileBtn = new Button();
        Button OpenHelpfile = new Button();
        Button NewOP = new Button();
        Button NewJD = new Button();
        Button link = new Button();
        Button printt=new Button();
        Button delete = new Button();
        Button saveFile = new Button();
        final Tooltip t12 = new Tooltip();
        t12.setText("save file to DB");
        t12.setFont(Font.font(18));
        saveFile.setTooltip(t12);
        saveFile.setOnAction( e -> {
            DB db = new DB();
            String path = "";
            FileChooser fc2 = new FileChooser();
            //fc.selectedExtensionFilterProperty();
            fc2.setTitle("Open Resource File");
            File file = fc2.showOpenDialog(stage);
            path = file.getPath();
            String name = file.getName();
            File f1 = new File(path);
            byte[] bFile = new byte[(int) f1.length()];
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                //convert file into array of bytes
                fileInputStream.read(bFile);
                fileInputStream.close();
            } catch (Exception error) {
                error.printStackTrace();
            }
            File1 f = new File1();
            f.setFiles(bFile);
            f.setName(name);
            if(name.contains(".jd"))
            {
                f.setType(1);
            }
            else if (name.contains(".opd"))
            {
                f.setType(0);
            }
            int y=0;
            List<File1> allFiles = new ArrayList<>(db.getAllFiles());
            for(int i=0;i<allFiles.size();i++)
            {
                if(allFiles.get(i).getName().equals(f.getName()) && allFiles.get(i).getType() == f.getType())
                {
                    System.out.println("filee"+f.getName());
                    f.setIdfiles(allFiles.get(i).getIdfiles());
                    db.update_file(f);
                    y=0;
                    break;
                }
                else {
                    y=1;
                }
            }

            if(y==1)
            {
                db.AddFile(f);
            }


  /*  Session session = FileRepository.getSessionFactory().openSession();
    session.beginTransaction();
    File file = new File("C:\\Users\\BEST WAY\\Desktop\\y.jd");
    byte[] bFile = new byte[(int) file.length()];

    try {
        FileInputStream fileInputStream = new FileInputStream(file);
        //convert file into array of bytes
        fileInputStream.read(bFile);
        fileInputStream.close();
    } catch (Exception error) {
        error.printStackTrace();
    }
    File1 f = new File1();
    f.setFiles(bFile);
    session.save(f);
    File1 avatar2 = (File1)session.get(File1.class, 2);
    byte[] f = avatar2.getFiles();

    try{
        FileOutputStream fos = new FileOutputStream("y.jd");
        fos.write(f);
        fos.close();
    }catch(Exception error){
        error.printStackTrace();
    }*/


            //session.getTransaction().commit();

        });
        saveFile.setGraphic(new ImageView(fileButton));

        final Tooltip t0 = new Tooltip();
        t0.setText("Refresh");
        t0.setFont(Font.font(18));
        openFileBtn.setTooltip(t0);
        Refresh.setOnAction(e ->
                {
                    refreshh(stage);
                }
        );

        Refresh.setGraphic(refimg);
        final Tooltip tt = new Tooltip();
        tt.setFont(Font.font(18));
        tt.setText("Refresh");
        Refresh.setTooltip(tt);

        openFileBtn.setGraphic(new ImageView(FILE_OPEN_ICON));
        openFileBtn.setOnAction(e -> {
            addressoben = Openn(Labels_vector, Lines_vector, stage, RecentOpenn);
        });
        openn.setOnAction(e -> {
            addressoben = Openn(Labels_vector, Lines_vector, stage, RecentOpenn);
        });
        final Tooltip t1 = new Tooltip();
        t1.setText("Open");
        t1.setFont(Font.font(18));
        openFileBtn.setTooltip(t1);

        closeFileBtn.setGraphic(new ImageView(FILE_CLOSE_ICON));
        closeFileBtn.setOnAction(e -> {
            fleMenue4.getItems().removeAll(fleMenue4.getItems());
            clearr();
        });
        final Tooltip t2 = new Tooltip();
        t2.setText("Close File");
        t2.setFont(Font.font(18));

        closeFileBtn.setTooltip(t2);
        SaveFileBtn.setGraphic(new ImageView(FILE_SAVE_ICON));
        final Tooltip t3 = new Tooltip();
        t3.setText("Save");
        t3.setFont(Font.font(18));

        SaveFileBtn.setTooltip(t3);
        SaveFileBtn.setOnAction(e -> {
            boolean error = false;
            if(EmployeeScene) {
                Vector<Employee> New_Employees_With_Tasks = new Vector<Employee>();
                DB db = new DB();
                String role;
                for (int i = 0; i < Labels_vector.size(); i++) {
                    boolean flag = false;
                    error = false;
                    if (Labels_vector.get(i).Type_id == 1) {
                        role = JobTitle.getText();
                        New_Employees_With_Tasks.add(Labels_vector.get(i).EM);
                        Labels_vector.get(i).EM.setRole(JobTitle.getText());
                        if (Experience.getValue() != null)
                            Labels_vector.get(i).EM.setExperience(Experience.getValue().toString());
                        if (JobLocation.getValue() != null)
                            Labels_vector.get(i).EM.setJobLocation(JobLocation.getValue().toString());
                        if (Languages.getValue() != null)
                            Labels_vector.get(i).EM.setLanguages(Languages.getValue().toString());
                        if (JobType.getValue() != null)
                            Labels_vector.get(i).EM.setJobType(JobType.getValue().toString());
                        Labels_vector.get(i).EM.setManager(JobManager.getText());
                        Labels_vector.get(i).EM.setSkills(Skills.getText());
                        Labels_vector.get(i).EM.setQualification(JobQualification.getText());

                        List<Employee> employees = new ArrayList<>(db.getALlEmployees());
                        for (int j = 0; j < employees.size(); j++) {
                            //System.out.println(employees.get(j).getName()+" "+Labels_vector.get(i).EM.getName());
                            if (employees.get(j).getRole().equals(role)) {

                                flag = true;
                                employees.get(j).setExperience(Labels_vector.get(i).EM.getExperience());
                                employees.get(j).setQualification(Labels_vector.get(i).EM.getQualification());
                                employees.get(j).setSkills(Labels_vector.get(i).EM.getSkills());
                                employees.get(j).setManager(Labels_vector.get(i).EM.getManager());
                                employees.get(j).setJobType(Labels_vector.get(i).EM.getJobType());
                                employees.get(j).setLanguages(Labels_vector.get(i).EM.getLanguages());
                                employees.get(j).setJobLocation(Labels_vector.get(i).EM.getJobLocation());
                                employees.get(j).setRole(Labels_vector.get(i).EM.getRole());
                                System.out.println(employees.get(j).getName() + " " + employees.get(j).getExperience());
                                if (Labels_vector.get(i).EM.getRole().isEmpty() == true) {
                                    error = true;
                                    if (araabc) {
                                        boolean answer = ConfirmBox2.display("????? ????", "??? ????? ??? ???????");
                                    } else {
                                        boolean answer = ConfirmBox2.display("Update", "JD can't be updated. Please insert Job Title");
                                    }
                                } else {
                                    db.update_employee(employees.get(j));
                                    checkButton.setVisible(false);
                                    if (araabc) {
                                        boolean answer = ConfirmBox2.display("????? ????", "?? ????? ?????? ??????");
                                    } else {
                                        boolean answer = ConfirmBox2.display("Update", "Employee Updated");
                                    }
                                }
                                break;
                            }
                        }
                        if (flag == false) {
                            if (Labels_vector.get(i).EM.getRole().isEmpty() == true) {
                                error = true;
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ?????", "??? ????? ?????? ???????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Insert", "Please Enter a Job Title to Add Employee");
                                }
                            } else {
                                db.addEmployee(Labels_vector.get(i).EM);
                                checkButton.setVisible(false);
                                if (araabc) {
                                    boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ?????? ??????");
                                } else {
                                    boolean answer = ConfirmBox2.display("Insert", "Employee Added");
                                }

                            }
                            break;
                        }
                    }
                }

            }
            else {
                Vector<Process> New_Employees_With_Tasks = new Vector<Process>();
                DB db = new DB();
                for (int i = 0; i < Labels_vector.size(); i++) {
                    boolean flag = false;
                    error = false;
                    if (Labels_vector.get(i).Type_id == 0) {
                        New_Employees_With_Tasks.add(Labels_vector.get(i).MP);
                        Labels_vector.get(i).MP.setMainProcessOwner(POwner.getText());
                        Labels_vector.get(i).MP.setDescription(PDescription.getText());
                        Labels_vector.get(i).MP.setShortDescription(PShortD.getText());
                        Labels_vector.get(i).MP.setVersion(PVersion.getText());
                        Labels_vector.get(i).MP.setPName(PName.getText());

                        if (Labels_vector.get(i).MP.getPName().isEmpty() == true) {
                            error = true;
                            if (araabc) {

                                boolean answer = ConfirmBox2.display("????? ?????", "???? ????? ??? ???????");
                            } else {
                                boolean answer2 = ConfirmBox2.display("Insert", "Please enter process name");
                            }
                        } else {
                            checkButton.setVisible(false);
                            if (araabc) {
                                boolean answer = ConfirmBox2.display("????? ?????", "?? ????? ??????? ?????");
                            } else {
                                boolean answer = ConfirmBox2.display("Insert", "Procedure Added");
                            }
                            db.addProcess(Labels_vector.get(i).MP);
                        }
                        break;
                    }
                }
            }
            if(error == false) {
                if (!addressoben.equalsIgnoreCase("")) {
                    Savesave(addressoben);
                    saveFileDb(addressoben);
                } else if (!addresssave.equalsIgnoreCase("")) {
                    Savesave(addresssave);
                    saveFileDb(addresssave);
                } else {
                    addresssave = Savee(stage);
                    saveFileDb(addresssave);
                }
            }

        });

        SaveAsFileBtn.setGraphic(new ImageView(FILE_SAVE_AS_ICON));
        SaveAsFileBtn.setOnAction(e -> addresssave = Savee(stage));

        final Tooltip t4 = new Tooltip();
        t4.setText("Save As");
        t4.setFont(Font.font(18));

        SaveAsFileBtn.setTooltip(t4);

        OpenHelpfile.setGraphic(new ImageView(HELP_ICON));
        final Tooltip t5 = new Tooltip();
        t5.setText("Help");
        t5.setFont(Font.font(18));

        OpenHelpfile.setTooltip(t5);
        //ZoomAnBtn.setAccelerator(new KeyCodeCombination(KeyCode.I));
        ZoomAnBtn.setGraphic(new ImageView(ZOOM_IN_ICON));
        final Tooltip t6 = new Tooltip();
        t6.setText("Zoom IN");
        t6.setFont(Font.font(18));

        ZoomAnBtn.setTooltip(t6);
        ZoomAnBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                root.setScaleX(root.getScaleX() * 1.5);
                root.setScaleY(root.getScaleY() * 1.5);

            }
        });

        ZoomOutFileBtn.setGraphic(new ImageView(ZOOM_OUT_ICON));
        final Tooltip t7 = new Tooltip();
        t7.setText("Zoom Out");
        t7.setFont(Font.font(18));

        ZoomOutFileBtn.setTooltip(t7);
        ZoomOutFileBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println(root.getScaleX() + " " + root.getScaleY());
                root.setScaleX(root.getScaleX() * 1 / 1.5);
                root.setScaleY(root.getScaleY() * 1 / 1.5);

            }
        });


        NewOP.setGraphic(new ImageView(FILE_NEW_ICON));
        final Tooltip t8 = new Tooltip();
        t8.setText("New OP");
        t8.setFont(Font.font(18));

        NewOP.setTooltip(t8);
        NewOP.setOnAction(e -> {
            EmployeeScene = false;
            fleMenue4.getItems().removeAll(fleMenue4.getItems());
            fleMenue4.getItems().add(GenerateOP);
            fleMenue4.getItems().add(GeneratePdf);
            ChangeScene();
        });

        NewJD.setGraphic(new ImageView(FILE_NEW_JD_ICON));
        final Tooltip t9 = new Tooltip();
        t9.setText("New JD");
        t9.setFont(Font.font(18));

        NewJD.setTooltip(t9);
        NewJD.setOnAction(e -> {
            EmployeeScene = true;
            fleMenue4.getItems().removeAll(fleMenue4.getItems());
            fleMenue4.getItems().add(GenerateJD);
            fleMenue4.getItems().add(GeneratePdf);
            ChangeScene();
        });
        link.setGraphic(new ImageView(LINK_ICON));
        final Tooltip t10 = new Tooltip();
        t10.setText("Link");
        t10.setFont(Font.font(18));
        link.setTooltip(t10);
        link.setOnAction(e -> {
            if (LinkOn == true) {
                LinkOn = false;
                Link.setStyle("");
            } else {
                LinkOn = true;
                Link.setStyle("-fx-border-width: 3;" + "-fx-border-radius:110;" + "-fx-border-color: green;");
            }
            Delete.setStyle("");
            DeleteOn = false;
        });
        printt.setOnAction(e->{
            printsss();
        });
        delete.setGraphic(new ImageView(DELETE_ICON));
        final Tooltip t11 = new Tooltip();
        t11.setText("Delete");
        t11.setFont(Font.font(18));
        delete.setTooltip(t11);
        delete.setOnAction(e -> {
            if (DeleteOn == true) {
                DeleteOn = false;
                Delete.setStyle("");
            } else {
                DeleteOn = true;
                Delete.setStyle("-fx-border-width: 3;" + "-fx-border-radius:110;" + "-fx-border-color: green;");
            }
            Link.setStyle("");
            LinkOn = false;
        });

        //Save_Employee_Tasks.setGraphic(image20);
        //Insert_Employee.setGraphic(image21);
        toolbar.getItems().addAll( NewJD,NewOP,link,delete, Refresh, openFileBtn, closeFileBtn, SaveFileBtn, SaveAsFileBtn, ZoomAnBtn, ZoomOutFileBtn, OpenHelpfile,printt,btnn);


        topContainer.getChildren().add(menuBar);
        topContainer.getChildren().add(toolbar);


        arabic.setOnAction(e -> {
            araabc = true;
            stage.setTitle("???? ?????");
            language.setText("?????");
            arabic.setText("????");
            english.setText("???????");
            fleMenue.setText("???");
            savee.setText("???");
            openn.setText("???");
            saveeAs.setText("??? ??");
            close.setText("?????");
            exit.setText("????");

            fleMenue1.setText("?????");
            Undo.setText("????? ?????");
            Redo.setText("????? ?????");

            fleMenue2.setText("???");
            Delete.setText("???");
            Link.setText("???");
            print.setText("????");

            fleMenue3.setText("???");
            zoomInMenuItem.setText("?????");
            zoomOutMenuItem.setText("?????");

            fleMenue4.setText("?????");
            GenerateOP.setText("????? ??? ??????? ??? ");
            GenerateJD.setText("????? ??? ???? ????? ");
            GeneratePdf.setText("????? ??? ????? PDF");

            fleMenue5.setText("??????");
            Operation.setText("?????");
            Help.setText("??? ??? ??????");
            Save_Employee_Tasks.setText("??? ???? ??????");
            Save_Process.setText("??? ??????? ?????");
            Save_Process2.setText("????? ??????? ?????");
            Insert_Employee.setText("????? ????");
            Generate.setText("?????");
            New.setText("????");
            newob.setText("??? ??????? ??? ????");
            newjb.setText("??? ???? ????? ????");


            //final Tooltip t11 = new Tooltip();
            t1.setText("???");

            openFileBtn.setTooltip(t1);

            //final Tooltip t2 = new Tooltip();
            t2.setText("?????");
            closeFileBtn.setTooltip(t2);
            //final Tooltip t3 = new Tooltip();
            t3.setText("???");
            SaveFileBtn.setTooltip(t3);

            //final Tooltip t4 = new Tooltip();
            t4.setText("??? ??");
            SaveAsFileBtn.setTooltip(t4);

            //final Tooltip t5 = new Tooltip();
            t5.setText("??????");
            OpenHelpfile.setTooltip(t5);

            //final Tooltip t6 = new Tooltip();
            t6.setText("?????");
            ZoomAnBtn.setTooltip(t6);

            //final Tooltip t7 = new Tooltip();
            t7.setText("?????");
            ZoomOutFileBtn.setTooltip(t7);
            //final Tooltip t8 = new Tooltip();
            t8.setText("??? ??????? ??? ????");
            NewOP.setTooltip(t8);
            //final Tooltip t9 = new Tooltip();
            t9.setText("??? ???? ????? ????");
            NewJD.setTooltip(t9);
            t10.setText("?????");
            link.setTooltip(t10);

            t11.setText("???");
            delete.setTooltip(t11);
            JobTitleL.setText("??? ???????");
            JobTitle.setPromptText("?????????? ????????.");

            JobTypeL.setText("??? ???????");
            JobType.setPromptText("??? ????.");

            JobLocationL.setText("???? ???????");
            JobLocation.setPromptText(" ??????? / ???.");

            JobManagerL.setText("???? ???????");
            JobManager.setPromptText("???? ?????? ??????? ?????????? ?????????.");

            JobQualificationL.setText("?????? ???????");
            RecentOpenn.setText("??????? ???????? ?????");

            ExperienceL.setText("??????");
            Experience.setPromptText("3-5 ?????.");
            LanguagesL.setText("??????");
            // Languages.setPromptText("????-???????");

            Insert_New_SubProcess.setText("????? ????? ????? ?????");
            Update_Sub_Process.setText("???? ??????? ???????");

            SkillsL.setText("????????");
            Skills.setPromptText("????? ??? ?????.");

            Jobdescription.setText("?????? ???????");
            Pdescription.setText("????? ?????");
            PDescriptionL.setText("??? ???????");
            PShortDL.setText("??? ????? ???????");
            PSNameL.setText("??? ???????");
            POwnerL.setText("???? ???????");
            PVersionL.setText("???? ???????");

            SDescribtionL.setText("????? ????? ?????");
            SdescriptionL.setText("??? ??????? ???????");
            SCategoryL.setText("??? ??????? ???????");
            SNameL.setText("??? ??????? ???????");
            langChoice.setText("??? ??????? ???????");
            SSTDL.setText("????? ??????? ??????? ");
            SShortDL.setText("??? ????? ??????? ???????");


        });

        english.setOnAction(e -> {
            araabc = false;
            stage.setTitle("Procedures Designer");
            language.setText("Language");
            arabic.setText("Arabic");
            english.setText("English");
            fleMenue.setText("File");
            savee.setText("Save");
            openn.setText("Open");
            saveeAs.setText("Save as");
            close.setText("Close");
            exit.setText("Exit");
            fleMenue1.setText("Edit");
            Undo.setText("Undo Ctrl+Z");
            Redo.setText("Redo Ctrl+X");

            fleMenue2.setText("Action");
            Delete.setText("Delete");
            Link.setText("Link");
            print.setText("Print");

            fleMenue3.setText("View");
            zoomInMenuItem.setText("Zoom In");
            zoomOutMenuItem.setText("Zoom Out");

            fleMenue4.setText("Generate");
            GenerateOP.setText("Generate OP");
            GenerateJD.setText("Generate JD");
            GeneratePdf.setText("Generate PDF");


            RecentOpenn.setText("Recent Open");

            fleMenue5.setText("Help");
            Operation.setText("Operation");
            Help.setText("Open Help file");
            Save_Employee_Tasks.setText("Update JD");
            Save_Process.setText("Add New Operating Procedure to Data base");
            Save_Process2.setText("Update Operating Procedure");
            Insert_Employee.setText("Add JD to Database");
            Generate.setText("Generate");
            New.setText("New");
            newob.setText("OP");
            newjb.setText("JD");

            //final Tooltip t11 = new Tooltip();
            t1.setText("Open");

            openFileBtn.setTooltip(t1);

            //final Tooltip t2 = new Tooltip();
            t2.setText("Close File");
            closeFileBtn.setTooltip(t2);
            //final Tooltip t3 = new Tooltip();
            t3.setText("Save");
            SaveFileBtn.setTooltip(t3);

            //final Tooltip t4 = new Tooltip();
            t4.setText("Save As");
            SaveAsFileBtn.setTooltip(t4);

            //final Tooltip t5 = new Tooltip();
            t5.setText("Help");
            OpenHelpfile.setTooltip(t5);

            //final Tooltip t6 = new Tooltip();
            t6.setText("Zoom IN");
            ZoomAnBtn.setTooltip(t6);

            //final Tooltip t7 = new Tooltip();
            t7.setText("Zoom Out");
            ZoomOutFileBtn.setTooltip(t7);
            //final Tooltip t8 = new Tooltip();
            t8.setText("New OP");
            NewOP.setTooltip(t8);
            //final Tooltip t9 = new Tooltip();
            t9.setText("New JD");
            NewJD.setTooltip(t9);
            t10.setText("Link");
            link.setTooltip(t10);

            t11.setText("Delete");
            delete.setTooltip(t11);

            Insert_New_SubProcess.setText("Insert SubProcess");
            Update_Sub_Process.setText("Update SubProcess");
            JobTitleL.setText("Job Title");
            JobTitle.setPromptText("Ex:IT Administrator .");
            JobTypeL.setText("Job Type");
            JobType.setPromptText("Ex:Full Time .");
            JobLocationL.setText("Job Location");
            JobLocation.setPromptText("Ex:Cairo/Egypt .");
            JobManagerL.setText("Supervisor/Manager");
            JobManager.setPromptText("EX:IT Infrastructure Head .");
            LanguagesL.setText("Languages");
            ExperienceL.setText("Experience");
            Experience.setPromptText("Ex:3-5 Years .");
            JobQualificationL.setText("Qualifications");
            SkillsL.setText("Skills");
            Skills.setPromptText("Ex: Team work, work under pressure .");

            // Languages.setPromptText("Ex:English - Arabic .");
            SDescribtionL.setText("New SubProcess");
            SdescriptionL.setText("SubProcess Description");
            SCategoryL.setText("SubProcess Category");
            SNameL.setText("SubProcess Name");
            SSTDL.setText("SubProcess standard");
            langChoice.setText("SubProcess Language");
            SShortDL.setText("SubProcess Short Description");
            PDescriptionL.setText("Procedure Description");
            POwnerL.setText("Procedure Owner");
            PShortDL.setText("Procedure Short Description");
            PVersionL.setText("Procedure Version");
            Pdescription.setText("Operating Procedure");
            PSNameL.setText("Procedure Name");
            Jobdescription.setText("Job Description");

        });


        int MAX_CHARS = 20;


        Update_attributes();


        layout.setTop(topContainer);
        root.getChildren().add(layout);




        ProcessTree.addColumn("Process", "Process");
        ProcessTree.setupDataForProcess();

        EmployeesTree.addColumn("Employees", "Process");
        EmployeesTree.setupDataForEmployees();

        TasksTree.addColumn("Tasks", "Process");
        TasksTree.setupDataForTasks();

        DurationTree.addColumn("Duration", "Process");
        DurationTree.setupDataForDuration();


        ProcessTree.tree.setTranslateX(0);
        ProcessTree.tree.setTranslateY(0);


        TasksTree.tree.setTranslateX(0);
        TasksTree.tree.setTranslateY(0);

        EmployeesTree.tree.setTranslateX(1370);
        EmployeesTree.tree.setTranslateY(0);

        DurationTree.tree.setTranslateX(0);
        DurationTree.tree.setTranslateY(500);

        ProcessTree.tree.setMaxWidth(230);
        ProcessTree.tree.setPrefHeight(740);

        TasksTree.tree.setPrefHeight(740);
        TasksTree.tree.setMaxWidth(230);

        DurationTree.tree.setPrefHeight(740);
        DurationTree.tree.setMaxWidth(230);

        EmployeesTree.tree.setMaxWidth(230);
        EmployeesTree.tree.setPrefHeight(740);

        ProcessTree.tree.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (ProcessTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree && event.isShiftDown() && ((Modi_Tree) ProcessTree.tree.getTreeItem(ProcessTree.tree.getSelectionModel().getSelectedIndex())).Level != -44) {
                    int index = ProcessTree.tree.getSelectionModel().getSelectedIndex();
                    Modi_Label labex = new Modi_Label(((Modi_Tree) ProcessTree.tree.getTreeItem(index)));
                    root.getChildren().remove(SubProcess_Form_Root);
                    root.getChildren().remove(Process_Form_Root);
                    if (labex.Type_id == 0) {
                        MainProcess = labex.MP;
                    }
                    ;
                    if (((Modi_Tree) ProcessTree.tree.getTreeItem(index)).MP != null && ((Modi_Tree) ProcessTree.tree.getTreeItem(index)).MP.getShortDescription().matches("New Main Process")) {
                        System.out.println("Main Process foooooooooorm");
                        root.getChildren().add(Process_Form_Root);
                        prcess_form_Flag = true;
                        subProcess_form_flag = false;
                    } else if (((Modi_Tree) ProcessTree.tree.getTreeItem(index)).SP != null
                        //&& ((Modi_Tree) ProcessTree.tree.getTreeItem(index)).SP.getName().matches("New Sub Process")
                            ) {
                        System.out.println("Sub Process foooooooooorm");
                        root.getChildren().add(SubProcess_Form_Root);
                        Operation.getItems().remove(Update_Sub_Process);
                        if (((Modi_Tree) ProcessTree.tree.getTreeItem(index)).Level == -4) {
                            Operation.getItems().remove(Update_Sub_Process);
                        } else {
                            Operation.getItems().add(Update_Sub_Process);

                        }
                        subProcess_form_flag = true;
                        prcess_form_Flag = false;

                    } else {
                        if (prcess_form_Flag == true) {
                            root.getChildren().add(Process_Form_Root);

                        } else if (subProcess_form_flag == true) {
                            root.getChildren().add(SubProcess_Form_Root);
                            Operation.getItems().add(Insert_New_SubProcess);
                            Operation.getItems().add(Update_Sub_Process);
                        }
                    }
                }
            }
        });
        final Label label = new Label("Address Book");
        label.setFont(new Font("Arial", 20));

        EmployeesTree.tree.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (EmployeesTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree && event.isShiftDown()) {
                    int index = EmployeesTree.tree.getSelectionModel().getSelectedIndex();
                    Modi_Label labex = new Modi_Label(((Modi_Tree) EmployeesTree.tree.getTreeItem(index)));
                    Operation.getItems().remove(Save_Employee_Tasks);
                    Operation.getItems().remove(Insert_Employee);
                    if (((Modi_Tree<Map<String, Object>>) EmployeesTree.tree.getTreeItem(index)).EM.getRole().matches("_New Employee_J1")) {
                        //System.out.println("Hoba Lala");
                        //     root.getChildren().removeAll(Save_Employee_Tasks);
                    } else {
                        Operation.getItems().add(Save_Employee_Tasks);
                    }
                    Operation.getItems().add(Insert_Employee);

                }
            }
        });
        TasksTree.tree.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (TasksTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree && event.isShiftDown()) {
                    int index = TasksTree.tree.getSelectionModel().getSelectedIndex();
                    Modi_Label labex = new Modi_Label(((Modi_Tree) TasksTree.tree.getTreeItem(index)));
                }
            }
        });


        DurationTree.tree.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (DurationTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree && event.isShiftDown()) {
                    int index = DurationTree.tree.getSelectionModel().getSelectedIndex();
                    Modi_Label labex = new Modi_Label(((Modi_Tree) DurationTree.tree.getTreeItem(index)));
                }
            }
        });
        DurationTree.tree.setRowFactory(t -> {
            TreeTableRow<Map<String, Object>> cell = new TreeTableRow<Map<String, Object>>() {
                @Override
                public void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setTooltip(null);
                    } else if (!empty) {
                        setTooltip(new Tooltip(((Modi_Tree<Map<String, Object>>) getTreeItem()).Desc));
                    }
                }
            };
            return cell;
        });



        ProcessTree.tree.setRowFactory(t -> {
            TreeTableRow<Map<String, Object>> cell = new TreeTableRow<Map<String, Object>>() {
                @Override
                public void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        // setText(null);
                        setTooltip(null);
                    } else if (!empty) {
                        //   setText("Sub");
                        setTooltip(new Tooltip(((Modi_Tree<Map<String, Object>>) getTreeItem()).Desc));
                    }
                }
            };
            return cell;
        });

        ProcessTree.tree.setRowFactory(t -> {
            TreeTableRow<Map<String, Object>> cell = new TreeTableRow<Map<String, Object>>() {
                @Override
                public void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        // setText(null);
                        setTooltip(null);
                    } else if (!empty) {
                        //   setText("Sub");
                        setTooltip(new Tooltip(((Modi_Tree<Map<String, Object>>) getTreeItem()).Desc));
                    }
                }
            };
            return cell;
        });

        EmployeesTree.tree.setRowFactory(t -> {
            TreeTableRow<Map<String, Object>> cell = new TreeTableRow<Map<String, Object>>() {
                @Override
                public void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        // setText(null);
                        setTooltip(null);
                    } else if (!empty) {
                        //   setText("Sub");
                        setTooltip(new Tooltip(((Modi_Tree<Map<String, Object>>) getTreeItem()).Desc));
                    }
                }
            };
            return cell;
        });

        TasksTree.tree.setRowFactory(t -> {
            TreeTableRow<Map<String, Object>> cell = new TreeTableRow<Map<String, Object>>() {
                @Override
                public void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        // setText(null);
                        setTooltip(null);
                    } else if (!empty) {
                        //   setText("Sub");
                        setTooltip(new Tooltip(((Modi_Tree<Map<String, Object>>) getTreeItem()).Desc));
                    }
                }
            };
            return cell;
        });
        Parent zoomPane = createZoomPane(root);

        VBox layout1 = new VBox();
        //layout1.setPadding(new Insets(0, 0, 0, 0));
        //layout1.setAlignment(Pos.BASELINE_LEFT);
        //layout1.setMargin(root,new Insets(0,0,0,0));
        //System.out.println("Margiiiiiiiiiin" + layout1.getSpacing());
        layout1.getChildren().setAll(topContainer,zoomPane);

        VBox.setVgrow(zoomPane, Priority.ALWAYS);
        Scene scene_w = new Scene(layout1);
        sx=scene_w;
        scene_w.setOnMouseMoved(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (start != -1 && event.isShiftDown()) {
                    System.out.println("Draw");
                    Dummy_Line.Start_ConnectionBetweenNodeAndMouse(start, Dummy_Line, event);
                    root.getChildren().remove(Dummy_Line);
                    root.getChildren().add(Dummy_Line);
                } else {
                    // System.out.println("Don't Draw");
                    root.getChildren().remove(Dummy_Line);
                }
                //   System.out.println("the mouse is moving bro");
            }
        });


        EmployeesTree.tree.setRowFactory(t -> {
            TreeTableRow<Map<String, Object>> cell = new TreeTableRow<Map<String, Object>>() {
                @Override
                public void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        // setText(null);
                        setTooltip(null);
                    } else if (!empty) {
                        //   setText("Sub");
                        setTooltip(new Tooltip(((Modi_Tree<Map<String, Object>>) getTreeItem()).Desc));
                    }
                }
            };
            return cell;
        });


        ProcessTree.tree.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (ProcessTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree) {
                    System.out.println("setOnMouseDragged");
                    int index = ProcessTree.tree.getSelectionModel().getSelectedIndex();
                    DragedTreeItem = ((Modi_Tree) ProcessTree.tree.getTreeItem(index));
                    scene_w.setCursor(Cursor.CLOSED_HAND);
                }
            }
        });


        ProcessTree.tree.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (ProcessTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree && DragedTreeItem != null && ((Modi_Tree) DragedTreeItem).Level != -44 && inserting_one_new_only(DragedTreeItem)) {
                    //  int index = ProcessTree.tree.getSelectionModel().getSelectedIndex();
                    Modi_Label labex = new Modi_Label(DragedTreeItem);

                    if (DragedTreeItem.Level == -11) {
                        addresssave="";
                        addressoben="";
                        File1 fileDrgged = DragedTreeItem.f;
                        byte[] f = fileDrgged.getFiles();
                        try {
                            File fx = new File("y.opd");
                            FileOutputStream fos = new FileOutputStream(fx, false);
                            fos.write(f);
                            openDragged(Labels_vector, Lines_vector, fx);

                            fos.close();
                        } catch (Exception error) {
                            error.printStackTrace();
                        }

                    } else {
                        labex.relocate(event.getSceneX(), event.getSceneY());
                    /*Operation.getItems().remove(Save_Process);
                    Operation.getItems().remove(Insert_New_SubProcess);
                    Operation.getItems().remove(Update_Sub_Process);
                    */
                        Operation.getItems().clear();
                        root.getChildren().remove(Process_Form_Root);
                        if (labex.Type_id == 0) {
                            MainProcess = labex.MP;
                        }
                        if (((Modi_Tree) DragedTreeItem).MP != null && ((Modi_Tree) DragedTreeItem).MP.getShortDescription().matches("New Main Process")) {

                            System.out.println("Main Process foooooooooorm");
                            root.getChildren().remove(SubProcess_Form_Root);
                            root.getChildren().add(Process_Form_Root);
                            Operation.getItems().add(Save_Process);
                            prcess_form_Flag = true;
                            subProcess_form_flag = false;
                            DragedTreeItem = null;


                        } else if (((Modi_Tree) DragedTreeItem).SP != null
                                && ((Modi_Tree) DragedTreeItem).SP.getShortDescription().matches("New Sub Process")
                                ) {
                            System.out.println("Sub Process foooooooooorm");
                            root.getChildren().remove(Process_Form_Root);
                            root.getChildren().add(SubProcess_Form_Root);
                            Operation.getItems().remove(Save_Process);
                            Operation.getItems().add(Insert_New_SubProcess);
                            prcess_form_Flag = false;
                            subProcess_form_flag = true;
                            // SubProcess_Form_Root.getChildren().remove(Update_Sub_Process);
                            if (((Modi_Tree) DragedTreeItem).Level == -4) {
                                //  SubProcess_Form_Root.getChildren().remove(Update_Sub_Process);
                            } else {
                                Operation.getItems().add(Update_Sub_Process);
                            }
                            subProcess_form_flag = true;
                            prcess_form_Flag = false;
                            DragedTreeItem = null;


                        } else {
                            if (prcess_form_Flag == true) {
                                System.out.println("i am here");
                                root.getChildren().remove(Process_Form_Root);
                                root.getChildren().remove(SubProcess_Form_Root);

                                root.getChildren().add(Process_Form_Root);
                                Operation.getItems().add(Save_Process);
                            } else if (subProcess_form_flag == true) {
                                System.out.println("i am here2");

                                root.getChildren().remove(Process_Form_Root);
                                root.getChildren().remove(SubProcess_Form_Root);

                                root.getChildren().add(SubProcess_Form_Root);
                                Operation.getItems().add(Insert_New_SubProcess);

                            }
                        }
                    }
                }
                scene_w.setCursor(Cursor.DEFAULT);
                DragedTreeItem = null;

            }
        });


        EmployeesTree.tree.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (((Modi_Tree<Map<String,Object>>) EmployeesTree.tree.getSelectionModel().getSelectedItem()).EM.getRole().equals("_New Employee_J1")) {
                    System.out.println("setOnMouseDragged");
                    int index = EmployeesTree.tree.getSelectionModel().getSelectedIndex();
                    DragedTreeItem = ((Modi_Tree) EmployeesTree.tree.getTreeItem(index));
                    scene_w.setCursor(Cursor.CLOSED_HAND);

                }
                if(!EmployeeScene && EmployeesTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree)
                {
                    System.out.println("setOnMouseDragged");
                    int index = EmployeesTree.tree.getSelectionModel().getSelectedIndex();
                    DragedTreeItem = ((Modi_Tree) EmployeesTree.tree.getTreeItem(index));
                    scene_w.setCursor(Cursor.CLOSED_HAND);
                }
            }
        });


        TasksTree.tree.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.println("Drag task");
                if (TasksTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree) {
                    System.out.println("setOnMouseDragged");
                    int index = TasksTree.tree.getSelectionModel().getSelectedIndex();
                    DragedTreeItem = ((Modi_Tree) TasksTree.tree.getTreeItem(index));
                    scene_w.setCursor(Cursor.CLOSED_HAND);
                }
            }
        });

        TasksTree.tree.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (DragedTreeItem != null && DragedTreeItem.Level != -44 && inserting_one_new_only(DragedTreeItem)) {
                    Modi_Label labex = new Modi_Label(DragedTreeItem);

                    if(DragedTreeItem.Level == -11){
                        addresssave="";
                        addressoben="";
                        File1 fileDrgged = DragedTreeItem.f;
                        byte[] f = fileDrgged.getFiles();
                        try{
                            File fx = new File("y.jd");
                            FileOutputStream fos = new FileOutputStream(fx,false);
                            fos.write(f);
                            openDragged(Labels_vector, Lines_vector, fx);

                            fos.close();
                        }catch(Exception error){
                            error.printStackTrace();
                        }

                    }
                    //System.out.println("release");
                    //  kk=0;
                    else {
                        labex.relocate(event.getSceneX(), event.getSceneY());
                    }
                }
                scene_w.setCursor(Cursor.DEFAULT);
                DragedTreeItem = null;
            }
        });

        EmployeesTree.tree.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (DragedTreeItem != null && inserting_one_new_only(DragedTreeItem)) {
                    System.out.println("release");
                    //  kk=0;
                    Modi_Label labex = new Modi_Label(DragedTreeItem);
                    labex.relocate(event.getSceneX(), event.getSceneY());
                    Operation.getItems().remove(Save_Employee_Tasks);
                    Operation.getItems().remove(Insert_Employee);
                    if (((Modi_Tree<Map<String, Object>>) DragedTreeItem).EM.getRole().matches("_New Employee_J1")) {
                        //System.out.println("Hoba Lala");
                        //     root.getChildren().removeAll(Save_Employee_Tasks);
                    } else {
                        if (EmployeeScene) {
                            Operation.getItems().add(Save_Employee_Tasks);
                        }
                    }
                    if (EmployeeScene)
                        Operation.getItems().add(Insert_Employee);
                }
                scene_w.setCursor(Cursor.DEFAULT);
                DragedTreeItem = null;
            }
        });


        DurationTree.tree.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (DurationTree.tree.getSelectionModel().getSelectedItem() instanceof Modi_Tree) {
                    //  System.out.println("setOnMouseDragged");
                    int index = DurationTree.tree.getSelectionModel().getSelectedIndex();
                    DragedTreeItem = ((Modi_Tree) DurationTree.tree.getTreeItem(index));
                    scene_w.setCursor(Cursor.CLOSED_HAND);
                }
            }
        });

        DurationTree.tree.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (DragedTreeItem != null) {
//                    if(DragedTreeItem.Level == -11){
//                        File1 fileDrgged = DragedTreeItem.f;
//                        byte[] f = fileDrgged.getFiles();
//                        try{
//                            File fx = new File("y.jd");
//                            FileOutputStream fos = new FileOutputStream(fx,false);
//                            fos.write(f);
//                            addressoben = openDragged(Labels_vector, Lines_vector, fx);
//
//                            fos.close();
//                        }catch(Exception error){
//                            error.printStackTrace();
//                        }
//
//                    }
//                    else {
                    Modi_Label labex = new Modi_Label(DragedTreeItem);
                    labex.relocate(event.getSceneX(), event.getSceneY());
                    //}
                }
                scene_w.setCursor(Cursor.DEFAULT);
                DragedTreeItem = null;
            }
        });



        layout1.setOnDragOver(event -> {
            // On drag over if the DragBoard has files
            if (event.getGestureSource() != root && event.getDragboard().hasFiles()) {
                // All files on the dragboard must have an accepted extension
                if (!validExtensions.containsAll(
                        event.getDragboard().getFiles().stream()
                                .map(file -> getExtension(file.getName()))
                                .collect(Collectors.toList()))) {

                    event.consume();
                    return;
                }

                // Allow for both copying and moving
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });
        layout1.setOnDragDropped(event -> {
            boolean success = false;
            if (event.getGestureSource() != root && event.getDragboard().hasFiles() ) {
                // Print files

                event.getDragboard().getFiles().forEach(file -> System.out.println(file.getAbsolutePath()));
                List<File> x = event.getDragboard().getFiles();
                for(int i =0 ; i<x.size();i++) {
                    try {
                        addressoben = openDragged(Labels_vector, Lines_vector, x.get(i));
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }

                success = true;
            }
            event.setDropCompleted(success);
            event.consume();
        });
        AddKeyPress(root);

        stage.setScene(scene_w);
        stage.setTitle("Procedures Designer");
        stage.setOnCloseRequest(e -> {
            if (araabc == false) {
                e.consume();
                closeProgram(stage, RecentOpenn);
            } else {
                e.consume();
                closeProgramArabc(stage, RecentOpenn);
            }
        });

        stage.setMaximized(true);
        stage.getIcons().add(Main_ICON);
        stagedummy=stage;
        stage.show();
        /*WritableImage snapshot = root.getScene().snapshot(null);
        //  ((ImageView) snapshot).setImage("Desktop");
        File file = new File("chsdgs1.png");
        try {
            //     BufferedImage bImage = SwingFXUtils.fromFXImage(image, null);
            //    ImageIO.write(bImage, "png", file);
            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);


        } catch (Exception s) {
            System.out.println(s);
        }*/

    }
    private String getExtension(String fileName){
        String extension = "";

        int i = fileName.lastIndexOf('.');
        if (i > 0 && i < fileName.length() - 1) //if the name is not empty
            return fileName.substring(i + 1).toLowerCase();

        return extension;
    }
    private Parent createZoomPane(final Group group) {
        final double SCALE_DELTA = 1.1;
        final StackPane zoomPane = new StackPane();
        zoomPane.getChildren().add(group);
        zoomPane.setAlignment(group,Pos.TOP_LEFT);

        final ScrollPane scroller = new ScrollPane();
        final Group scrollContent = new Group(zoomPane);
        //System.out.println("heiiiggggght"+zoomPane.getMaxHeight());
        scroller.setContent(scrollContent);

        scroller.viewportBoundsProperty().addListener(new ChangeListener<Bounds>() {
            @Override
            public void changed(ObservableValue<? extends Bounds> observable,
                                Bounds oldValue, Bounds newValue) {
                zoomPane.setMinSize(newValue.getWidth(), newValue.getHeight());
            }
        });

        scroller.setPrefViewportWidth(265);
        scroller.setPrefViewportHeight(265);

        zoomPane.setOnScroll(new EventHandler<ScrollEvent>() {
            @Override
            public void handle(ScrollEvent event) {
                event.consume();

                if (event.getDeltaY() == 0) {
                    return;
                }

                double scaleFactor = (event.getDeltaY() > 0) ? SCALE_DELTA
                        : 1 / SCALE_DELTA;

                // amount of scrolling in each direction in scrollContent coordinate
                // units
                Point2D scrollOffset = figureScrollOffset(scrollContent, scroller);

                group.setScaleX(group.getScaleX() * scaleFactor);
                group.setScaleY(group.getScaleY() * scaleFactor);

                // move viewport so that old center remains in the center after the
                // scaling
                repositionScroller(scrollContent, scroller, scaleFactor, scrollOffset);

            }
        });

        // Panning via drag....
        final ObjectProperty<Point2D> lastMouseCoordinates = new SimpleObjectProperty<Point2D>();
        scrollContent.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                lastMouseCoordinates.set(new Point2D(event.getX(), event.getY()));
            }
        });

   /*     scrollContent.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                double deltaX = event.getX() - lastMouseCoordinates.get().getX();
                double extraWidth = scrollContent.getLayoutBounds().getWidth() - scroller.getViewportBounds().getWidth();
                double deltaH = deltaX * (scroller.getHmax() - scroller.getHmin()) / extraWidth;
                double desiredH = scroller.getHvalue() - deltaH;
                scroller.setHvalue(Math.max(0, Math.min(scroller.getHmax(), desiredH)));

                double deltaY = event.getY() - lastMouseCoordinates.get().getY();
                double extraHeight = scrollContent.getLayoutBounds().getHeight() - scroller.getViewportBounds().getHeight();
                double deltaV = deltaY * (scroller.getHmax() - scroller.getHmin()) / extraHeight;
                double desiredV = scroller.getVvalue() - deltaV;
                scroller.setVvalue(Math.max(0, Math.min(scroller.getVmax(), desiredV)));
            }
        });*/

        return scroller;
    }

    private Point2D figureScrollOffset(Node scrollContent, ScrollPane scroller) {
        double extraWidth = scrollContent.getLayoutBounds().getWidth() - scroller.getViewportBounds().getWidth();
        double hScrollProportion = (scroller.getHvalue() - scroller.getHmin()) / (scroller.getHmax() - scroller.getHmin());
        double scrollXOffset = hScrollProportion * Math.max(0, extraWidth);
        double extraHeight = scrollContent.getLayoutBounds().getHeight() - scroller.getViewportBounds().getHeight();
        double vScrollProportion = (scroller.getVvalue() - scroller.getVmin()) / (scroller.getVmax() - scroller.getVmin());
        double scrollYOffset = vScrollProportion * Math.max(0, extraHeight);
        return new Point2D(scrollXOffset, scrollYOffset);
    }

    private void repositionScroller(Node scrollContent, ScrollPane scroller, double scaleFactor, Point2D scrollOffset) {
        double scrollXOffset = scrollOffset.getX();
        double scrollYOffset = scrollOffset.getY();
        double extraWidth = scrollContent.getLayoutBounds().getWidth() - scroller.getViewportBounds().getWidth();
        if (extraWidth > 0) {
            double halfWidth = scroller.getViewportBounds().getWidth() / 2 ;
            double newScrollXOffset = (scaleFactor - 1) *  halfWidth + scaleFactor * scrollXOffset;
            scroller.setHvalue(scroller.getHmin() + newScrollXOffset * (scroller.getHmax() - scroller.getHmin()) / extraWidth);
        } else {
            scroller.setHvalue(scroller.getHmin());
        }
        double extraHeight = scrollContent.getLayoutBounds().getHeight() - scroller.getViewportBounds().getHeight();
        if (extraHeight > 0) {
            double halfHeight = scroller.getViewportBounds().getHeight() / 2 ;
            double newScrollYOffset = (scaleFactor - 1) * halfHeight + scaleFactor * scrollYOffset;
            scroller.setVvalue(scroller.getVmin() + newScrollYOffset * (scroller.getVmax() - scroller.getVmin()) / extraHeight);
        } else {
            scroller.setHvalue(scroller.getHmin());
        }

    }
    private void refreshh(Stage stage) {

        //   Task task = new Task() {
        //  @Override
        //protected Integer call() throws Exception {
        //    sx.setCursor(Cursor.WAIT); //Change cursor to wait style
        ProcessTree.TT = new Test_Data();
        DurationTree.TT=new Test_Data();
        EmployeesTree.TT = new Test_Data();
        TasksTree.TT = new Test_Data();
        ProcessTree.root.getChildren().clear();
        DurationTree.root.getChildren().clear();
        EmployeesTree.root.getChildren().clear();
        TasksTree.root.getChildren().clear();
        ProcessTree.setupDataForProcess();
        DurationTree.setupDataForDuration();
        EmployeesTree.setupDataForEmployees();
        TasksTree.setupDataForTasks();
        if (EmployeeScene) {
            Update_attributes();
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i) != null && Labels_vector.get(i).Type_id == 1&& Labels_vector.get(i).Datee.matches("false")) {
                    Labels_vector.get(i).setText(JobTitle.getText());
                }
            }
        } else {
            for (int i = 0; i < Labels_vector.size(); i++)
                if (Labels_vector.get(i) != null && Labels_vector.get(i).Type_id % 2 == 0&& Labels_vector.get(i).Datee.matches("false")) {
                    Labels_vector.get(i).setText(SName.getText());
                }
        }

//                sx.setCursor(Cursor.DEFAULT); //Change cursor to default style
//                return 0;
//            }
//        };
//        Thread th = new Thread(task);
//        th.setDaemon(true);
//        th.start();

    }

   /* private void refreshh(Stage stage) {

        Task task = new Task() {
            @Override
            protected Integer call() throws Exception {
                sx.setCursor(Cursor.WAIT); //Change cursor to wait style
                ProcessTree.TT = new Test_Data();
                EmployeesTree.TT = new Test_Data();
                TasksTree.TT = new Test_Data();
                ProcessTree.root.getChildren().clear();
                EmployeesTree.root.getChildren().clear();
                TasksTree.root.getChildren().clear();
                ProcessTree.setupDataForProcess();
                EmployeesTree.setupDataForEmployees();
                TasksTree.setupDataForTasks();
                if (EmployeeScene) {
                    Update_attributes();
                    for (int i = 0; i < Labels_vector.size(); i++) {
                        if (Labels_vector.get(i) != null && Labels_vector.get(i).Type_id == 1) {
                            Labels_vector.get(i).setText(JobTitle.getText());
                        }
                    }
                } else {
                    for (int i = 0; i < Labels_vector.size(); i++)
                        if (Labels_vector.get(i) != null && Labels_vector.get(i).Type_id % 2 == 0) {
                            Labels_vector.get(i).setText(SName.getText());
                        }
                }
                sx.setCursor(Cursor.DEFAULT); //Change cursor to default style
                return 0;
            }
        };
        Thread th = new Thread(task);
        th.setDaemon(true);
        th.start();

    }*/


    public void Update_attributes() {
        DB db2 = new DB();
        List<String> jobTypeStrings = new ArrayList<String>(db2.getJobType());
        List<String> jobLocationStrings = new ArrayList<String>(db2.getJopLocation());
        List<String> jobLanguages = new ArrayList<String>(db2.getLanguages());
        List<String> jobExperiences = new ArrayList<String>(db2.getExperience());
        List<String> SubSTDS = new ArrayList<String>(db2.getSTDS());

        for (int i = 0; i < jobTypeStrings.size(); i++) {
            //  if(jobTypeStrings.get(i).isEmpty()==false)
            JobType.getItems().add(jobTypeStrings.get(i));
        }

        for (int i = 0; i < jobLocationStrings.size(); i++) {
            // if(jobLocationStrings.get(i).isEmpty()==false)
            JobLocation.getItems().add(jobLocationStrings.get(i));
        }

        for (int i = 0; i < jobExperiences.size(); i++) {
            //  if(jobExperiences.get(i).isEmpty()==false)
            Experience.getItems().add(jobExperiences.get(i));
        }

        for (int i = 0; i < jobLanguages.size(); i++) {
//            if(jobLanguages.get(i).isEmpty()==false)
            Languages.getItems().add(jobLanguages.get(i));
        }

        for (int i = 0; i < SubSTDS.size(); i++) {
            SSTD.getItems().add(SubSTDS.get(i));
        }
    }


    private boolean inserting_one_new_only(Modi_Tree Tree) {
        boolean The_Tree_IS_NEw = false;
        boolean There_is_a_new = false;
        for (int i = 0; i < Labels_vector.size(); i++) {
            if (Labels_vector.get(i) != null) {
                if (Labels_vector.get(i).Type_id == 0 || Labels_vector.get(i).getText().matches("New Employee") || Labels_vector.get(i).Type_id == -4) {
                    There_is_a_new = true;
                    break;
                }
            }
        }
        if (Tree.Level == 0 || Tree.Level == -4) {
            The_Tree_IS_NEw = true;
        } else if (Tree.EM != null && Tree.EM.getRole().matches("_New Employee_J1")) {
            The_Tree_IS_NEw = true;
        }
        ;
        if (The_Tree_IS_NEw && There_is_a_new) {
            return false;
        } else {
            return true;
        }
    }

   /* public Boolean Only_One_EMployee_In_JD() {
        for (int i = 0; i < Labels_vector.size(); i++) {
            if (Labels_vector.get(i).Type_id == 1 && EmployeeScene) {
                return false;
            }
        }
        return true;
    }*/

    private void clearr() {
        Operation.getItems().clear();
        langCat.setValue("English");
        root.getChildren().clear();
        root.getChildren().add(layout);
        JobLocation.getEditor().clear();
        JobType.getEditor().clear();
        JobTitle.clear();
        JobManager.clear();
        JobQualification.clear();
        PDescription.clear();
        PName.clear();
        POwner.clear();
        PShortD.clear();
        PVersion.clear();
        Languages.getEditor().clear();
        Skills.clear();
        SSTD.getEditor().clear();
        Experience.getEditor().clear();
        SCategory.clear();
        Sdescription.clear();
        SName.clear();
        SShortD.clear();
        Labels_vector.clear();
        Lines_vector.clear();
        MainProcess = null;
        prcess_form_Flag = false;
        subProcess_form_flag = false;
        addresssave="";
        addressoben="";
    }
    private void saveFileDb(String p)
    {
        DB db = new DB();
        String path = p;
        // FileChooser fc2 = new FileChooser();
        //fc.selectedExtensionFilterProperty();
        //  fc2.setTitle("Open Resource File");
        //  File file = fc2.showOpenDialog(stage);
        //path = file.getPath();
        File f1 = new File(path);
        String name = f1.getName();
        byte[] bFile = new byte[(int) f1.length()];
        try {
            FileInputStream fileInputStream = new FileInputStream(f1);
            //convert file into array of bytes
            fileInputStream.read(bFile);
            fileInputStream.close();
        } catch (Exception error) {
            error.printStackTrace();
        }
        File1 f = new File1();
        f.setFiles(bFile);
        f.setName(name);
        if(name.contains(".jd"))
        {
            f.setType(1);
        }
        else if (name.contains(".opd"))
        {
            f.setType(0);
        }
        int y=0;
        List<File1> allFiles = new ArrayList<>(db.getAllFiles());
        for(int i=0;i<allFiles.size();i++)
        {
            if(allFiles.get(i).getName().equals(f.getName()) && allFiles.get(i).getType() == f.getType())
            {
                System.out.println("filee"+f.getName());
                f.setIdfiles(allFiles.get(i).getIdfiles());
                db.update_file(f);
                y=0;
                break;
            }
            else {
                y=1;
            }
        }

        if(y==1 || allFiles.size() == 0)
        {
            db.AddFile(f);
        }

    }
    private void oPenProgram(Menu m, Vector<Modi_Label> Labelss_vector, Vector<Modi_Line> tem, Stage primaryStage) {
        try {
            FileInputStream fi = new FileInputStream(new File("myText2"));
            ObjectInputStream oi = new ObjectInputStream(fi);
            int sze = oi.read();
            System.out.println(sze);
            int recentOpensze = 0;
            if (sze > 8) {
                recentOpensze = sze - 8;
            }
            for (int i = recentOpensze; i < sze; i++) {
                N_Menu_item ne = new N_Menu_item("new");
                ne.set(oi.readObject().toString());
                ne.setText(oi.readObject().toString());
                ne.setOnAction(e -> {
                    addressoben = ne.getPath();
                    OpenActon(Labelss_vector, tem, primaryStage, ne.getPath());
                });
                m.getItems().add(ne);
            }
            oi.close();
            fi.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    private void closeProgram(Stage stage, Menu m) {
        boolean answer = ConfirmBox.display("Exit  ", "Are you sure ?");
        try {

            FileOutputStream f = new FileOutputStream("myText2");
            ObjectOutputStream o = new ObjectOutputStream(f);

            o.write(m.getItems().size());
            System.out.println(m.getItems().size());
            for (int i = 0; i < m.getItems().size(); i++) {
                o.writeObject(((N_Menu_item) m.getItems().get(i)).getPath());
                o.writeObject(m.getItems().get(i).getText());

            }
            // Always close files.
            f.close();
            o.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (answer) {

            stage.close();
        }
    }


    private void addMeuetem(Menu m, String
            bath, Vector<Modi_Label> Labelss_vector, Vector<Modi_Line> tem, Stage primaryStage, String name) {
        //myText
        boolean found = false;
        for (int i = 0; i < m.getItems().size(); i++) {
            if (name.equalsIgnoreCase(m.getItems().get(i).getText())) {
                found = true;
            }
        }
        if (found == false) {
            N_Menu_item newtem = new N_Menu_item(name);
            newtem.set(bath);
            newtem.setOnAction(e -> {
                addressoben = bath;
                OpenActon(Labelss_vector, tem, primaryStage, bath);
            });
            if (m.getItems().size() < 8) {
                m.getItems().add(newtem);
            } else {
                m.getItems().remove(0, 1);
                m.getItems().add(newtem);
            }
        }
    }

    private void closeProgramArabc(Stage stage, Menu m) {
        boolean answer = ConfirmBoxArabic.display("??????", "?? ??? ????? ??? ???? ???????");
        try {

            FileOutputStream f = new FileOutputStream("myText2");
            ObjectOutputStream o = new ObjectOutputStream(f);
            o.write(m.getItems().size());

            for (int i = 0; i < m.getItems().size(); i++) {
                o.writeObject(((N_Menu_item) m.getItems().get(i)).getPath());
                o.writeObject(m.getItems().get(i).getText());

            }
            // Always close files.
            f.close();
            o.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (answer) {
            stage.close();
        }
    }

    private void Savesave(String bath) {
        try {
           /* char flag;

            if (EmployeeScene == true) {
                flag = 'j';

            } else {
                flag = 'p';
            }*/
            FileInputStream fi = new FileInputStream(new File(bath));
            ObjectInputStream oi = new ObjectInputStream(fi);
            char flag = oi.readChar();
            fi.close();
            oi.close();

            FileOutputStream f = new FileOutputStream(bath);
            ObjectOutputStream o = new ObjectOutputStream(f);

            // Write objects to file

            o.writeChar(flag);
            o.write(Labels_vector.size());
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i) == null) {
                    Modi_Label tem = new Modi_Label(false);
                    o.writeObject(tem);
                    o.writeDouble(-1);
                    o.writeDouble(-1);

                } else {
                    Labels_vector.get(i).Namee = Labels_vector.get(i).getText();
                    o.writeObject(Labels_vector.get(i));
                    o.writeDouble(Labels_vector.get(i).getTranslateX() + Labels_vector.get(i).layoutXProperty().getValue());
                    o.writeDouble(Labels_vector.get(i).getTranslateY() + Labels_vector.get(i).layoutYProperty().getValue());
                }
            }
            o.write(Lines_vector.size());

            for (int i = 0; i < Lines_vector.size(); i++) {
                if (Lines_vector.get(i) == null) {
                    Modi_Line tem = new Modi_Line(false);
                    o.writeObject(tem);

                } else {
                    o.writeObject(Lines_vector.get(i));
                }
            }
            if (flag == 'j') {
                o.writeObject(JobTitle.getText());
                o.writeObject(JobType.getValue());
                o.writeObject(JobLocation.getEditor().getText());
                o.writeObject(JobManager.getText());
                o.writeObject(JobQualification.getText());
                o.writeObject(Experience.getEditor().getText());
                o.writeObject(Skills.getText());
                o.writeObject(Languages.getEditor().getText());

            } else if (flag == 'p') {
                o.writeObject(PDescription.getText());
                o.writeObject(PShortD.getText());
                o.writeObject(POwner.getText());
                o.writeObject(PVersion.getText());
                o.writeObject(PName.getText());
            }
            o.close();
            f.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String Savee(Stage primaryStage) {
        String str = "";
        FileChooser fc1 = new FileChooser();

        fc1.setTitle("Save");
        char flag;
        try {
            if (EmployeeScene == true) {
                flag = 'j';
                fc1.getExtensionFilters().add(new FileChooser.ExtensionFilter("JD File", "*.jd"));
                fc1.setInitialFileName(JobTitle.getText());

            } else {
                flag = 'p';
                fc1.getExtensionFilters().add(new FileChooser.ExtensionFilter("OPD File", "*.opd"));
                fc1.setInitialFileName(PName.getText());

            }

            File file = fc1.showSaveDialog(primaryStage);
            str = file.getPath();
            FileOutputStream f = new FileOutputStream(str);
            ObjectOutputStream o = new ObjectOutputStream(f);


            o.writeChar(flag);
            // Write objects to file
            o.write(Labels_vector.size());
            for (int i = 0; i < Labels_vector.size(); i++) {
                if (Labels_vector.get(i) == null) {
                    Modi_Label tem = new Modi_Label(false);
                    o.writeObject(tem);
                    o.writeDouble(-1);
                    o.writeDouble(-1);

                } else {
                    Labels_vector.get(i).Namee = Labels_vector.get(i).getText();
                    o.writeObject(Labels_vector.get(i));
                    o.writeDouble(Labels_vector.get(i).getTranslateX() + Labels_vector.get(i).layoutXProperty().getValue());
                    o.writeDouble(Labels_vector.get(i).getTranslateY() + Labels_vector.get(i).layoutYProperty().getValue());
                }
            }
            o.write(Lines_vector.size());

            for (int i = 0; i < Lines_vector.size(); i++) {
                if (Lines_vector.get(i) == null) {
                    Modi_Line tem = new Modi_Line(false);
                    o.writeObject(tem);

                } else {
                    o.writeObject(Lines_vector.get(i));
                }
            }
            if (flag == 'j') {
                o.writeObject(JobTitle.getText());
                o.writeObject(JobType.getValue());
                o.writeObject(JobLocation.getEditor().getText());
                o.writeObject(JobManager.getText());
                o.writeObject(JobQualification.getText());
                o.writeObject(Experience.getEditor().getText());
                o.writeObject(Skills.getText());
                o.writeObject(Languages.getEditor().getText());

            } else if (flag == 'p') {
                o.writeObject(PDescription.getText());
                o.writeObject(PShortD.getText());
                o.writeObject(POwner.getText());
                o.writeObject(PVersion.getText());
                o.writeObject(PName.getText());
            }

            o.close();
            f.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }

    private String Openn(Vector<Modi_Label> Labelss_vector, Vector<Modi_Line> tem, Stage primaryStage, Menu m) {
        String bath = "";
        FileChooser fc2 = new FileChooser();
        Vector<Modi_Line> Liness_vector = new Vector<Modi_Line>();
        //root.getChildren().clear();
        try {
            //fc.selectedExtensionFilterProperty();
            fc2.setTitle("Open Resource File");
            File file = fc2.showOpenDialog(primaryStage);
            bath = file.getPath();

            addMeuetem(m, bath, Labelss_vector, tem, primaryStage, file.getName());

            FileInputStream fi = new FileInputStream(new File(file.getPath()));
            ObjectInputStream oi = new ObjectInputStream(fi);

            root.getChildren().clear();
            root.getChildren().add(layout);
            root.getChildren().add(checkButton);

            Labels_vector.clear();
            Lines_vector.clear();
            // Read objects
            char flag = oi.readChar();
            System.out.println("flaaaaaaaaaaaag is" + flag);
            if (flag == 'j') {

                System.out.println(flag);
                fleMenue4.getItems().clear();
                fleMenue4.getItems().add(GenerateJD);
                fleMenue4.getItems().add(GeneratePdf);
                Operation.getItems().remove(Insert_Employee);

                root.getChildren().addAll(EmployeesTree.tree, TasksTree.tree, Jobdescription, JobLocation, JobManager, JobQualification, JobTitle, JobType, Languages, Skills, JobLocationL, JobManagerL, JobQualificationL, JobTitleL, JobTypeL, LanguagesL, SkillsL, Experience, ExperienceL);
            } else {
                Operation.getItems().clear();
                Operation.getItems().add(Save_Process2);
                fleMenue4.getItems().clear();
                fleMenue4.getItems().add(GenerateOP);
                fleMenue4.getItems().add(GeneratePdf);

                System.out.println(flag);
                root.getChildren().remove(SubProcess_Form_Root);
                root.getChildren().add(Process_Form_Root);
                root.getChildren().addAll(ProcessTree.tree, EmployeesTree.tree);
                prcess_form_Flag=true;
                subProcess_form_flag=false;
                // root.getChildren().addAll(ProcessTree.tree, EmployeesTree.tree, Pdescription, PSNameL, PName, PDescriptionL, PDescription, PShortDL, PShortD, POwnerL, POwner, PVersionL, PVersion);
            }
            int size = oi.read();
            int j = 0;


            while (Labelss_vector.size() != size) {
                Modi_Label pr11 = (Modi_Label) oi.readObject();
                pr11.setTranslateX(oi.readDouble());
                pr11.setTranslateY(oi.readDouble());
                pr11.setText(pr11.Namee);
                j++;
                if (pr11.exist == true) {
                    pr11.Add_Style();
                    pr11.clearAll();
                    Labelss_vector.add(pr11);
                } else {
                    Modi_Label ne = null;
                    Labelss_vector.add(ne);
                }
            }
            System.out.println("Lb: " + Labelss_vector.size());

            int size1 = oi.read();

            while (Liness_vector.size() != size1) {
                Modi_Line pr21 = (Modi_Line) oi.readObject();
                if (pr21.CanBeConnceted == true) {
                    Liness_vector.add(pr21);
                } else {
                    Modi_Line ne = null;
                    Liness_vector.add(ne);
                }
            }
            for (int i = 0; i < Liness_vector.size(); i++) {
                if (Liness_vector.get(i) == null) {
                    Modi_Line L = null;
                    tem.add(L);
                } else {
                    Modi_Line L = new Modi_Line(Labelss_vector.get(Liness_vector.get(i).S_Index), Labelss_vector.get(Liness_vector.get(i).E_Index));
                    Labelss_vector.get(Liness_vector.get(i).S_Index).lines_id.add(L.Line_Index);
                    Labelss_vector.get(Liness_vector.get(i).E_Index).lines_id.add(L.Line_Index);
                }
            }
            System.out.println("Lsze: " + Liness_vector.size());

            root.getChildren().removeAll(Labels_vector);
            for (int i = 0; i < Labelss_vector.size(); i++) {
                if (Labelss_vector.get(i) != null && Labelss_vector.get(i).Type_id == 0) {
                    MainProcess = Labelss_vector.get(i).MP;
                }
                if (Labelss_vector.get(i) != null) {
                    root.getChildren().add(Labelss_vector.get(i));
                    //System.out.println(Labelss_vector.get(i).getText());
                }
            }

            for (int i = 0; i < Liness_vector.size(); i++) {
                if (Liness_vector.get(i) != null) {
                    root.getChildren().add(Liness_vector.get(i));

                }
            }
           /* Lines_vector.clear();
            Lines_vector.addAll(Liness_vector);
            Labels_vector.clear();
            Labels_vector.addAll(Labelss_vector);*/
            if (flag == 'j') {
                for(int i=0;i<Labelss_vector.size();i++){
                    if(Labelss_vector.get(i).Type_id == 1){
                        if (Labelss_vector.get(i).getText().equalsIgnoreCase("New Employee")) {
                            System.out.println("hal dakhal?");
                            Operation.getItems().clear();
                            Operation.getItems().add(Insert_Employee);
                        }
                        else
                        {
                            System.out.println("madakhalsh el condition");
                            Operation.getItems().clear();
                            //Operation.getItems().add(Insert_Employee);
                            Operation.getItems().add(Save_Employee_Tasks);
                        }}}
                JobTitle.setText(oi.readObject().toString());
                JobType.getEditor().setText(oi.readObject().toString());
                //(oi.readObject());
                JobLocation.getEditor().setText(oi.readObject().toString());
                JobManager.setText(oi.readObject().toString());
                JobQualification.setText(oi.readObject().toString());
                Experience.getEditor().setText(oi.readObject().toString());
                Skills.setText(oi.readObject().toString());
                Languages.getEditor().setText(oi.readObject().toString());
                //fleMenue4.getItems().add(GenerateJD);

            } else if (flag == 'p') {
                Operation.getItems().clear();
                Operation.getItems().add(Save_Process);

                PDescription.setText(oi.readObject().toString());
                PShortD.setText((oi.readObject().toString()));
                POwner.setText((oi.readObject().toString()));
                PVersion.setText(oi.readObject().toString());
                PName.setText(oi.readObject().toString());
//                fleMenue4.getItems().add(GenerateOP);

            }
            oi.close();
            fi.close();

        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("Error initializing stream");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return bath;
    }
    private String openDragged(Vector<Modi_Label> Labelss_vector, Vector<Modi_Line> tem,File file) throws IOException, ClassNotFoundException {
        String bath = file.getAbsolutePath();
        FileInputStream fi = null;
        Vector<Modi_Line> Liness_vector = new Vector<Modi_Line>();

        fi = new FileInputStream(new File(file.getPath()));


        ObjectInputStream oi = null;
        oi = new ObjectInputStream(fi);


        root.getChildren().clear();
        root.getChildren().add(layout);
        Labels_vector.clear();
        Lines_vector.clear();
        // Read objects
        char flag = oi.readChar();
        if (flag == 'j') {

            System.out.println(flag);
            fleMenue4.getItems().clear();
            fleMenue4.getItems().add(GenerateJD);
            fleMenue4.getItems().add(GeneratePdf);
            Operation.getItems().remove(Insert_Employee);

            root.getChildren().addAll( TasksTree.tree, Jobdescription, JobLocation, JobManager, JobQualification, JobTitle, JobType, Languages, Skills, JobLocationL, JobManagerL, JobQualificationL, JobTitleL, JobTypeL, LanguagesL, SkillsL, Experience, ExperienceL);
        } else {
            Operation.getItems().clear();
            Operation.getItems().add(Save_Process2);
            fleMenue4.getItems().clear();
            fleMenue4.getItems().add(GenerateOP);
            fleMenue4.getItems().add(GeneratePdf);

            System.out.println(flag);
            root.getChildren().remove(SubProcess_Form_Root);
            root.getChildren().add(Process_Form_Root);
            root.getChildren().addAll(ProcessTree.tree, EmployeesTree.tree);
            prcess_form_Flag=true;
            subProcess_form_flag=false;
            // root.getChildren().addAll(ProcessTree.tree, EmployeesTree.tree, Pdescription, PSNameL, PName, PDescriptionL, PDescription, PShortDL, PShortD, POwnerL, POwner, PVersionL, PVersion);
        }
        int size = oi.read();
        int j = 0;


        while (Labelss_vector.size() != size) {
            Modi_Label pr11 = (Modi_Label) oi.readObject();
            pr11.setTranslateX(oi.readDouble());
            pr11.setTranslateY(oi.readDouble());
            pr11.setText(pr11.Namee);
            j++;
            if (pr11.exist == true) {
                pr11.Add_Style();
                pr11.clearAll();
                Labelss_vector.add(pr11);
            } else {
                Modi_Label ne = null;
                Labelss_vector.add(ne);
            }
        }
        System.out.println("Lb: " + Labelss_vector.size());

        int size1 = oi.read();
        System.out.println("Lb: sizze " + size1);

        while (Liness_vector.size() != size1) {
            Modi_Line pr21 = (Modi_Line) oi.readObject();
            if (pr21.CanBeConnceted == true) {
                Liness_vector.add(pr21);
            } else {
                Modi_Line ne = null;
                Liness_vector.add(ne);
            }
        }
        for (int i = 0; i < Liness_vector.size(); i++) {
            if (Liness_vector.get(i) == null) {
                Modi_Line L = null;
                tem.add(L);
            } else {
                Modi_Line L = new Modi_Line(Labelss_vector.get(Liness_vector.get(i).S_Index), Labelss_vector.get(Liness_vector.get(i).E_Index));
                Labelss_vector.get(Liness_vector.get(i).S_Index).lines_id.add(L.Line_Index);
                Labelss_vector.get(Liness_vector.get(i).E_Index).lines_id.add(L.Line_Index);
            }
        }
        System.out.println("Lsze: " + Liness_vector.size());

        root.getChildren().removeAll(Labels_vector);
        for (int i = 0; i < Labelss_vector.size(); i++) {
            if (Labelss_vector.get(i) != null && Labelss_vector.get(i).Type_id == 0) {
                MainProcess = Labelss_vector.get(i).MP;
            }
            if (Labelss_vector.get(i) != null) {
                root.getChildren().add(Labelss_vector.get(i));
                //System.out.println(Labelss_vector.get(i).getText());
            }
        }

        for (int i = 0; i < Liness_vector.size(); i++) {
            if (Liness_vector.get(i) != null) {
                root.getChildren().add(Liness_vector.get(i));

            }
        }
           /* Lines_vector.clear();
            Lines_vector.addAll(Liness_vector);
            Labels_vector.clear();
            Labels_vector.addAll(Labelss_vector);*/
        if (flag == 'j') {
            for(int i=0;i<Labelss_vector.size();i++){
                if(Labelss_vector.get(i).Type_id==1){
                    if (Labelss_vector.get(i).getText().equalsIgnoreCase("New Employee")) {
                        System.out.println("hal dakhal?");
                        Operation.getItems().clear();
                        Operation.getItems().add(Insert_Employee);
                    }
                    else
                    {
                        System.out.println("madakhalsh el condition");
                        Operation.getItems().clear();
                        //Operation.getItems().add(Insert_Employee);
                        Operation.getItems().add(Save_Employee_Tasks);
                    }}}
            JobTitle.setText(oi.readObject().toString());
            JobType.getEditor().setText(oi.readObject().toString());
            //(oi.readObject());
            JobLocation.getEditor().setText(oi.readObject().toString());
            JobManager.setText(oi.readObject().toString());
            JobQualification.setText(oi.readObject().toString());
            Experience.getEditor().setText(oi.readObject().toString());
            Skills.setText(oi.readObject().toString());
            Languages.getEditor().setText(oi.readObject().toString());
            //fleMenue4.getItems().add(GenerateJD);

        } else if (flag == 'p') {
            Operation.getItems().clear();
            Operation.getItems().add(Save_Process);

            PDescription.setText(oi.readObject().toString());
            PShortD.setText((oi.readObject().toString()));
            POwner.setText((oi.readObject().toString()));
            PVersion.setText(oi.readObject().toString());
            PName.setText(oi.readObject().toString());
//                fleMenue4.getItems().add(GenerateOP);

        }
        oi.close();
        fi.close();

        return bath;

    }

    private void OpenActon(Vector<Modi_Label> Labelss_vector, Vector<Modi_Line> tem, Stage
            primaryStage, String bath) {
        Vector<Modi_Line> Liness_vector = new Vector<Modi_Line>();
        try {
            FileInputStream fi = new FileInputStream(new File(bath));
            ObjectInputStream oi = new ObjectInputStream(fi);

            root.getChildren().clear();
            root.getChildren().add(layout);
            Labels_vector.clear();
            Lines_vector.clear();
            // Read objects
            char flag = oi.readChar();
            if (flag == 'j') {

                fleMenue4.getItems().clear();
                fleMenue4.getItems().add(GenerateJD);
                fleMenue4.getItems().add(GeneratePdf);
                Operation.getItems().remove(Insert_Employee);


                System.out.println(flag);
                root.getChildren().addAll( TasksTree.tree, Jobdescription, JobLocation, JobManager, JobQualification, JobTitle, JobType, Languages, Skills, JobLocationL, JobManagerL, JobQualificationL, JobTitleL, JobTypeL, LanguagesL, SkillsL, Experience, ExperienceL);
            } else {
                Operation.getItems().clear();
                Operation.getItems().add(Save_Process);
                fleMenue4.getItems().clear();
                fleMenue4.getItems().add(GenerateOP);
                fleMenue4.getItems().add(GeneratePdf);

                System.out.println(flag);
                root.getChildren().remove(SubProcess_Form_Root);
                root.getChildren().add(Process_Form_Root);
                root.getChildren().addAll(ProcessTree.tree, EmployeesTree.tree);
                prcess_form_Flag=true;
                subProcess_form_flag=false;
                // root.getChildren().addAll(ProcessTree.tree, EmployeesTree.tree, Pdescription, PSNameL, PName, PDescriptionL, PDescription, PShortDL, PShortD, POwnerL, POwner, PVersionL, PVersion);
            }
            int size = oi.read();
            int j = 0;


            while (Labelss_vector.size() != size) {
                Modi_Label pr11 = (Modi_Label) oi.readObject();
                pr11.setTranslateX(oi.readDouble());
                pr11.setTranslateY(oi.readDouble());
                pr11.setText(pr11.Namee);
                j++;
                if (pr11.exist == true) {
                    pr11.Add_Style();
                    pr11.clearAll();
                    Labelss_vector.add(pr11);
                } else {
                    Modi_Label ne = null;
                    Labelss_vector.add(ne);
                }
            }

            int size1 = oi.read();

            while (Liness_vector.size() != size1) {
                Modi_Line pr21 = (Modi_Line) oi.readObject();
                if (pr21.CanBeConnceted == true) {
                    Liness_vector.add(pr21);
                } else {
                    Modi_Line ne = null;
                    Liness_vector.add(ne);
                }
            }
            for (int i = 0; i < Liness_vector.size(); i++) {
                if (Liness_vector.get(i) == null) {
                    Modi_Line L = null;
                    tem.add(L);
                } else {
                    Modi_Line L = new Modi_Line(Labelss_vector.get(Liness_vector.get(i).S_Index), Labelss_vector.get(Liness_vector.get(i).E_Index));
                    Labelss_vector.get(Liness_vector.get(i).S_Index).lines_id.add(L.Line_Index);
                    Labelss_vector.get(Liness_vector.get(i).E_Index).lines_id.add(L.Line_Index);
                }
            }

            root.getChildren().removeAll(Labels_vector);
            for (int i = 0; i < Labelss_vector.size(); i++) {
                if (Labelss_vector.get(i) != null && Labelss_vector.get(i).Type_id == 0) {
                    MainProcess = Labelss_vector.get(i).MP;
                }
                if (Labelss_vector.get(i) != null) {
                    root.getChildren().add(Labelss_vector.get(i));
                }
            }

            for (int i = 0; i < Liness_vector.size(); i++) {
                if (Liness_vector.get(i) != null) {
                    root.getChildren().add(Liness_vector.get(i));

                }
            }

            if (flag == 'j') {
                System.out.println();
                for(int i=0;i<Labelss_vector.size();i++){
                    if(Labelss_vector.get(i).Type_id==1){
                        if (Labelss_vector.get(i).getText().equalsIgnoreCase("New Employee")) {
                            System.out.println("hal dakhal?");
                            Operation.getItems().clear();
                            Operation.getItems().add(Insert_Employee);
                        }
                        else
                        {

                            System.out.println("madakhalsh el condition");
                            Operation.getItems().clear();
                            //Operation.getItems().add(Insert_Employee);
                            Operation.getItems().add(Save_Employee_Tasks);
                        }}
                }
                JobTitle.setText(oi.readObject().toString());
                JobType.getEditor().setText(oi.readObject().toString());
                //(oi.readObject());
                JobLocation.getEditor().setText(oi.readObject().toString());
                JobManager.setText(oi.readObject().toString());
                JobQualification.setText(oi.readObject().toString());
                Experience.getEditor().setText(oi.readObject().toString());
                Skills.setText(oi.readObject().toString());
                Languages.getEditor().setText(oi.readObject().toString());
                //fleMenue4.getItems().add(GenerateJD);

            } else if (flag == 'p') {
                Operation.getItems().clear();
                Operation.getItems().add(Save_Process);
                PDescription.setText(oi.readObject().toString());
                PShortD.setText((oi.readObject().toString()));
                POwner.setText((oi.readObject().toString()));
                PVersion.setText(oi.readObject().toString());
                PName.setText(oi.readObject().toString());
                // fleMenue4.getItems().add(GenerateOP);

            }
            oi.close();
            fi.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public static void Reconnect() {
        System.out.println("size " + Lines_vector.size());
        for (int i = 0; i < Lines_vector.size(); i++) {
            if (Lines_vector.get(i) != null) {
                Lines_vector.get(i).Start_ConnectionBetween2Nodes(Lines_vector.get(i));
            }
        }
    }

    public static class MouseGestures {
        class DragContext {
            double x;
            double y;
        }

        DragContext dragContext = new DragContext();

        public void makeDraggable(Node node) {
            node.setOnMousePressed(onMousePressedEventHandler);
            node.setOnMouseDragged(onMouseDraggedEventHandler);
        }


        EventHandler<MouseEvent> onMousePressedEventHandler = event -> {
            if (!event.isShiftDown()) {
                Node node = ((Node) (event.getSource()));
                dragContext.x = node.getTranslateX() - event.getSceneX();
                dragContext.y = node.getTranslateY() - event.getSceneY();
            }
        };

        EventHandler<MouseEvent> onMouseDraggedEventHandler = event -> {
            if (!event.isShiftDown()) {

                Node node = ((Node) (event.getSource()));
                node.toFront();
                node.setTranslateX(dragContext.x + event.getSceneX());
                node.setTranslateY(dragContext.y + event.getSceneY()); // uncomment this if you want x/y dragging
                Reconnect();
            }
        };
    }

    private void AddKeyPress(Group scene) {
        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                scene.setOnKeyPressed((KeyEvent e) -> {
                    if (e.isControlDown()) {
                        if (e.getCode().isLetterKey()) {
                            if (e.getCode().toString() == "Z" || e.getCode().toString() == "z") {
                                H.Undo(scene, Labels_vector, Lines_vector);
                            } else if (e.getCode().toString() == "X" || e.getCode().toString() == "x") {
                                H.Redo(scene, Labels_vector, Lines_vector);
                            } else if (e.getCode().toString() == "F" || e.getCode().toString() == "f" && MainProcess != null) {
                                MainProcess.Get_Info();
                            }
                            System.out.println("Get letter = " + e.getText() + " get char= " + e.getCode().toString());
                        }
                    }
                });
            }
        });
    }


    public static void UnClick() {
        Link.setStyle("");
        Delete.setStyle("");
        System.out.println("unclick");
    }

    public static void printsss(){
//        Group gr =new Group();
//        Scene ssssss=new Scene(gr, 300, 250);
//
//        for(int i=0;i<Labels_vector.size();i++){
//            gr.getChildren().add(Labels_vector.elementAt(i));
//        }
//        for(int i=0;i<Lines_vector.size();i++){
//            gr.getChildren().add(Lines_vector.elementAt(i));
//        }
//        WritableImage snapshot = root.getScene().snapshot(null);
//        //  ((ImageView) snapshot).setImage("Desktop");
//        File file = new File("c55asas55.png");
//        try {
//            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);
//        } catch (Exception s) {
//            System.out.println(s);
//        }

        Button btn = new Button();

        btn.setText("Say 'Hello Worldaaaaaa222222'");
        Group gg = new Group();
        //Scene s=new Scene(root, 300, 250);
        //se=s;
        Scene ssssss=new Scene(gg, 300, 250);

        btn.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
            }
        });

        //gg.getChildren().add(btn);
        //Modi_Label llll=new Modi_Label(Labels_vector.elementAt(0));
        //   gg.getChildren().add(llll);
        Vector<Modi_Label> MLab=new Vector<Modi_Label>();
        Vector<Modi_Line> MLin=new Vector<Modi_Line>();
        for(int i=0;i<Labels_vector.size();i++){
            Modi_Label lab=new Modi_Label(Labels_vector.elementAt(i));
            MLab.add(lab);
            gg.getChildren().add(lab);
        }
        for(int i=0;i<Lines_vector.size();i++){
            Modi_Line lin=new Modi_Line(Lines_vector.elementAt(i),MLab);
            MLin.add(lin);
            gg.getChildren().add(lin);
        }
        for (int i = 0; i < MLin.size(); i++) {
            if (MLin.get(i) != null) {
                MLin.get(i).Start_ConnectionBetween2Nodes(MLin.get(i));
            }
        }
        String Screen_shot_name="New_Screen";
        if (EmployeeScene == true) {
            Screen_shot_name= JobTitle.getText();

        } else {
            Screen_shot_name=PName.getText();
        }
        if(Screen_shot_name.matches("")){
            Screen_shot_name="New_Screen";
        }
        WritableImage image = gg.snapshot(new SnapshotParameters(), null);
        // TODO: probably use a file chooser here
        File file = new File(Screen_shot_name+".png");

        try {
            ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
        } catch (IOException e) {
            // TODO: handle exception here
        }
        gg.getChildren().clear();
        ssssss=null;
    }

    public static void ChangeScene() {
        addressoben="";
        addresssave="";
        root.getChildren().clear();
        root.getChildren().add(layout);
        root.getChildren().add(checkButton);
        if (EmployeeScene) {
            Operation.getItems().clear();
            root.getChildren().add(TasksTree.tree);
            root.getChildren().add(DurationTree.tree);
            root.getChildren().add(Jobdescription);
            root.getChildren().add(JobTitle);
            root.getChildren().add(JobType);
            root.getChildren().add(JobLocation);
            root.getChildren().add(JobManager);
            root.getChildren().add(Languages);
            root.getChildren().add(Experience);
            root.getChildren().add(JobQualification);
            root.getChildren().add(Skills);
            root.getChildren().add(JobTitleL);
            root.getChildren().add(JobTypeL);
            root.getChildren().add(JobLocationL);
            root.getChildren().add(JobManagerL);
            root.getChildren().add(LanguagesL);
            root.getChildren().add(ExperienceL);
            root.getChildren().add(JobQualificationL);
            root.getChildren().add(SkillsL);
            // root.getChildren().add(Save_Employee_Tasks);
            //root.getChildren().add(Insert_Employee);
            EmployeesTree.root.getChildren().clear();
            EmployeesTree.setupDataForEmployees();
        } else {
            Operation.getItems().clear();
            EmployeesTree.root.getChildren().clear();
            EmployeesTree.setupDataForEmployees();
            root.getChildren().add(ProcessTree.tree);
            root.getChildren().add(EmployeesTree.tree);


            // root.getChildren().add(Generate);

        }
        MainProcess = new Process();
        Labels_vector.clear();
        Lines_vector.clear();
        start = -1;
        H = new History();
        DeleteOn = false;
        LinkOn = false;

    }


}