package sample;
import Entities.*;
import Entities.Process;
import Not_Used.ConfirmBox;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.io.Serializable;
import java.util.Vector;

//import static GUI.Image.*;

import static sample.Image.*;
import static sample.Main.*;

public class Modi_Label extends Label implements Serializable {
    private static final long serialVersionUID = 8131742784303653976L;


    String Namee="";
    int index;
    Vector<Integer> lines_id = new Vector<Integer>();
    String Des="";
    double Type_id=-44;
    String Type="";
    Process MP;
    SubProcess SP;
    Activity AC;
    Task_ TA;
    Employee EM;
    File1 ff;
    boolean exist;
    Modi_Label(boolean ex){
        exist=ex;


    }

    Modi_Label(Modi_Tree t) {

        this.setText(t.NAAAMe);
        Type_id = t.Level;
        if (Type_id == 0) {
            MP = new Process(t.MP);
            MP.ClearChildern();
            Type = "MainProcess";
        } else if (Type_id == 1) {
            EM = new Employee(t.EM);
            EM.ClearChildern();
            Type = "Employee";
        } else if (Type_id == -1) {
            TA = new Task_(t.TA);
            TA.ClearChildern();
            Type = "Task_";
        }
        else if (Type_id == -11)
        {
            ff= new File1(t.f);
            Type="File";

        }
        else if (Type_id % 2 == 0) {
            SP = new SubProcess(t.SP);
            SP.ClearChildern();
            Type = "SubProcess";
        }
        else {
            AC = new Activity(t.AC);
            AC.ClearChildern();
            Type = "Activity";
        }
        exist = true;
        this.relocate(500, 500);
        this.toFront();
        this.index = Labels_vector.size();
        //if (Type_id==-1) {
        //root2.getChildren().add(this);

        //} else {
        root.getChildren().add(this);
        //}
        Add_Style();
        Labels_vector.add(this);
        H.add(Labels_vector, Lines_vector);
    }


    Modi_Label(Modi_Label l) {
        this.setText(l.getText());
        this.setFont(Font.font(12));
        this.setTranslateX(l.getTranslateX() + l.layoutXProperty().getValue());
        this.setTranslateY(l.getTranslateY() + l.layoutYProperty().getValue());
        this.toFront();
        this.index = l.index;
        this.Type = l.Type;
        this.lines_id = (Vector<Integer>) l.lines_id.clone();
        Type_id = l.Type_id;
        if (Type_id == 0) {
            MP = new Process(l.MP);
            MP.ClearChildern();
        } else if (Type_id == -1) {
            TA = new Task_(l.TA);
            TA.ClearChildern();
        } else if (Type_id == 1) {
            EM = new Employee(l.EM);
            EM.ClearChildern();
        }
        else if (Type_id == -11)
        {
            ff= new File1(l.ff);

        }else if (Type_id % 2 == 0) {
            SP = new SubProcess(l.SP);
            SP.ClearChildern();
        } else {
            AC = new Activity(l.AC);
            AC.ClearChildern();
        }
        exist = l.exist;
        Add_Style();
    }

    public void Add_Style() {
        if (Type_id == 0) {
            this.setStyle("-fx-font: 12 arial;-fx-border-color: #b1c1ff;-fx-border-radius: 100;-fx-padding: 5;-fx-background-color: rgba(255,252,249,3);");
            this.setGraphic(new ImageView(imageMain));
            // this.setFont(Font.font(12));
            Des = MP.getDescription();
        } else if (Type_id == -1) {
            this.setStyle("-fx-font: 12 arial;-fx-border-color: #b1c1ff;-fx-border-radius: 100;-fx-padding: 5;-fx-background-color: rgba(255,252,249,3);");
            this.setGraphic(new ImageView(imageAC));
            // this.setFont(Font.font(12));
            Des = TA.getDescription();
        } else if (Type_id == 1) {
            this.setStyle("-fx-font: 12 Tahoma;-fx-border-color: #4e2aff;-fx-border-radius: 100;-fx-padding: 5;-fx-background-color: rgba(255,252,249,3);");
            this.setGraphic(new ImageView(image));
            // this.setFont(Font.font(12));
            Des = EM.getDescription();
        } else if (Type_id % 2 == 0) {
            this.setStyle("-fx-font: 12 arial;-fx-border-color: #b1c1ff;-fx-border-radius: 100;-fx-padding: 5;-fx-background-color: rgba(255,252,249,3);");
            this.setGraphic(new ImageView(image2));
//            this.setFont(Font.font(8));
            Des = SP.getDescription();
        }
        else if (Type_id == -11)
        {
            this.setStyle("-fx-font: 12 arial;-fx-border-color: #b1c1ff;-fx-border-radius: 100;-fx-padding: 5;-fx-background-color: rgba(255,252,249,3);");
            Des = ff.getName();

        }
            else {
            this.setStyle("-fx-font: 12 arial;-fx-border-color: #b1c1ff;-fx-border-radius: 100;-fx-padding: 5;-fx-background-color: rgba(255,252,249,3);");
            this.setGraphic(new ImageView(imageAC));
            // this.setFont(Font.font(12));
            Des = AC.getDescription();
        }
        Add_Click(this);
        Add_Hover(this);
    }

    public void Add_Click(Modi_Label labex) {
        labex.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (labex instanceof Modi_Label) {
                    if (LinkOn || event.isShiftDown()) {
                        Add_Link(labex);
                    }
                    if (DeleteOn || event.isAltDown()) {
                        boolean answer;
                        if(araabc)
                        {
                             answer = ConfirmBoxArabic.display("مسح", "هل تريد الحذف ؟");

                        }
                        else {
                             answer = ConfirmBox.display("Delete ", "Are you want to Delete it ?");
                        }
                        if(answer) {
                            System.out.println("Node Deleted");
                            exist = false;
                            for (int i = 0; i < labex.lines_id.size(); i++) {
                                Modi_Line LL = Lines_vector.get(labex.lines_id.get(i));
                                if (LL != null) {
                                    LL.CanBeConnceted = false;
                                    Lines_vector.set(LL.Line_Index, null);
                                    root.getChildren().remove(LL);
                                    LL.Disconnect();
                                }
                            }
                            Labels_vector.set(labex.index, null);
                            root.getChildren().remove(labex);
                            H.add(Labels_vector, Lines_vector);
                            DeleteOn = false;
                            UnClick();
                        }
                        else{
                            DeleteOn = false;
                            UnClick();
                        }

                    }
                    if (event.isControlDown()) {
                        GetInfo();
                    }
                }
            }
        });
        mg.makeDraggable(labex);
    }

    public void GetInfo() {
        System.out.println("My index is " + this.index + " and CanBeConnceted is " + exist);
        if (Type_id == 0) {
            MP.Get_Info();
        } else if (Type.matches("SubProcess")) {
            SP.Get_Info("");
        } else if (Type.matches("Activity")) {
            AC.Get_Info("");
        }
        else if (Type.matches("Task")) {
            TA.Get_Info("");
        }
        else{
            System.out.println(EM.GetTasksString());
            //    System.out.println(EM.GetTasksString());

        }
        System.out.println("and it's type is " + Type);
    }


    public void Add_Hover(Modi_Label labelx) {
        labelx.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (labelx instanceof Modi_Label) {
                    final Tooltip tooltip = new Tooltip();
                    tooltip.setFont(Font.font(12));
                    tooltip.setText(labelx.Des);
                    labelx.setTooltip(tooltip);
                }
            }

        });
    }

    public void Add_Link(Modi_Label labex) {
        if (start != -1) {
            if (start != labex.index) {
                Modi_Line line = new Modi_Line(Labels_vector.get(start), labex);
                if (exist = true) {
                    labex.lines_id.add(line.Line_Index);
                    Labels_vector.get(start).lines_id.add(line.Line_Index);
                    H.add(Labels_vector, Lines_vector);

                }
                //set every thing back to normal
                Labels_vector.get(start).setTextFill(Color.BLACK);
                start = -1;
                labex.setTextFill(Color.BLACK);
                LinkOn = false;
                UnClick();
                root.getChildren().remove(Dummy_Line);
            } else {
                Labels_vector.get(start).setTextFill(Color.BLACK);
                start = -1;
                labex.setTextFill(Color.BLACK);
                LinkOn = false;
                UnClick();
            }
        } else {
            start = labex.index;
            if (labex.Type_id == 1) {
                labex.setTextFill(Color.GOLD);
            } else {
                labex.setTextFill(Color.ROYALBLUE);
            }
        }
    }

    public void clearAll()
    {
        if (Type_id == 0) {
            MP.ClearChildern();
        } else if (Type_id == -1) {
            TA.ClearChildern();
        } else if (Type_id == 1) {
            EM.ClearChildern();
        }
        else if (Type_id % 2 == 0) {
            SP.ClearChildern();
        } else {
            AC.ClearChildern();
        }
    }
}
