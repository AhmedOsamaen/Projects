package sample;

import java.io.Serializable;
import java.util.Vector;

public class SceneComponents implements Serializable {
    public int Label_MP_Index=-1;
    public Vector<Modi_Label> Labels = new Vector<Modi_Label>();
    public Vector<Modi_Line> Lines = new Vector<Modi_Line>();

}

