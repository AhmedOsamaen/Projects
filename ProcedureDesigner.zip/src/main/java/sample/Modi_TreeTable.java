package sample;

import Entities.*;
import Controller.DB;
import Entities.Process;
import Repositories.FileRepository;
import Repositories.Repository;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeTableView;
import javafx.util.Duration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static sample.Image.imageNew;
import static sample.Main.EmployeeScene;

public class Modi_TreeTable implements Serializable {
    Modi_TreeTable() {
        this.root = new Modi_Tree<>();
        this.tree = new TreeTableView<>(this.root);
        this.tree.setShowRoot(false);
        this.tree.setRowFactory(this::rowFactory);
         this.setupScrolling();
    }

    Test_Data TT = new Test_Data();
    public Modi_Tree<Map<String, Object>> root;
    public TreeTableView<Map<String, Object>> tree;
    public Timeline scrolltimeline = new Timeline();
    public double scrollDirection = 0;

 public void setupScrolling() {
        scrolltimeline.setCycleCount(Timeline.INDEFINITE);
        scrolltimeline.getKeyFrames().add(new KeyFrame(Duration.millis(20), "Scoll", (ActionEvent) -> {
            dragScroll();
        }));
        tree.setOnDragExited(event -> {
            if (event.getY() > 0) {
                scrollDirection = 1.0 / tree.getExpandedItemCount();
            } else {
                scrollDirection = -1.0 / tree.getExpandedItemCount();
            }
            scrolltimeline.play();
        });
        tree.setOnDragEntered(event -> {
            scrolltimeline.stop();
        });
        tree.setOnDragDone(event -> {
            scrolltimeline.stop();
        });
    }

    public void dragScroll() {
        ScrollBar sb = getVerticalScrollbar();
        if (sb != null) {
            double newValue = sb.getValue() + scrollDirection;
            newValue = Math.min(newValue, 1.0);
            newValue = Math.max(newValue, 0.0);
            sb.setValue(newValue);
        }
    }

    public ScrollBar getVerticalScrollbar() {
        ScrollBar result = null;
        for (Node n : tree.lookupAll(".scroll-bar")) {
            if (n instanceof ScrollBar) {
                ScrollBar bar = (ScrollBar) n;
                if (bar.getOrientation().equals(Orientation.VERTICAL)) {
                    result = bar;
                }
            }
        }
        return result;
    }

    public TreeTableRow<Map<String, Object>> rowFactory(TreeTableView<Map<String, Object>> view) {
        TreeTableRow<Map<String, Object>> row = new TreeTableRow<>();
        return row;
    }

    public void setupDataForEmployees() {
        if(EmployeeScene){
            Employee E1 = new Employee("New Employee", 1, "_New Employee_J1", "This is New Employee");
            Modi_Tree<Map<String, Object>> e3 = createItemForEmployees(root, "New Employee", "Shift and left mouse click for adding new employee");
            //  e3.Level=33;
            //e3.setGraphic("");
            e3.EM = E1;
            e3.setGraphic(new javafx.scene.image.ImageView(imageNew));
        }


        for (int i = 0; i < TT.Employees.size(); i++) {
            Modi_Tree<Map<String, Object>> e = createItemForEmployees(root, TT.Employees.get(i).getRole(), TT.Employees.get(i).getDescription());
            e.EM = TT.Employees.get(i);
        }
    }

    public void setupDataForProcess() {
        //      javafx.scene.image.Image imageNewP = new javafx.scene.image.Image(Image.class.getResourceAsStream("icon.png"), 40, 40, false, true);
//        javafx.scene.image.Image imageNewS = new javafx.scene.image.Image(Image.class.getResourceAsStream("New.png"), 40, 40, false, true);

        Process p1 = new Process("New Main Process", 1, "Shift and mouse left click to Add New Main Process ", 3);
        Modi_Tree<Map<String, Object>> New_MainProcess = createItemForProcess(root, p1.getShortDescription(), "Main Process", p1.getDescription(), 0);
        New_MainProcess.MP = p1;
        //   New_MainProcess.getGraphic().
        New_MainProcess.setGraphic(new javafx.scene.image.ImageView(imageNew));
        SubProcess S_P_1 = new SubProcess("New Sub Process", 11, "Shift and mouse left click to Add new Sub Process 1 ", 3);
        Modi_Tree<Map<String, Object>> TSPs = createItemForProcess(root, S_P_1.getName(), "Sub Process", S_P_1.getDescription(), -4);
        TSPs.SP = S_P_1;
        TSPs.setGraphic(new javafx.scene.image.ImageView(imageNew));

        Modi_Tree<Map<String, Object>> langa = createItemForGat(root, "AR", -44);
        Modi_Tree<Map<String, Object>> lange = createItemForGat(root, "EN", -44);
        Modi_Tree<Map<String, Object>> files = createItemForGat(root, "Files", -44);
       for(int j =0;j<TT.allFiles.size();j++){
        if(TT.allFiles.get(j).getType() == 0) {
            Modi_Tree<Map<String, Object>> ff = createItemForFiles(files, TT.allFiles.get(j).getName());
            ff.f = TT.allFiles.get(j);
        }

       }
        List<SubProcess> subProcesses=new ArrayList<SubProcess>(TT.db.getALlSubProcess());

 /*       for (int i = 0; i < TT.procedures_array.size(); i++) {
            // Modi_Tree<Map<String, Object>> MainProcess = createItemForProcess(root, TT.procedures_array.get(i).getShortDescription(), "Main Process", TT.procedures_array.get(i).getDescription(), 0);
            // MainProcess.MP = TT.procedures_array.get(i);
            // MainProcess.setExpanded(false);
            subProcesses.addAll(TT.procedures_array.get(i).getSubProcesses());
        }*/

        for (int k = 0; k < TT.sTDScats.size(); k++) {
            Modi_Tree<Map<String, Object>> Cata = createItemForGat(langa, TT.sTDScats.get(k), -44);
            Modi_Tree<Map<String, Object>> Cate = createItemForGat(lange, TT.sTDScats.get(k), -44);
            ArrayList<String> results = new ArrayList<>();
                for(int x =0;x < TT.categoriesSb.size();x++) {
                    //System.out.println("categories " + TT.categoriesSb.get(x));

                    Modi_Tree<Map<String, Object>> categoryArabic= null;
                    Modi_Tree<Map<String, Object>> categoryEnglish=null;
                    for (int j = 0; j < subProcesses.size(); j++) {
                    if(subProcesses.get(j).getSTD().matches(TT.sTDScats.get(k))&&subProcesses.get(j).isChildFlag()==false
                            &&subProcesses.get(j).getCategory().equals(TT.categoriesSb.get(x))) {
                        if(!results.contains(subProcesses.get(j).getCategory()))
                        {
                             categoryArabic = createItemForGat(Cata, TT.categoriesSb.get(x), -44);
                             categoryEnglish = createItemForGat(Cate, TT.categoriesSb.get(x), -44);
                            //System.out.println(subProcesses.get(j).getCategory() + "catrogryyy");
                            Modi_Tree<Map<String, Object>> TSP;
                            if (subProcesses.get(j).getLanguage().matches("AR")) {
                                TSP = createItemForProcess(categoryArabic, subProcesses.get(j).getName(), "Sub Process", subProcesses.get(j).getDescription(), 2);

                            } else {
                                TSP = createItemForProcess(categoryEnglish, subProcesses.get(j).getName(), "Sub Process", subProcesses.get(j).getDescription(), 2);

                            }
                            TSP.SP = subProcesses.get(j);
                            TSP.setExpanded(false);
                            Add_Child(TSP, subProcesses.get(j), 2);
                            results.add(subProcesses.get(j).getCategory());
                        }
                        else {

                          //  System.out.println(subProcesses.get(j).getCategory() + "catrogryyy");
                            Modi_Tree<Map<String, Object>> TSP;
                            if (subProcesses.get(j).getLanguage().matches("AR")) {
                                TSP = createItemForProcess(categoryArabic, subProcesses.get(j).getName(), "Sub Process", subProcesses.get(j).getDescription(), 2);

                            } else {
                                TSP = createItemForProcess(categoryEnglish, subProcesses.get(j).getName(), "Sub Process", subProcesses.get(j).getDescription(), 2);

                            }
                            TSP.SP = subProcesses.get(j);
                            TSP.setExpanded(false);
                            Add_Child(TSP, subProcesses.get(j), 2);
                            //  break;
                        }
                    }



                }


            }
            //TT.procedures_array.get(i).SubProcesses.get(j).level_num = 2;

        }
    }


    public void setupDataForTasks() {
        //for(){}
        Modi_Tree<Map<String, Object>> langa = createItemForGat(root, "AR", -44);
        Modi_Tree<Map<String, Object>> lange = createItemForGat(root, "EN", -44);
        Modi_Tree<Map<String, Object>> files = createItemForGat(root, "Files", -44);
        for(int j =0;j<TT.allFiles.size();j++){
            if(TT.allFiles.get(j).getType() == 1) {
                Modi_Tree<Map<String, Object>> ff = createItemForFiles(files, TT.allFiles.get(j).getName());

                ff.f = TT.allFiles.get(j);
            }

        }
        for (int j = 0; j < TT.Cats.size(); j++) {


            // if(.get(j).getLanguage().matches("A"))


            Modi_Tree<Map<String, Object>> Cata = createItemForGat(langa, TT.Cats.get(j), -44);
            Modi_Tree<Map<String, Object>> Cate = createItemForGat(lange, TT.Cats.get(j), -44);

            for (int i = 0; i < TT.Tasks_list.size(); i++) {
                if (TT.Tasks_list.get(i).getCategory().matches(TT.Cats.get(j))) {
                    TT.Tasks_list.get(i).getDescription();
                    Modi_Tree<Map<String, Object>> Task;
                    if (TT.Tasks_list.get(i).getLanguage().matches("AR")) {
                        Task = createItemForProcess(Cata, TT.Tasks_list.get(i).getShortDesc(), "Task_", TT.Tasks_list.get(i).getDescription(), -1);
                    } else {
                        Task = createItemForProcess(Cate, TT.Tasks_list.get(i).getShortDesc(), "Task_", TT.Tasks_list.get(i).getDescription(), -1);
                    }
                    Task.TA = TT.Tasks_list.get(i);
                    Task.setExpanded(false);
                }

            }
        }
    }

    public void Add_Child(Modi_Tree<Map<String, Object>> parent, SubProcess SP, int Level) {
        if (SP.getChild() != null) {
            Modi_Tree<Map<String, Object>> TCH = createItemForProcess(parent, SP.getChild().getShortDescription(), "Sub Process", SP.getChild().getDescription(), Level + 2);
            TCH.SP = SP.getChild();
            SP.getChild().level_num = Level + 2;
            Add_Child(TCH, SP.getChild(), Level + 2);
            parent.setExpanded(false);
        }
        List<Activity> SPA = new ArrayList<Activity>(SP.getActivities());
        for (int i = 0; i < SPA.size(); i++) {
            Modi_Tree<Map<String, Object>> TA = createItemForProcess(parent, "--" + SPA.get(i).getShortDescription(), "Activity", SPA.get(i).getDescription(), Level + 3);
            TA.AC = SPA.get(i);
            SPA.get(i).level_num = Level + 3;
        }
    }

    public Modi_Tree<Map<String, Object>> createItemForProcess(Modi_Tree<Map<String, Object>> parent, String region, String type, String desc, int Level) {
        Modi_Tree<Map<String, Object>> item = new Modi_Tree<>();
        item.NAAAMe = region;
        item.Desc = desc + "  " + Level;
        item.Level = Level;
        Map<String, Object> value = new HashMap<>();
        value.put("Process", region);
        value.put("Type", type);

        item.setValue(value);
        if (Level == 0) {
            javafx.scene.image.Image imageMainx = new javafx.scene.image.Image(sample.Image.class.getResourceAsStream("/Images_And_Icons/icon_main.png"), 20, 20, false, true);
            item.setGraphic(new javafx.scene.image.ImageView(imageMainx));
        } else if (Level % 2 == 0) {
            javafx.scene.image.Image image2x = new javafx.scene.image.Image(sample.Image.class.getResourceAsStream("/Images_And_Icons/iconA.png"), 20, 20, false, true);
            item.setGraphic(new javafx.scene.image.ImageView(image2x));
        } else {
            javafx.scene.image.Image imageACx = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/iconAc.png"), 20, 20, false, true);
            item.setGraphic(new javafx.scene.image.ImageView(imageACx));
        }

        parent.getChildren().add(item);
        item.setExpanded(false);
        return item;
    }

    public Modi_Tree<Map<String, Object>> createItemForEmployees(Modi_Tree<Map<String, Object>> parent, String region, String Des) {
        Modi_Tree<Map<String, Object>> item = new Modi_Tree<>();
        item.NAAAMe = region;
        item.Level = 1;
        item.Desc = Des;
        Map<String, Object> value = new HashMap<>();
        value.put("Process", region);
        item.setValue(value);
        parent.getChildren().add(item);
        item.setExpanded(false);
        javafx.scene.image.Image imagex = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/icon.png"), 30, 30, false, true);
        item.setGraphic(new javafx.scene.image.ImageView(imagex));

        return item;
    }
    public Modi_Tree<Map<String, Object>> createItemForFiles(Modi_Tree<Map<String, Object>> parent, String region) {
        Modi_Tree<Map<String, Object>> item = new Modi_Tree<>();
        item.NAAAMe = region;
        item.Level = -11;
        Map<String, Object> value = new HashMap<>();
        value.put("Process", region);
        item.setValue(value);
        parent.getChildren().add(item);
        item.setExpanded(false);
        javafx.scene.image.Image imagex = new javafx.scene.image.Image(Image.class.getResourceAsStream("/Images_And_Icons/file.png"), 20, 20, false, true);
        item.setGraphic(new javafx.scene.image.ImageView(imagex));

        return item;
    }


    public Modi_Tree<Map<String, Object>> createItemForGat(Modi_Tree<Map<String, Object>> parent, String region, int id) {
        Modi_Tree<Map<String, Object>> item = new Modi_Tree<>();
        item.NAAAMe = region;
        item.Level = id;
        item.Desc = region;
        Map<String, Object> value = new HashMap<>();
        value.put("Process", region);
        item.setValue(value);
        parent.getChildren().add(item);
        item.setExpanded(false);
        return item;
    }


    public void addColumn(String label, String dataIndex) {
        TreeTableColumn<Map<String, Object>, String> column = new TreeTableColumn<>(label);
        column.setPrefWidth(230);
        column.setCellValueFactory(
                (TreeTableColumn.CellDataFeatures<Map<String, Object>, String> param) -> {
                    ObservableValue<String> result = new ReadOnlyStringWrapper("");
                    if (param.getValue().getValue() != null) {
                        result = new ReadOnlyStringWrapper("" + param.getValue().getValue().get(dataIndex));
                    }
                    return result;
                }
        );
        tree.getColumns().add(column);
    }

}

