package sample;
import Entities.*;
import Controller.DB;
import Entities.Process;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Test_Data implements Serializable {

    DB db =new DB();


    public List<Employee> Employees = new ArrayList<Employee>();
    public List<Process> procedures_array = new ArrayList<Process>();
    public List<File1> allFiles = new ArrayList<>();

    public List<String> categoriesSb = new ArrayList<String>();
    public List<Process> procedures_array1 = new ArrayList<Process>();
    public List<SubProcess> SubProcess_list = new ArrayList<SubProcess>();
    public List<Activity> Activites_list = new ArrayList<Activity>();
    public List<Task_> Tasks_list = new ArrayList<Task_>();
    public ArrayList<String> Cats=new ArrayList<String>();
    public ArrayList<String> sTDScats=new ArrayList<String>();
    public ArrayList<String> langCats=new ArrayList<String>();

    //public Vector<Process> proceduresArray = new Vector<Process>();
    // public Vector<Employee> EmployeesArray = new Vector<Employee>();




 /*   Process procedure1 = new Process("Main Process 1", 1, "This is Main Process 1 and bla bla bla", 3);
    Process procedure2 = new Process("Main Process 2", 2, "This is Main Process 2 and bla bla bla", 2);
    //Process procedure3;


    SubProcess S_P_1 = new SubProcess("Sub Process 1", 11, "This is Sub Process 1 and bla bla bla", 3);
    SubProcess S_P_2 = new SubProcess("Sub Process 2", 12, "This is Sub Process 2 and bla bla bla", 3);
    SubProcess S_P_3 = new SubProcess("Sub Process 3", 13, "This is Sub Process 3 and bla bla bla", 2);
    SubProcess S_P_4 = new SubProcess("Sub Process 4", 14, "This is Sub Process 4 and bla bla bla", 2);

    SubProcess S_S_P_1 = new SubProcess("Second Sub Process 1", 111, "This is Second Sub Process 1 and bla bla bla", 2);
    SubProcess S_S_P_2 = new SubProcess("Second Sub Process 2", 112, "This is Second Sub Process 2 and bla bla bla", 2);
    SubProcess S_S_P_3 = new SubProcess("Second Sub Process 3", 121, "This is Second Sub Process 3 and bla bla bla", 1);
    SubProcess S_S_P_4 = new SubProcess("Second Sub Process 4", 122, "This is Second Sub Process 4 and bla bla bla", 1);
    SubProcess S_S_P_55 = new SubProcess("Second Sub Process 55", 12255, "This is Second Sub Process 55 and bla bla bla", 1);

    Activity A_1 = new Activity("Activity 1", 1111, "This is Activity 1", 3);
    Activity A_2 = new Activity("Activity 2", 1112, "This is Activity 2", 3);
    Activity A_3 = new Activity("Activity 3", 1121, "This is Activity 3 and bla bla bla", 3);
    Activity A_4 = new Activity("Activity 4", 1122, "This is Activity 4 and bla bla bla", 3);
    Activity A_5 = new Activity("Activity 5", 1211, "This is Activity 5 and bla bla bla", 3);
    Activity A_6 = new Activity("Activity 6", 1212, "This is Activity 6 and bla bla bla", 3);
    Activity A_7 = new Activity("Activity 7", 1221, "This is Activity 7 and bla bla bla", 3);
    Activity A_8 = new Activity("Activity 8", 1222, "This is Activity 8 and bla bla bla", 3);

    Activity A_9 = new Activity("Activity 9", 131, "This is Activity 9 and bla bla bla", 2);
    Activity A_10 = new Activity("Activity 10", 132, "This is Activity 10 and bla bla bla", 2);
    Activity A_11 = new Activity("Activity 11", 141, "This is Activity 11 and bla bla bla", 2);
    Activity A_12 = new Activity("Activity 12", 142, "This is Activity 12 and bla bla bla", 2);

    Activity A_13 = new Activity("Activity 13", 13133, "This is Activity 13 and bla bla bla", 2);
    Activity A_14 = new Activity("Activity 14", 13244, "This is Activity 14 and bla bla bla", 2);
    Activity A_15 = new Activity("Activity 15", 14155, "This is Activity 15 and bla bla bla", 2);
    Activity A_16 = new Activity("Activity 16", 14266, "This is Activity 16 and bla bla bla", 2);

    Employee E1 = new Employee("Employee 1", 1, "J1", "This is Employee 1 and bla bla bla");
    Employee E2 = new Employee("Employee 2", 2, "J2", "This is Employee 2 and bla bla bla");
    Employee E3 = new Employee("Employee 3", 3, "J3", "This is Employee 3 and bla bla bla");
    Employee E4 = new Employee("Employee 4", 1, "J1", "This is Employee 4 and bla bla bla");
    Employee E5 = new Employee("Employee 5", 2, "J2", "This is Employee 5 and bla bla bla");
    Employee E6 = new Employee("Employee 6", 3, "J3", "This is Employee 6 and bla bla bla");
    Employee E7 = new Employee("Employee 7", 1, "J1", "This is Employee 7 and bla bla bla");
    Employee E8 = new Employee("Employee 8", 2, "J2", "This is Employee 8 and bla bla bla");
    Employee E9 = new Employee("Employee 9", 3, "J3", "This is Employee 9 and bla bla bla");


    Task_ T_1 = new Task_("Task_ 1", 1111, "This is Task_ 1 and bla bla bla");
    Task_ T_2 = new Task_("Task_ 2", 1112, "This is Task_ 2 and bla bla bla");
    Task_ T_3 = new Task_("Task_ 3", 1121, "This is Task_ 3 and bla bla bla");
    Task_ T_4 = new Task_("Task_ 4", 1122, "This is Task_ 4 and bla bla bla");
*/

    public Test_Data() {

        Employees= db.getALlEmployees();
        procedures_array=db.getALlProcess();
        SubProcess_list=db.getALlSubProcess();
        allFiles = db.getAllFiles();
        Tasks_list=db.GetAllTaskes();
        Cats=db.GetAllCategorisFromTasks();
        sTDScats=db.GetAllSTDFromSubprosess();
        langCats=db.GetAllLanguagesFromSubprosess();
        categoriesSb = db.GetAllCategoriesFromSubprosess();
/*
            Employees.add(E1);
            Employees.add(E2);
            Employees.add(E3);
            Employees.add(E4);
            Employees.add(E5);
            Employees.add(E6);
            Employees.add(E7);
            Employees.add(E8);
            Employees.add(E9);

            procedures_array.add(procedure1);
            procedures_array.add(procedure2);

            SubProcess_list.add(S_P_1);
            SubProcess_list.add(S_P_2);
            SubProcess_list.add(S_P_3);
            SubProcess_list.add(S_P_4);
            SubProcess_list.add(S_S_P_1);
            SubProcess_list.add(S_S_P_2);
            SubProcess_list.add(S_S_P_3);
            SubProcess_list.add(S_S_P_4);

            Activites_list.add(A_1);
            Activites_list.add(A_2);
            Activites_list.add(A_3);
            Activites_list.add(A_4);
            Activites_list.add(A_5);
            Activites_list.add(A_6);
            Activites_list.add(A_7);
            Activites_list.add(A_8);
            Activites_list.add(A_9);
            Activites_list.add(A_10);
            Activites_list.add(A_11);
            Activites_list.add(A_12);

            procedure1.getSubProcesses().add(S_P_1);
            procedure1.getSubProcesses().add(S_P_2);
            procedure2.getSubProcesses().add(S_P_3);
            procedure2.getSubProcesses().add(S_P_4);

            S_P_1.getActivities().add(A_13);
            S_P_1.getActivities().add(A_14);
            S_P_2.getActivities().add(A_15);
            S_P_2.getActivities().add(A_16);

            S_P_3.getActivities().add(A_9);
            S_P_3.getActivities().add(A_10);
            S_P_4.getActivities().add(A_11);
            S_P_4.getActivities().add(A_12);

            Tasks_list.add(T_1);
            Tasks_list.add(T_2);
            Tasks_list.add(T_3);
            Tasks_list.add(T_4);


            S_P_1.setChild(S_S_P_1);
            S_P_2.setChild(S_S_P_2);
            S_P_3.setChild(S_S_P_3);
            S_P_4.setChild(S_S_P_4);

            S_S_P_1.getActivities().add(A_1);
            S_S_P_1.setChild(S_S_P_55);
            S_S_P_1.getActivities().add(A_2);
            S_S_P_2.getActivities().add(A_3);
            S_S_P_2.getActivities().add(A_4);
            S_S_P_3.getActivities().add(A_5);
            S_S_P_3.getActivities().add(A_6);
            S_S_P_4.getActivities().add(A_7);
            S_S_P_4.getActivities().add(A_8);

*/
    }


}

