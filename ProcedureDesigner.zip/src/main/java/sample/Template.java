package sample;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List;

public class Template {
    private String template_path ;
    private XWPFDocument doc;
    private String save_path;
    private File f;
    Template(String path,String template_path) throws IOException, InvalidFormatException {
        save_path = path;
        this.template_path = template_path;
        System.out.println("Test");
        f = new File(template_path);
        OPCPackage pkg = OPCPackage.open(f);
        pkg.replaceContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml");
        doc = new XWPFDocument(pkg);
    }

    void replaceText(String keyword, String value) throws Exception {
        for (XWPFParagraph p : doc.getParagraphs()) {
            List<XWPFRun> runs = p.getRuns();
            if (runs != null) {
                for (XWPFRun r : runs) {
                    String text = r.getText(0);
                    System.out.println(r.getText(0));
                    if (text != null && text.contains(keyword)) {
                        text = text.replace(keyword, value);

//                        r.setText(text, 0);
                        setText(r,text);
                        //r.setBold(true);
                        r.setFontFamily("JQRNOE Times New Roman Italic");
                        r.setFontSize(14);
                        r.setColor("000000");
                        System.out.println(r.getText(0));
                    }
                }
            }
        }
        for (XWPFTable tbl : doc.getTables()) {
            System.out.println("hellooooooooo1");

            for (XWPFTableRow row : tbl.getRows()) {
                System.out.println("hellooooooooo2");

                for (XWPFTableCell cell : row.getTableCells()) {
                    System.out.println("hellooooooooo3");

                    for (XWPFParagraph p : cell.getParagraphs()) {
                        System.out.println("hellooooooooo4");

                        for (XWPFRun r : p.getRuns()) {
                            System.out.println("hellooooooooo5");

                            String text = r.getText(0);
                            System.out.println(r.getText(0));

                            if (text != null && text.contains(keyword)) {
                                text = text.replace(keyword, value);
                                setText(r,text);
                                r.setFontFamily("JQRNOE Times New Roman Italic");
                                r.setFontSize(14);
                                r.setColor("000000");
                                System.out.println("hellooooooooo6");

                            }
                        }
                    }
                }
            }
        }
    }
    void saveWord() throws Exception {
       captureScreenShot();

        doc.write(new FileOutputStream(save_path));
        doc.close();
     //   pkg.close();
    }
    void setText(XWPFRun run, String data){
        if (data.contains("\n")) {
            String[] lines = data.split("\n");

            run.setText(lines[0], 0); // set first line into XWPFRun
            for(int i=1;i<lines.length;i++){
                // add break and insert new text

                run.addCarriageReturn(); //ADD THE NEW LINE
                run.setText(lines[i]);
            }
        } else {
            run.setText(data, 0);
        }


    }
    void captureScreenShot( ) throws Exception {
        XWPFRun run = doc.createParagraph().createRun();
//new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()
        String screenshot_name ="image" + ".png";
        BufferedImage image = new Robot().createScreenCapture(new Rectangle(410,100,945,700));
        File file = new File( screenshot_name);
        ImageIO.write(image, "png", file);
        InputStream pic = new FileInputStream(screenshot_name);
        run.addBreak();
        run.addPicture(pic, XWPFDocument.PICTURE_TYPE_PNG, screenshot_name, Units.toEMU(350), Units.toEMU(350));
        pic.close();
        file.delete();
    }

}